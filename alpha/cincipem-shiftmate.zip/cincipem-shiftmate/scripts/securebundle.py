"""Encrypted data bundle for CinciPEM ShiftMate.

Released builds ship the roster, shift codes, holiday list and SKILL_SENSITIVE.md
only inside `secure.bin`. This module packs and unpacks it. Standard library plus
the vendored pure-Python AES (pyaes); uses the `cryptography` package instead when
it is installed (same output, faster).

File layout:
  MAGIC (6 bytes) | log2(scrypt N) (1 byte) | salt (16) | nonce (16) | body | tag (32)
  key material = scrypt(normalize(passphrase), salt, N, r=8, p=1) -> 64 bytes
  body = AES-256-CTR(first 32 bytes, nonce)(zip of the files)
  tag  = HMAC-SHA256(last 32 bytes, everything before the tag)
"""
import hashlib, hmac, io, os, re, sys, zipfile

VERSION = "0.01.82"

MAGIC = b"CPSS1\n"
LOG2_N = 16
ALLOWED = re.compile(r"^(data/[A-Za-z0-9_]+\.csv|SKILL_SENSITIVE\.md|thankyou\.md)$")


class BadPassphrase(Exception):
    pass


class BadBundle(Exception):
    pass


def normalize(passphrase):
    """Ignore capitals, punctuation and extra spaces."""
    return " ".join(re.sub(r"[^a-z0-9]+", " ", passphrase.lower()).split())


def _keys(passphrase, salt, log2n):
    k = hashlib.scrypt(normalize(passphrase).encode(), salt=salt, n=2 ** log2n, r=8, p=1,
                       maxmem=2 ** 28, dklen=64)
    return k[:32], k[32:]


def _ctr(key, nonce, data):
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        c = Cipher(algorithms.AES(key), modes.CTR(nonce)).encryptor()
        return c.update(data) + c.finalize()
    except ImportError:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor"))
        import pyaes
        return pyaes.AESModeOfOperationCTR(key, pyaes.Counter(int.from_bytes(nonce, "big"))).encrypt(data)


def pack(files, passphrase):
    """files: {archive name: bytes}. Returns the encrypted bundle."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(files):
            if not ALLOWED.match(name):
                raise ValueError("not allowed in the bundle: " + name)
            z.writestr(zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0)), files[name], zipfile.ZIP_DEFLATED)
    salt, nonce = os.urandom(16), os.urandom(16)
    ek, mk = _keys(passphrase, salt, LOG2_N)
    head = MAGIC + bytes([LOG2_N]) + salt + nonce
    body = _ctr(ek, nonce, buf.getvalue())
    return head + body + hmac.new(mk, head + body, hashlib.sha256).digest()


def unpack(blob, passphrase):
    """Returns {archive name: bytes}. Raises BadPassphrase or BadBundle."""
    if not blob.startswith(MAGIC) or len(blob) < len(MAGIC) + 1 + 32 + 32:
        raise BadBundle("not a CinciPEM bundle")
    i = len(MAGIC)
    log2n, salt, nonce = blob[i], blob[i + 1:i + 17], blob[i + 17:i + 33]
    head, body, tag = blob[:i + 33], blob[i + 33:-32], blob[-32:]
    ek, mk = _keys(passphrase, salt, log2n)
    if not hmac.compare_digest(tag, hmac.new(mk, head + body, hashlib.sha256).digest()):
        raise BadPassphrase("wrong passphrase")
    out = {}
    with zipfile.ZipFile(io.BytesIO(_ctr(ek, nonce, body))) as z:
        for name in z.namelist():
            if not ALLOWED.match(name):
                raise BadBundle("unexpected file in bundle: " + name)
            out[name] = z.read(name)
    return out
