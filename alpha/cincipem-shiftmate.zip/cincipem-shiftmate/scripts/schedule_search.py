#!/usr/bin/env python3
"""CinciPEM ShiftMate · Version 0.01.08b · Shift Search (Schedule Inquiry and Planning, sub-workflow 1).

Administrators search the whole division's schedule by date range, clinician, site, time of day, day kind,
shift kind, shift level and role. The side-panel page (assets/shift-search.html) copies one line
(SHIFTMATE_SEARCH ...); Claude runs `search --line` on it and shows the list in the chat.
See workflows/schedule-inquiry/shift-search.md.

Uses the engine (shiftmate.py) as a library for the schedule, the roster and every rule; nothing is rebuilt here.

Commands:
  page --out FILE          write a copy of the page with the option lists filled in (PAGE_READY: FILE)
  page-data                print the option lists and the clinician picker's names for the page
                           (PAGE_OPTIONS: const OPTIONS = {...};); --example-people: stand-in names
  search --line "SHIFTMATE_SEARCH start=...; end=...; clinician=...; sites=...; times=...; days=...; kinds=...;
         levels=...; roles=..." [--group BY] [--sort BY] [--all] [--ics FILE]
"""
import argparse, csv, json, os, re, sys
from datetime import date, datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import shiftmate as sm  # noqa: E402

VERSION = "0.01.82"
PAGE = os.path.join(sm.SKILL_DIR, "assets", "shift-search.html")
DENSITY_MAX = 20    # more results than this: suggest a layout before listing (brief 2, Results)
LIST_MAX = 200      # more than this even grouped: counts per group only, unless --all
MARK = "SHIFTMATE_SEARCH"
CLIN_SEP = "|"      # several clinicians in the clinician field: Alex Example|Jamie Trial (any of them)
FIELDS = ("start", "end", "clinician", "sites", "times", "days", "kinds", "levels", "roles")
LIST_FIELDS = ("days", "times", "sites", "levels", "roles", "kinds")   # the page's row order
GROUPS = ("date", "week", "site", "time", "clinician", "kind", "level", "role")
SORTS = ("date", "site", "clinician")
NOT_ON_ROSTER = "Not on roster"

# Times of day and day kinds follow the engine's shift times (shiftmate.time_cat, base_cat, HOL_TIMES):
# day 05:30-15:59, evening 16:00-21:59, overnight 22:00-05:29 (a shift starting before 05:30 belongs to the day
# before); Mon-Thu, Friday and weekend as the engine splits evenings and overnights; a holiday shift is only "holiday".
TIMES = [("day", "Day", "starts 05:30-15:59"), ("evening", "Evening", "starts 16:00-21:59"),
         ("overnight", "Overnight", "starts 22:00-05:29")]
DAYS = [("mon-thu", "Mon-Thu", ""), ("friday", "Friday", ""), ("weekend", "Weekend", "Sat-Sun"),
        ("holiday", "Holiday", "division holidays")]
KINDS = [("regular", "Regular", ""), ("ml", "Moonlighting (ML)", "")]
LEVEL_TOKEN = {"C": "CL", "C*": "CL*"}   # engine level -> the level name administrators use
LEVEL_ORDER = ["F", "CL*", "CL", "E", "SrAPP", "Jeop F", "Jeop CL", "Jeop APP"]


def out(line=""):
    print(line)


def stop(line, code=2):
    print(line)
    sys.exit(code)


def fmt_d(d):
    return f"{d:%m/%d/%y}"


# ---------------------------------------------------------------- options (from the engine's data)
def level_token(s):
    if s.is_jeop:
        return f"Jeop {s.level}" if s.level else "Jeop"
    return LEVEL_TOKEN.get(s.level, s.level or "?")


def csv_rows(fn):
    return sm.read_csv(fn)


def options(shifts=None):
    """The page's option lists: sites and levels from data/shift_codes.csv (plus any seen in the schedule),
    roles from data/roles.csv, times of day and day kinds from the engine's shift-time rules."""
    codes = csv_rows("shift_codes.csv")
    seen_sites = {r.get("site", "").strip() for r in codes}
    levels = set()
    for r in codes:
        lv = (r.get("level") or "").strip()
        if not lv:
            continue
        levels.add(f"Jeop {lv}" if r.get("location_type") == "JEOP" else LEVEL_TOKEN.get(lv, lv))
    for s in shifts or []:
        seen_sites.add(s.site)
        levels.add(level_token(s))
    sites = [x for x in sm.ALL_SITES + ["Jeopardy"] if x in seen_sites]
    sites += sorted(x for x in seen_sites if x and x not in sites)
    lv = [x for x in LEVEL_ORDER if x in levels] + sorted(x for x in levels if x not in LEVEL_ORDER and x != "?")
    roles = []
    for r in csv_rows("roles.csv"):
        k = r["role"].strip()
        if k and k not in roles:
            roles.append(k)
    roles.append(NOT_ON_ROSTER)
    opt = {"today": sm.now().date().isoformat(),
           "sites": [{"key": x, "label": x} for x in sites],
           "times": [{"key": k, "label": l, "hint": h} for k, l, h in TIMES],
           "days": [{"key": k, "label": l, "hint": h} for k, l, h in DAYS],
           "kinds": [{"key": k, "label": l} for k, l, _ in KINDS],
           "levels": [{"key": x, "label": sm.level_label(x) if x == "SrAPP" else x} for x in lv],
           "roles": [{"key": x, "label": x} for x in roles]}
    if shifts:
        opt["schedule"] = {"first": min(s.sdate for s in shifts).isoformat(),
                           "last": max(s.sdate for s in shifts).isoformat()}
    return opt


EXAMPLE_PEOPLE = [   # --example-people: stand-ins for previews and demos kept outside the division (no roster data)
    ("Alex Example", "Faculty", "Example, A"), ("Jordan Example", "Clinical Staff", "Example, J"),
    ("Casey Example", "Senior APP", "Example, C; Case"), ("Sam Sample", "APP", "Sample, S; Sammy"),
    ("Riley Sample", "Senior Clinical Staff", "Sample, R"), ("Taylor Test", "Fellow Y2, PGY-5", "Test, T"),
    ("Quinn Tester", "Moonlighter", "Tester, Q"), ("Jamie Trial", "Faculty", "Trial, J; Jim"),
]


def people_list(shifts=None, example=False):
    """The clinician picker's list: every roster name with its role (and the names ShiftAdmin, aliases and the
    preferred name use, for matching what's typed), plus names that are on the schedule but not the roster.
    Names and roles only: no contact details. Only in the filled scratch copy; the shipped page holds none."""
    if example:
        return [{"name": n, "role": r, "keys": k} for n, r, k in EXAMPLE_PEOPLE]
    people, by_sched = sm.load_roster()
    unknown = []
    if shifts:
        raw = {s.id: s.who for s in shifts if isinstance(s.who, str)}
        sm.attach(shifts, people, by_sched)
        unknown = sorted({raw[s.id] for s in shifts if s.who is None and s.id in raw})
    out = []
    for p in sorted(people, key=lambda p: sm.nkey(p.schedule_name)):
        keys = [p.schedule_name, getattr(p, "preferred_name", "") or ""] + [a for a in (p.aliases or "").split(";")]
        out.append({"name": p.name, "role": sm.role_label(p),
                    "keys": "; ".join(k.strip() for k in keys if k and k.strip() and k.strip() != p.name)})
    out += [{"name": n, "role": "not on roster", "keys": ""} for n in unknown]
    return out


def page_options(a):
    shifts = maybe_shifts(a.ics)
    opt = options(shifts)
    opt["people"] = people_list(shifts, example=a.example_people)
    return opt


def maybe_shifts(ics):
    """The schedule for the page's date hints, only when it's already at hand (attached file or cached copy):
    opening the page never waits on a download."""
    if ics or os.path.exists(os.path.join(sm.WORK, "feed.ics")) or sm.demo_active():
        try:
            return sm.load_feed(ics, quiet=True)[0]
        except SystemExit:
            return None
    return None


def options_js(opt):
    return "const OPTIONS = " + json.dumps(opt, separators=(",", ":")) + ";"


def cmd_page_data(a):
    out("PAGE_OPTIONS: " + options_js(page_options(a)))


def cmd_page(a):
    html = open(PAGE, encoding="utf-8").read()
    if "const OPTIONS = null;" not in html:
        stop("ERROR: assets/shift-search.html has no `const OPTIONS = null;` line to fill. Send feedback.")
    html = html.replace("const OPTIONS = null;", options_js(page_options(a)), 1)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    open(a.out, "w", encoding="utf-8").write(html)
    out(f"PAGE_READY: {a.out}")


# ---------------------------------------------------------------- the pasted line
MONTHS = {m: i + 1 for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct",
                                            "nov", "dec"])}


def parse_date(txt, today):
    """ISO (what the page sends), or what an administrator might type in the chat: 10/5, 10/5/26, Oct 5, today."""
    t = txt.strip().lower().rstrip(".")
    if t in ("", "all"):
        return None
    if t == "today":
        return today
    if t == "tomorrow":
        return today + timedelta(days=1)
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", t)
    if m:
        return date(int(m[1]), int(m[2]), int(m[3]))
    m = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2}|\d{4}))?", t)
    if m:
        y = m[3]
        if y:
            return date(int(y) + (2000 if len(y) == 2 else 0), int(m[1]), int(m[2]))
        return infer_year(int(m[1]), int(m[2]), today)
    m = re.fullmatch(r"(?:[a-z]+,?\s+)?([a-z]{3})[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s+(\d{4}))?", t)
    if m and m[1] in MONTHS:
        if m[3]:
            return date(int(m[3]), MONTHS[m[1]], int(m[2]))
        return infer_year(MONTHS[m[1]], int(m[2]), today)
    raise ValueError(txt)


def infer_year(mo, d, today):
    """No year typed: this year, unless that's more than 60 days ago (then next year: schedules look ahead)."""
    x = date(today.year, mo, d)
    return date(today.year + 1, mo, d) if (today - x).days > 60 else x


def norm_values(field, raw, opt):
    """Split a list field and map each value to its option key (case and spacing forgiven). Returns (keys, bad)."""
    vals = [v.strip() for v in raw.split(",") if v.strip()]
    if not vals or any(v.lower() in ("all", "any") for v in vals):
        return [], []
    keys = [o["key"] for o in opt[field]]
    by = {}
    for o in opt[field]:
        for form in (o["key"], o["label"]):
            by[re.sub(r"[^a-z0-9*]", "", form.lower())] = o["key"]
    got, bad = [], []
    for v in vals:
        k = by.get(re.sub(r"[^a-z0-9*]", "", v.lower()))
        if k is None and field == "sites":
            k = site_word(v)
            k = k if k in keys else None
        if k is None and field == "levels" and v.upper() in ("C", "C*"):
            k = LEVEL_TOKEN[v.upper()]
        if k is None and field == "roles" and v.lower().startswith("fellow"):
            k = "Fellow"
        if k is None:
            bad.append(v)
        elif k not in got:
            got.append(k)
    return got, bad


def site_word(v):
    """A site as an administrator might type it: the engine's names and aliases, plus "Liberty ED", "Burnet UC"."""
    k = re.sub(r"[^A-Z]", "", v.upper())
    for pre, ed, uc in (("LIBERTY", "Lib ED", "LT UC"), ("LIB", "Lib ED", "LT UC"), ("LT", "Lib ED", "LT UC"),
                        ("BURNET", "B ED", "BUC"), ("B", "B ED", "BUC")):
        if k == pre + "ED":
            return ed
        if k in (pre + "UC", pre + "URGENTCARE"):
            return uc
    return sm.norm_site(v)


def parse_line(line, opt, today):
    t = (line or "").strip().strip("`").strip()
    i = t.find(MARK)
    if i < 0:
        stop(f"BAD_LINE: the line doesn't start with {MARK}. Ask them to press Search in the page again and paste "
             "the whole line.")
    body = t[i + len(MARK):].strip()
    crit, unknown = {k: "" for k in FIELDS}, []
    for part in body.split(";"):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            stop(f"BAD_LINE: can't read '{part}' (each part is name=value). Ask them to press Search again and paste "
                 "the whole line.")
        k, v = part.split("=", 1)
        k = k.strip().lower()
        if k not in FIELDS:
            unknown.append(k)
            continue
        crit[k] = v.strip()
    if unknown:
        stop("BAD_LINE: unknown field(s) " + ", ".join(unknown) + f". Known fields: {', '.join(FIELDS)}.")
    bad = []
    for f in LIST_FIELDS:
        crit[f], b = norm_values(f, crit[f], opt)
        bad += [f"{f}={x}" for x in b]
    if bad:
        stop("UNKNOWN_VALUE: " + "; ".join(bad) + ". Say which choice wasn't recognized and ask them to press Search "
             "in the page again (or pick from: " + "; ".join(
                 f"{f} " + ", ".join(o['key'] for o in opt[f]) for f in LIST_FIELDS
                 if any(x.startswith(f + '=') for x in bad)) + ").")
    for f in ("start", "end"):
        raw = crit[f]
        try:
            crit[f] = parse_date(raw, today)
        except ValueError:
            stop(f"BAD_DATE: {f} date '{raw}' isn't a date I can read. Ask for it again (for example 10/05/26 or "
                 "2026-10-05).")
        except Exception:
            stop(f"BAD_DATE: {f} date '{raw}' isn't a real date. Ask for it again.")
    names = []   # one or more clinicians, separated by "|" (OR); a name never holds "|"
    for n in crit["clinician"].split(CLIN_SEP):
        n = re.sub(r"\s+", " ", n).strip()
        if n and n.lower() not in ("all", "any", "anyone", "everyone") and n not in names:
            names.append(n)
    crit["clinician"] = names
    return crit


# ---------------------------------------------------------------- matching
def day_kind(s):
    if s.hol == "HOL":
        return "holiday"
    wd = s.sdate.weekday()
    return "mon-thu" if wd <= 3 else ("friday" if wd == 4 else "weekend")


def kind_of(s):
    return "ml" if s.is_ml else "regular"


def role_of(s):
    return s.who.role if s.who is not None else NOT_ON_ROSTER


def name_of(s, raw):
    return s.who.name if s.who is not None else raw.get(s.id, "?")


def who_text(s, raw):
    if s.who is None:
        return f"{raw.get(s.id, '?')} (not on roster)"
    return f"{s.who.name} ({sm.role_label(s.who, s.sdate)})"


def match_clinicians(people, shifts, raw, names):
    """Each name matched in turn; the first name problem stops the search with its line (the others are fine)."""
    return [match_clinician(people, shifts, raw, n, several=len(names) > 1) for n in names]


def match_clinician(people, shifts, raw, name, several=False):
    """Returns ("person", p) or ("raw", schedule name) for someone on the schedule but not the roster.
    Name problems print their line and stop, as whoami does (never a silent partial match)."""
    again = ("search again with that exact name in its place (keep the other names)" if several
             else "search again with that exact name")
    hits = sm.find_person(people, name)
    if len(hits) == 1:
        p = hits[0]
        if not sm.whole_word_match(p, name):
            stop(f"DID_YOU_MEAN: {p.name} ({sm.role_label(p)})? '{name}' isn't an exact match. Ask (Yes / No); after a "
                 f"yes, {again}.", 0)
        return "person", p
    if len(hits) > 1:
        stop("AMBIGUOUS: '" + name + "' matches " + "; ".join(f"{p.name} ({sm.role_label(p)})" for p in hits[:6])
             + ". Ask which one, with one button per name (at most 4; more: ask them to type more of the name).", 0)
    close = [p for p in people if sm.name_close(p, name)]
    if close:
        stop("DID_YOU_MEAN: " + "; ".join(f"{p.name} ({sm.role_label(p)})" for p in close[:3]) + f"? '{name}' isn't on "
             f"the roster. Ask with one button per name plus 'None of these'; after a yes, {again}.", 0)
    k = sm.nkey(name)
    names = sorted({raw[s.id] for s in shifts if s.who is None and k and k in sm.nkey(raw.get(s.id, ""))})
    if len(names) == 1:
        return "raw", names[0]
    stop(f"NO_MATCH: '{name}' isn't on the roster or the schedule. Ask them to check the spelling, or search "
         + ("without that name." if several else "without a clinician."), 0)


def filters(crit, who):
    """The active filters as (field, test) pairs, in the order NO_RESULTS names them."""
    fs = []
    if crit["start"] or crit["end"]:
        lo, hi = crit["start"], crit["end"]
        fs.append(("dates", lambda s, r: (lo is None or s.sdate >= lo) and (hi is None or s.sdate <= hi)))
    if who:   # any of the clinicians
        people = {id(x) for kind, x in who if kind == "person"}
        rawn = {x for kind, x in who if kind == "raw"}
        fs.append(("clinician", lambda s, r: (s.who is not None and id(s.who) in people)
                   or (s.who is None and r.get(s.id) in rawn)))
    tests = {"sites": lambda s: s.site, "times": lambda s: s.tc, "days": day_kind, "kinds": kind_of,
             "levels": level_token, "roles": role_of}
    for f in LIST_FIELDS:
        if crit[f]:
            want, get = set(crit[f]), tests[f]
            fs.append((f, lambda s, r, want=want, get=get: get(s) in want))
    return fs


def apply(shifts, fs, raw, skip=None):
    return [s for s in shifts if all(t(s, raw) for f, t in fs if f != skip)]


# ---------------------------------------------------------------- layout
def site_idx(s):
    order = sm.ALL_SITES + ["Jeopardy"]
    return order.index(s.site) if s.site in order else 99


def sort_key(by, raw):
    if by == "site":
        return lambda s: (site_idx(s), s.start, name_of(s, raw))
    if by == "clinician":
        return lambda s: (sched_key(s, raw), s.start)
    return lambda s: (s.start, site_idx(s), name_of(s, raw))


def sched_key(s, raw):
    return sm.nkey(s.who.schedule_name if s.who is not None else raw.get(s.id, ""))


def week_of(d):
    return d - timedelta(days=d.weekday())


def group_key(by, raw):
    """(sort key, label) of the group a shift belongs to."""
    kinds = {k: l for k, l, _ in KINDS}
    return {
        "date": lambda s: (s.sdate, f"{s.sdate:%a %m/%d/%y}"),
        "week": lambda s: (week_of(s.sdate), f"Week of Mon {week_of(s.sdate):%m/%d/%y}"),
        "site": lambda s: (site_idx(s), s.site),
        "time": lambda s: (sm.TIME_IDX[s.tc], {k: l for k, l, _ in TIMES}[s.tc]),
        "clinician": lambda s: (sched_key(s, raw), who_text(s, raw)),
        "kind": lambda s: (kind_of(s), kinds[kind_of(s)]),
        "level": lambda s: (LEVEL_ORDER.index(level_token(s)) if level_token(s) in LEVEL_ORDER else 99, level_token(s)),
        "role": lambda s: (role_of(s), role_of(s)),
    }[by]


def groups(rows, by, raw):
    g = {}
    gk = group_key(by, raw)
    for s in rows:
        k, label = gk(s)
        g.setdefault((k, label), []).append(s)
    return [(label, g[(k, label)]) for k, label in sorted(g, key=lambda x: x[0])]


READABLE = {"date": (2, 14), "site": (2, 10), "week": (2, 8), "clinician": (2, 12), "level": (2, 8), "kind": (2, 8),
            "role": (2, 8), "time": (2, 3)}   # group counts that read well in the chat, per layout


def suggest(rows, crit, raw):
    """The layout to offer first: the first in a fixed preference order (date, site, week, clinician, level, kind,
    role, time of day) whose group count reads well (READABLE), else the one closest to 8 groups. A dimension the search already
    fixed to one value (one group) is never offered."""
    cands = [by for by in ("date", "site", "week", "clinician", "level", "kind", "role", "time")
             if not (by == "clinician" and len(crit["clinician"]) == 1)]
    counts = {by: len(groups(rows, by, raw)) for by in cands}
    useful = [by for by in cands if counts[by] > 1]
    for by in useful:
        lo, hi = READABLE[by]
        if lo <= counts[by] <= hi:
            return by, useful, counts
    best = min(useful or cands, key=lambda by: (abs(counts[by] - 8), cands.index(by)))
    return best, useful, counts


def shift_text(s, raw, omit=None):
    bits = []
    if omit not in ("date", "week"):
        bits.append(f"{s.sdate:%a %m/%d}")
    elif omit == "week":
        bits.append(f"{s.sdate:%a %m/%d}")
    if omit != "site":
        bits.append(s.site)
    bits.append(s.code)
    bits.append(f"{s.start:%H%M}-{s.end:%H%M}")
    if omit != "clinician":
        bits.append(who_text(s, raw))
    bits.append(f"#{s.id}")
    line = " · ".join(bits)
    tags = []
    if s.hol == "HOL":
        tags.append(f"[holiday: {s.hol_name}]")
    elif s.hol == "PERI":
        tags.append("[peri-holiday]")
    if s.is_ml:
        tags.append("[ML]")
    if s.buddy:
        tags.append("[buddy shift]")
    return line + (" " + " ".join(tags) if tags else "")


def summary(crit, who, first, last):
    lo = crit["start"] or first
    hi = crit["end"] or last
    parts = [f"{fmt_d(lo)} to {fmt_d(hi)}" + ("" if crit["end"] else " (end of schedule)")]
    if who:
        names = [x.name if kind == "person" else f"{x} (not on roster)" for kind, x in who]
        parts.append(("clinician " if len(names) == 1 else "clinicians ") + " or ".join(names))
    else:
        parts.append("clinician any")
    names = {"sites": "sites", "times": "times", "days": "days", "kinds": "kinds", "levels": "levels", "roles": "roles"}
    for f in LIST_FIELDS:
        parts.append(f"{names[f]} " + (", ".join(crit[f]) if crit[f] else "all"))
    return "SEARCH: " + " · ".join(parts)


# ---------------------------------------------------------------- search
def require_ready():
    sm.require_unlocked()
    if sm.RELEASE and not os.path.exists(sm.STARTUP_DONE):
        stop("STARTUP_FIRST: run `startup` and finish its checklist first (SKILL.md, Startup), then repeat this "
             "command. Whatever the first message asked for is kept for afterwards.", 4)


def cmd_search(a):
    shifts, src = sm.load_feed(a.ics, quiet=True)
    raw = {s.id: s.who for s in shifts}   # schedule names, kept for people the roster doesn't have
    people, by_sched = sm.load_roster()
    sm.attach(shifts, people, by_sched)
    today = sm.now().date()
    opt = options(shifts)
    crit = parse_line(a.line, opt, today)
    first, last = min(s.sdate for s in shifts), max(s.sdate for s in shifts)
    if crit["start"] is None:
        crit["start"] = today
    if crit["end"] and crit["start"] > crit["end"]:
        stop(f"BAD_RANGE: the start date {fmt_d(crit['start'])} is after the end date {fmt_d(crit['end'])}. Ask for the "
             "dates again.")
    if crit["end"] and crit["end"] < first:
        stop(f"PAST_DATES: the schedule holds shifts from {fmt_d(first)} to {fmt_d(last)}; {fmt_d(crit['start'])} to "
             f"{fmt_d(crit['end'])} is before it. Ask for dates from {fmt_d(first)} on.")
    notes = []
    if crit["start"] < first:
        notes.append(f"NOTE: the schedule holds shifts from {fmt_d(first)}; earlier dates aren't in it.")
    if crit["start"] < today:
        notes.append(f"NOTE: dates before today ({fmt_d(today)}) are past shifts, as the schedule shows them now.")
    if crit["end"] and crit["end"] > last:
        notes.append(f"NOTE: the schedule runs to {fmt_d(last)}; later dates aren't scheduled yet.")
    who = match_clinicians(people, shifts, raw, crit["clinician"]) if crit["clinician"] else None
    fs = filters(crit, who)
    rows = apply(shifts, fs, raw)
    out(summary(crit, who, first, last))
    if crit["start"] > last:
        out(f"NO_RESULTS: the schedule runs to {fmt_d(last)}; nothing is scheduled from {fmt_d(crit['start'])} yet. "
            "Offer dates up to then.")
        sm.print_feedback()
        return
    for n in notes:
        out(n)
    if not rows:
        best = None   # the filter whose removal alone brings shifts back; the clinician only when nothing else does
        for pass_ in ("other", "clinician"):
            for f, _ in fs:
                if f == "dates" or (f == "clinician") != (pass_ == "clinician"):
                    continue
                n = len(apply(shifts, fs, raw, skip=f))
                if n and (best is None or n > best[1]):
                    best = (f, n)
            if best:
                break
        why = (f" Without the {best[0]} filter there would be {best[1]}." if best else "")
        out(f"NO_RESULTS: no shifts match.{why} Offer to widen that filter or change the dates.")
        sm.print_feedback()
        return
    out(f"FOUND: {len(rows)} shift{'s' if len(rows) != 1 else ''}.")
    by = a.group
    if by is None and len(rows) > DENSITY_MAX:
        best, useful, counts = suggest(rows, crit, raw)
        others = [x for x in useful if x != best] + (["none"] if len(rows) <= LIST_MAX else [])
        big = (f" Over {LIST_MAX} is too many to list in the chat even grouped: suggest narrowing first (one site, "
               "fewer choices or a shorter date range); a layout then shows only the counts per group."
               if len(rows) > LIST_MAX else "")
        out(f"DENSITY: {len(rows)} results (over {DENSITY_MAX}). Suggested layout: {best}. Other layouts: "
            + ", ".join(others) + ". Ask which layout (the suggested one first), then run again with --group <layout>."
            + big)
        out(f"GROUPS ({best}): " + "; ".join(f"{label} {len(g)}" for label, g in groups(rows, best, raw)))
        sm.print_feedback()
        return
    by = by or "date"
    if by == "none":
        rows.sort(key=sort_key(a.sort or "date", raw))
        if len(rows) > LIST_MAX and not a.all:
            out(f"TOO_MANY: {len(rows)} shifts is too many to list in the chat. Suggest a grouped layout or narrower "
                "filters (run again with --all to list them anyway).")
        else:
            out(f"LIST (none, sorted by {a.sort or 'date'}):")
            for s in rows:
                out("  - " + shift_text(s, raw))
        sm.print_feedback()
        return
    gs = groups(rows, by, raw)
    if len(rows) > LIST_MAX and not a.all:
        out(f"GROUPS ({by}): " + "; ".join(f"{label} {len(g)}" for label, g in gs))
        out(f"TOO_MANY: {len(rows)} shifts is too many to list in the chat. Show the group counts above and suggest "
            "narrower filters (for example one site or a shorter date range); run again with --all to list them anyway.")
        sm.print_feedback()
        return
    out(f"LIST ({by}):")
    for label, g in gs:
        out(f"GROUP: {label} ({len(g)})")
        for s in sorted(g, key=sort_key(a.sort or ("site" if by == "date" else "date"), raw)):
            out("  - " + shift_text(s, raw, omit=by))
    sm.print_feedback()


def main(argv=None):
    ap = argparse.ArgumentParser(prog="schedule_search.py", description=__doc__.split("\n\n")[0])
    ap.add_argument("--local-data", help=argparse.SUPPRESS)   # accepted like shiftmate.py; Shift Search saves nothing
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("page", help="write the side-panel page with its option lists filled in")
    p.add_argument("--out", required=True)
    p.add_argument("--ics")
    p.add_argument("--example-people", action="store_true", help="stand-in names instead of the roster (previews)")
    p = sub.add_parser("page-data", help="print the option lists for the page")
    p.add_argument("--ics")
    p.add_argument("--example-people", action="store_true", help="stand-in names instead of the roster (previews)")
    p = sub.add_parser("search", help="run a pasted SHIFTMATE_SEARCH line")
    p.add_argument("--line", required=True)
    p.add_argument("--group", choices=GROUPS + ("none",))
    p.add_argument("--sort", choices=SORTS)
    p.add_argument("--all", action="store_true", help="list every shift even past the chat limit")
    p.add_argument("--ics")
    a = ap.parse_args(argv)
    require_ready()
    {"page": cmd_page, "page-data": cmd_page_data, "search": cmd_search}[a.cmd](a)


if __name__ == "__main__":
    main()
