"""Local Data folder for CinciPEM ShiftMate (plan 6.7, 6.10).

Keeps the skill's settings, feedback and logs as many small encrypted files in
"<Skill name> Local Data/" on the user's computer, instead of Claude memory.
Standard library plus securebundle (same scrypt key derivation and AES-CTR + HMAC
helpers; the faster `cryptography` library is used when present).

Encrypted file layout:
  MAGIC (6) | nonce (16) | AES-256-CTR(body) | HMAC-SHA256 tag (32)
  body = JSON {"counter": n, "kind": "json"|"text", "data": ...}
  keys = scrypt(passphrase, live/system/key-salt) -> 32-byte cipher key + 32-byte MAC key
Unencrypted (nothing personal): README.txt, */system/format.json, live/system/key-salt.
lockout.json is encrypted with a key built into this script (readable before the
passphrase) and has a tamper check: unreadable or edited counts as a full 24 h lockout.
"""
import hashlib, hmac, json, os, sys, tempfile, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import securebundle as SB

VERSION = "0.01.08"

MAGIC = b"CPLD1\n"
LOCK_MAGIC = b"CPLK1\n"
FORMAT_VERSION = 1
SKILL_NAME = "CinciPEM ShiftMate"
FOLDER_NAME = SKILL_NAME + " Local Data"
KEY_FILE = "shiftmate-localdata.key"
LOCKOUT_SECONDS = 24 * 3600
SENT_KEEP_DAYS = 365
# Built-in key for lockout.json: stops casual editing, not someone who reads this script.
_LOCK_KEY = hashlib.sha512(b"CinciPEM ShiftMate lockout.json built-in key v1").digest()

SUBDIRS = [
    "system", "system/lib", "system/sessions/open", "system/sessions/closed",
    "profile", "preferences", "blocked-dates", "clinicians",
    "schedule/drop-in", "schedule/cache", "requests",
    "feedback/outbox", "feedback/sent", "feedback/downloads",
    "logs/usage", "logs/timing", "logs/health", "previous-settings",
]
TESTING_EXTRA = ["backup", "results", "archive"]
PLAIN_FILES = {"system/format.json", "system/key-salt"}

README = """This is the {name} Local Data folder.

The {name} skill keeps your settings, feedback and usage logs here, in small
encrypted files, instead of in Claude's memory. Ask the skill to show your saved
settings; the files themselves can't be read in a text editor.

live/     everyday use
testing/  test mode only

Nothing personal is stored unencrypted. Please don't edit or move files by hand.
"""


class LocalDataError(Exception):
    pass


class BadKey(LocalDataError):
    """Wrong passphrase, or a file that was edited or damaged."""


class NoKey(LocalDataError):
    pass


class RefusedFolder(LocalDataError):
    pass


def _is_skill_folder(d):
    """True when d holds the skill's own files or is a build folder."""
    return (os.path.isfile(os.path.join(d, "SKILL.md"))
            or os.path.isfile(os.path.join(d, "scripts", "shiftmate.py"))
            or os.path.isfile(os.path.join(d, "cincipem-shiftmate", "SKILL.md"))
            or os.path.isfile(os.path.join(d, "tools", "release.py")))


def check_root(root, build_dir=None, walk=True):
    """Raise RefusedFolder if root is inside the build folder or holds skill files (plan 6.7). walk=False (a Local Data
    tree that already exists, so it passed this check when it was made) skips the per-folder look up to the drive root,
    which is slow on a synced (OneDrive) folder."""
    r = os.path.realpath(root)
    here = os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    avoid = [here] + ([os.path.realpath(build_dir)] if build_dir else [])
    for a in avoid:
        if r == a or r.startswith(a.rstrip(os.sep) + os.sep):
            raise RefusedFolder("the Local Data folder can't be inside the build or skill folder: " + a)
    if not walk:
        return r
    d = r
    while True:
        if _is_skill_folder(d):
            raise RefusedFolder("the Local Data folder can't hold or sit inside the skill's own files: " + d)
        up = os.path.dirname(d)
        if up == d:
            return r
        d = up


def _seal(ek, mk, magic, payload):
    nonce = os.urandom(16)
    body = SB._ctr(ek, nonce, payload)
    head = magic + nonce
    return head + body + hmac.new(mk, head + body, hashlib.sha256).digest()


def _open(ek, mk, magic, blob):
    if not blob.startswith(magic) or len(blob) < len(magic) + 16 + 32:
        raise BadKey("not a Local Data file, or damaged")
    head, body, tag = blob[:len(magic) + 16], blob[len(magic) + 16:-32], blob[-32:]
    if not hmac.compare_digest(tag, hmac.new(mk, head + body, hashlib.sha256).digest()):
        raise BadKey("wrong passphrase, or the file was edited or damaged")
    return SB._ctr(ek, head[len(magic):], body)


def _atomic_write(path, data):
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=d)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


class LocalData:
    def __init__(self, root, mode="live", build_dir=None, create=True):
        if mode not in ("live", "testing"):
            raise ValueError("mode must be live or testing")
        # fast open (C: 1.3 s on a OneDrive folder): when the tree already exists (its marker files are there), skip the
        # folder walk and the ~40 folder checks; missing folders are made when a file is first written into them
        ready = all(os.path.isfile(os.path.join(root, *x)) for x in (
            ("live", "system", "format.json"), ("live", "system", "key-salt"), (mode, "system", "format.json")))
        self.root = check_root(root, build_dir, walk=not ready)
        self.mode = mode
        self.base = os.path.join(self.root, mode)
        self._ek = self._mk = None
        self._seen = {}          # rel path -> counter this process last read or wrote
        self.health_notes = []   # notes for logs/health when the key isn't loaded yet
        if create and not ready:
            self.ensure_tree()

    # ---- folder layout
    def ensure_tree(self):
        os.makedirs(self.root, exist_ok=True)
        rd = os.path.join(self.root, "README.txt")
        if not os.path.exists(rd):
            _atomic_write(rd, README.format(name=SKILL_NAME).encode())
        for m in ("live", "testing"):
            for s in SUBDIRS + (TESTING_EXTRA if m == "testing" else []):
                os.makedirs(os.path.join(self.root, m, s), exist_ok=True)
            fmt = os.path.join(self.root, m, "system", "format.json")
            if not os.path.exists(fmt):
                _atomic_write(fmt, json.dumps({"format": FORMAT_VERSION, "skill_version": VERSION,
                                               "channel": None, "mode": m}, indent=1).encode())
        salt = self._salt_path()
        if not os.path.exists(salt):
            _atomic_write(salt, os.urandom(16).hex().encode())

    def _salt_path(self):
        return os.path.join(self.root, "live", "system", "key-salt")

    def read_format(self):
        with open(os.path.join(self.base, "system", "format.json")) as f:
            return json.load(f)

    def write_format(self, **fields):
        d = self.read_format()
        d.update(fields)
        _atomic_write(os.path.join(self.base, "system", "format.json"), json.dumps(d, indent=1).encode())
        return d

    @staticmethod
    def is_local_data_folder(root):
        """The "I already have one" check: a real Local Data folder has live/system/format.json."""
        try:
            with open(os.path.join(root, "live", "system", "format.json")) as f:
                return isinstance(json.load(f).get("format"), int)
        except (OSError, ValueError, AttributeError):
            return False

    # ---- key
    def derive_key(self, passphrase):
        """Make the key from the passphrase and key-salt (about 0.4 s; once per chat).
        The first time, writes system/key-check; later, a wrong passphrase raises BadKey."""
        with open(self._salt_path()) as f:
            salt = bytes.fromhex(f.read().strip())
        ek, mk = SB._keys(passphrase, salt, SB.LOG2_N)
        self._set_key(ek, mk)

    def _set_key(self, ek, mk):
        chk = os.path.join(self.root, "live", "system", "key-check")
        if os.path.exists(chk):
            with open(chk, "rb") as f:
                if _open(ek, mk, MAGIC, f.read()) != b"CinciPEM Local Data key check":
                    raise BadKey("wrong passphrase")
        else:
            _atomic_write(chk, _seal(ek, mk, MAGIC, b"CinciPEM Local Data key check"))
        self._ek, self._mk = ek, mk

    def has_key(self):
        return self._ek is not None

    def save_key(self, workdir):
        """Keep the key in the chat's temp work folder so later runs skip the passphrase."""
        if not self.has_key():
            raise NoKey("no key yet")
        os.makedirs(workdir, exist_ok=True)
        p = os.path.join(workdir, KEY_FILE)
        with open(self._salt_path()) as f:
            salt = f.read().strip()
        data = json.dumps({"root": self.root, "salt": salt, "key": (self._ek + self._mk).hex()}).encode()
        fd = os.open(p + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(p + ".tmp", p)
        return p

    def load_key(self, workdir):
        """Returns True if a key saved for this folder (and salt) was found and works."""
        try:
            with open(os.path.join(workdir, KEY_FILE)) as f:
                d = json.load(f)
            with open(self._salt_path()) as f:
                salt = f.read().strip()
            if d.get("root") != self.root or d.get("salt") != salt:
                return False
            k = bytes.fromhex(d["key"])
            self._set_key(k[:32], k[32:])
            return True
        except (OSError, ValueError, KeyError, BadKey):
            return False

    # ---- encrypted files
    def _path(self, rel):
        rel = rel.replace("\\", "/").strip("/")
        if not rel or os.path.isabs(rel) or ".." in rel.split("/"):
            raise LocalDataError("bad path: " + rel)
        return rel, os.path.join(self.base, *rel.split("/"))

    def _need_key(self):
        if not self.has_key():
            raise NoKey("the passphrase key isn't loaded (derive_key or load_key first)")

    def _load(self, full):
        with open(full, "rb") as f:
            return json.loads(_open(self._ek, self._mk, MAGIC, f.read()).decode())

    def exists(self, rel):
        return os.path.isfile(self._path(rel)[1])

    def read(self, rel, default=None):
        """Decrypt one file: returns the dict/list/str written, or default if it doesn't exist.
        Raises BadKey for a wrong key or an edited file."""
        self._need_key()
        rel, full = self._path(rel)
        if not os.path.isfile(full):
            self._seen[rel] = 0
            return default
        d = self._load(full)
        self._seen[rel] = d["counter"]
        return d["data"]

    def counter(self, rel):
        self._need_key()
        rel, full = self._path(rel)
        return self._load(full)["counter"] if os.path.isfile(full) else 0

    def write(self, rel, obj, force=False):
        """Encrypt and save atomically. Refuses (returns a CONFLICT result, writes nothing)
        if another process changed the file since this one read it, unless force.
        Returns {"ok": True, "counter": n} or
        {"ok": False, "status": "CONFLICT", "path": rel, "read_counter": a, "file_counter": b}."""
        self._need_key()
        rel, full = self._path(rel)
        if rel in PLAIN_FILES or rel == "system/lockout.json":
            raise LocalDataError("not written with write(): " + rel)
        with _FileLock(full):
            cur = self._load(full)["counter"] if os.path.isfile(full) else 0
            seen = self._seen.get(rel, 0 if not os.path.isfile(full) else None)
            if not force and seen != cur:
                return {"ok": False, "status": "CONFLICT", "path": rel,
                        "read_counter": seen, "file_counter": cur}
            n = cur + 1
            kind = "text" if isinstance(obj, str) else "json"
            payload = json.dumps({"counter": n, "kind": kind, "data": obj}).encode()
            _atomic_write(full, _seal(self._ek, self._mk, MAGIC, payload))
            self._seen[rel] = n
        return {"ok": True, "counter": n}

    def delete(self, rel):
        rel, full = self._path(rel)
        if os.path.isfile(full):
            os.unlink(full)
            self._seen.pop(rel, None)
            return True
        return False

    def list(self, subdir=""):
        """Relative paths of the files under subdir (not temp or lock files)."""
        top = self._path(subdir)[1] if subdir else self.base
        out = []
        for d, dirs, fs in os.walk(top):
            dirs.sort()
            for f in sorted(fs):
                if f.startswith(".tmp-") or f.endswith(".lock"):
                    continue
                out.append(os.path.relpath(os.path.join(d, f), self.base).replace(os.sep, "/"))
        return out

    def list_older(self, subdir, days, now=None):
        cut = (now or time.time()) - days * 86400
        return [r for r in self.list(subdir) if os.path.getmtime(self._path(r)[1]) < cut]

    def delete_older(self, subdir, days, now=None):
        old = self.list_older(subdir, days, now)
        for r in old:
            self.delete(r)
        return old

    def prune_sent(self, now=None):
        """Sent feedback is removed once it's over a year old (plan 6.7)."""
        return self.delete_older("feedback/sent", SENT_KEEP_DAYS, now)

    # ---- lockout.json (built-in key, tamper check)
    def _lockout_path(self):
        return os.path.join(self.base, "system", "lockout.json")

    def read_lockout(self, now=None):
        """Returns the lockout record. A missing file is an empty record. An unreadable or
        edited file counts as a full 24 h lockout from when it was changed, with
        "tampered": True, and a health note (logs/health, or health_notes if no key yet)."""
        p = self._lockout_path()
        if not os.path.exists(p):
            return {"passphrase": [], "name": [], "locked_until": 0, "tampered": False}
        try:
            with open(p, "rb") as f:
                d = json.loads(_open(_LOCK_KEY[:32], _LOCK_KEY[32:], LOCK_MAGIC, f.read()).decode())
            if not isinstance(d, dict):
                raise ValueError("not a record")
            d.setdefault("passphrase", [])
            d.setdefault("name", [])
            d.setdefault("locked_until", 0)
            d["tampered"] = False
            return d
        except (OSError, ValueError, BadKey, UnicodeDecodeError):
            try:
                since = os.path.getmtime(p)
            except OSError:
                since = now or time.time()
            note = "lockout.json was unreadable or edited; treated as a full 24 h lockout"
            self._health(note)
            return {"passphrase": [], "name": [], "locked_until": since + LOCKOUT_SECONDS,
                    "tampered": True}

    def write_lockout(self, record):
        d = {k: v for k, v in record.items() if k != "tampered"}
        payload = json.dumps(d).encode()
        _atomic_write(self._lockout_path(), _seal(_LOCK_KEY[:32], _LOCK_KEY[32:], LOCK_MAGIC, payload))

    def is_locked_out(self, now=None):
        d = self.read_lockout(now)
        return (now or time.time()) < float(d.get("locked_until") or 0), d

    def reset_lockout(self):
        """Deleting the file is the only way to reset a lockout early."""
        try:
            os.unlink(self._lockout_path())
            return True
        except FileNotFoundError:
            return False

    def _health(self, note):
        line = time.strftime("%Y-%m-%d %H:%M:%S") + " " + note
        if not self.has_key():
            self.health_notes.append(line)
            return
        rel = "logs/health/system.md"
        try:
            cur = self.read(rel, "")
            self.write(rel, (cur + "\n" if cur else "") + line)
        except LocalDataError:
            self.health_notes.append(line)

    def flush_health_notes(self):
        """After the key loads, save notes gathered before it."""
        notes, self.health_notes = self.health_notes, []
        for n in notes:
            self._health(n.split(" ", 2)[2] if n.count(" ") >= 2 else n)
        return len(notes)


class _FileLock:
    """Short lock beside a file so two processes can't check-and-write it at once."""

    def __init__(self, full, timeout=10.0):
        self.p, self.timeout = full + ".lock", timeout

    def __enter__(self):
        os.makedirs(os.path.dirname(self.p), exist_ok=True)
        end = time.time() + self.timeout
        while True:
            try:
                os.close(os.open(self.p, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
                return self
            except FileExistsError:
                try:  # a lock left by a crashed process
                    if time.time() - os.path.getmtime(self.p) > 30:
                        os.unlink(self.p)
                        continue
                except OSError:
                    continue
                if time.time() > end:
                    raise LocalDataError("file is busy: " + self.p)
                time.sleep(0.02)

    def __exit__(self, *a):
        try:
            os.unlink(self.p)
        except OSError:
            pass
