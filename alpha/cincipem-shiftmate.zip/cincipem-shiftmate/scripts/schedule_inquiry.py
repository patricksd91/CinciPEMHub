#!/usr/bin/env python3
"""Schedule Inquiry and Planning (SIP): administrator commands for CinciPEM ShiftMate (from 0.01.82).

Administrators (the division's schedulers) run these for the division, not for one clinician. Every command
imports shiftmate.py for the schedule, the roster, roles and the division's rules; nothing is rebuilt here.
The engine's rules used: site and level eligibility (roles.csv plus permission exceptions), ShiftAdmin vacations,
8 h rest, at most 7 days in a row, Jeopardy pools, holidays. Individual blocked dates are ignored on purpose:
the schedulers make the call.

Commands (all take --ics FILE for an attached or frozen schedule; SHIFTSWAP_NOW freezes "today"):
  tiers                                     the protection tiers and the rules that sort shifts into them
  vacated     --name N --from DATE [--to DATE] [--shifts IDS]         Audit (Replace Clinician 2)
  pools       --name N --from DATE [--to DATE] [--shifts IDS]         Pool Selection (Replace Clinician 3)
  candidates  --name N --from DATE [--to DATE] [--shifts IDS] --pools 1,2   Eligibility Matching (Replace Clinician 4)
  resolve     --name N --from DATE [--to DATE] [--shifts IDS] --pools 1,2   Resolution Output (Replace Clinician 5)
  snapshot    --from DATE [--to DATE] [--sites S] [--detail]          Coverage Snapshot
  enhancements --from DATE [--to DATE] [--sites S] [--tiers 1,2] [--list]   Enhancement Shifts
  mloffers    --name N --from DATE [--to DATE] [--shifts IDS] [--pools 1,2] [--include-optional]  Moonlighting Offers

Output markers (one per line, Claude turns them into messages; see workflows/schedule-inquiry/):
  SI_NAME_OK, DID_YOU_MEAN, DID_YOU_MEAN_MANY, NO_MATCH, SI_PAST_DATE, SI_VACATED, SI_OPTIONAL, SI_UNKNOWN_IDS,
  SI_NONE, SI_TIERS, SI_POOLS, SI_CANDIDATES, SI_RESOLVED, SI_PLAN, SI_UNRESOLVED, SI_SNAPSHOT, DAY, SI_NOTE,
  SI_ENHANCEMENTS, SI_LIST, SI_SKIPPED_OPTIONAL, SI_ML_OFFERS, SI_MORE, SI_NEXT, STARTUP_FIRST, ERROR, FEEDBACK.
Examples in comments use "Alex Example"; the roster is never quoted in code.
"""
VERSION = "0.01.82"   # version stamp (tools/release.py bump rewrites it)
import argparse
import os
import re
import signal
import sys
from datetime import date, datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import shiftmate as sm  # noqa: E402

SI_VERSION = VERSION
OK, NO = "\U0001F7E2", "❌"   # green circle, X: the status column of Eligibility Matching
MAX_LINES = 60                    # longer lists end with SI_MORE and the count left out
MAX_RESOLVE = 60                  # Resolution Output lists at most this many shifts per part (then SI_MORE)

# ---------------------------------------------------------------- protection tiers
# Least protected (1) to most protected (5). Donor pools for Replace Clinician are picked from these.
# The rules are data so the schedulers can move a shift name between tiers without touching the logic.
# A shift takes the first tier whose rule matches (checked 1 -> 5).
TIERS = [
    (1, "Enhancement", "pilot enhancements the leadership email names: flex, bullpen and lecture shifts",
     {"name_words": ["Flex", "Bullpen", "Lec"]}),
    (2, "Extra capacity", "add-on APP coverage: Short, Psych and Supertrack shifts and the mid-day B ED/Lib ED "
     "add-ons (B 11a-5pE, B 12p-5p E, B 6a-12p E, Lib 10a-6pE)",
     {"name_words": ["Short", "Psych"], "stypes": ["Supertrack"],
      "names": ["B 11a-5pE", "B 12p-5p E", "B 6a-12p E", "Lib 10a-6pE"]}),
    (3, "Core APP coverage", "every other APP/NP-level shift (level E or SrAPP) at the EDs, hospital-based UCs "
     "and VUC", {"levels": ["E", "SrAPP"]}),
    (4, "Core physician coverage", "physician-level shifts (F, C*, C) and the one-provider outpatient UCs",
     {"levels": ["F", "C*", "C"]}),
    (5, "Jeopardy backup", "Jeopardy call pools: the last resort, never a first choice",
     {"jeopardy": True}),
]
TIER_NAME = {n: name for n, name, _, _ in TIERS}


def tier_of(s):
    """-> tier number (1-5) for shift s."""
    name = (s.full or s.code or "").replace(" ML", "").strip()
    squeezed = re.sub(r"\s+", "", name)
    for n, _, _, rule in TIERS:
        if rule.get("jeopardy"):
            if s.is_jeop:
                return n
            continue
        if s.is_jeop:
            continue
        if any(w in name for w in rule.get("name_words", [])) or s.stype in rule.get("stypes", []):
            return n
        if squeezed in [re.sub(r"\s+", "", x) for x in rule.get("names", [])]:
            return n
        if s.level in rule.get("levels", []):
            return n
    return 4


# ---------------------------------------------------------------- loading
class Ctx:
    pass


def load(args, need_person=True, clamp_past=True):
    """Schedule + roster, with the departing clinician resolved (never a silent partial match)."""
    if sm.RELEASE:
        sm.require_unlocked()
        if not os.path.exists(sm.STARTUP_DONE):
            print("STARTUP_FIRST: run `startup` and finish its checklist first (SKILL.md, Startup), then repeat this "
                  "command.")
            sys.exit(4)
    c = Ctx()
    c.shifts, c.src = sm.load_feed(getattr(args, "ics", None), quiet=True)
    c.people, c.by_sched = sm.load_roster()
    sm.attach(c.shifts, c.people, c.by_sched)
    c.today = sm.now().date()
    c.last = max(s.sdate for s in c.shifts)
    c.person = None
    if need_person:
        c.person = resolve_name(c.people, args.name)
        if c.person is None:
            sys.exit(0)
    frm = parse_day(getattr(args, "frm", None), "--from") if getattr(args, "frm", None) else c.today
    to = parse_day(args.to, "--to") if getattr(args, "to", None) else None
    if to and to < frm:
        print(f"ERROR: the end date {to:%m/%d/%y} is before the start date {frm:%m/%d/%y}.")
        sys.exit(2)
    if clamp_past and to and to < c.today:
        print(f"SI_NONE: {frm:%m/%d/%y} to {to:%m/%d/%y} is all in the past; shifts already worked don't need cover.")
        sys.exit(0)
    if clamp_past and frm < c.today:
        print(f"SI_PAST_DATE: {frm:%m/%d/%y} is in the past; shifts already worked don't need cover, so this starts "
              f"today ({c.today:%m/%d/%y}).")
        frm = c.today
    if to and to < frm:
        print(f"ERROR: the end date {to:%m/%d/%y} is before the start date {frm:%m/%d/%y}.")
        sys.exit(2)
    c.frm, c.to = frm, (to or c.last)
    if c.frm > c.last:
        print(f"SI_NONE: the schedule only runs to {c.last:%m/%d/%y}, so there's nothing from {c.frm:%m/%d/%y} on.")
        sys.exit(0)
    sm.attach_vacations(c.people, {sm.nkey(p.schedule_name): p for p in c.people},
                        c.frm - timedelta(days=1), c.to + timedelta(days=1))
    return c


def parse_day(txt, what):
    txt = (txt or "").strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(txt, fmt).date()
        except ValueError:
            pass
    print(f"ERROR: can't read the date '{txt}' for {what}; use YYYY-MM-DD.")
    sys.exit(2)


def resolve_name(people, name):
    """The roster's name matching, as whoami does it: an exact match goes on; a near miss is asked about."""
    if not sm.nkey(name or ""):
        print("ERROR: no name given; ask who is leaving.")
        sys.exit(2)
    hits = sm.find_person(people, name or "")
    if (len(hits) == 1 and sm.whole_word_match(hits[0], name) and has_first_name(hits[0], name)
            and len(sm.split_name(name)) >= 2):   # 0.01.82: a first name alone is confirmed too
        p = hits[0]   # a departure: a last name alone (even several words) is confirmed first
        print(f"SI_NAME_OK: {p.name} ({sm.role_label(p)})")
        return p
    if len(hits) == 1:
        print(f"DID_YOU_MEAN: {hits[0].name} ({sm.role_label(hits[0])})? '{name}' isn't an exact match. Ask (Yes / No); "
              "after a yes, run the command again with that exact name.")
        return None
    if len(hits) > 3:
        print(f"DID_YOU_MEAN_MANY: '{name}' matches {len(hits)} people (for example "
              + "; ".join(p.name for p in hits[:3]) + "). Ask for their full name.")
        return None
    if len(hits) > 1:
        print("DID_YOU_MEAN: " + "; ".join(f"{p.name} ({sm.role_label(p)})" for p in hits) + f"? '{name}' matches "
              "more than one person. Ask with one button per name plus 'None of these'; then run the command again "
              "with that exact name.")
        return None
    close = [p for p in people if sm.name_close(p, name or "")]
    if close:
        print("DID_YOU_MEAN: " + "; ".join(f"{p.name} ({sm.role_label(p)})" for p in close[:3]) + f"? '{name}' isn't on "
              "the roster. Ask with one button per name plus 'None of these'; then run the command again with that "
              "exact name.")
        return None
    print(f"NO_MATCH: '{name}' is not on the roster. Ask them to check the spelling (or the name ShiftAdmin uses).")
    return None


def has_first_name(p, name):
    """The typed name includes the person's first name (or preferred name, a nickname or an initial), or is one of
    their exact name forms: 'Alex Example' and 'A. Example' go on; 'Example' alone is confirmed first."""
    forms = [p.name, p.schedule_name] + [a for a in (p.aliases or "").split(";") if a.strip()]
    if sm.nkey(name) in [sm.nkey(f) for f in forms]:
        return True
    firsts = {sm.nkey(p.name.split()[0])} | ({sm.nkey(p.preferred_name)} if getattr(p, "preferred_name", "") else set())
    for t in sm.split_name(name):
        k = sm.nkey(t)
        if not k:
            continue
        if k in firsts or (len(k) == 1 and any(f.startswith(k) for f in firsts)):
            return True
        if any(f in sm.NICKNAMES.get(k, []) or k in sm.NICKNAMES.get(f, []) for f in firsts):
            return True
    return False


def in_window(c, s):
    return c.frm <= s.sdate <= c.to


def id_list(txt):
    return [x for x in re.split(r"[,\s;]+", txt or "") if x and x.lower() not in ("and", "&", "pool", "pools", "tier", "tiers")]


def vacated(c, args):
    """The departing clinician's shifts in the window that need someone else (ML and Jeopardy included)."""
    out = [s for s in c.person.shifts if in_window(c, s) and s.start > sm.now()]
    want = id_list(getattr(args, "shifts", None))
    if want:
        unknown = [x for x in want if x not in {s.id for s in out}]
        if unknown:
            print(f"SI_UNKNOWN_IDS: not {c.person.name}'s shifts in this window, left out: {', '.join(unknown)}")
        out = [s for s in out if s.id in want]
    return sorted(out, key=lambda s: s.start)


def day_label(d):
    return f"{d:%a %m/%d/%y}"


def hol_tag(s):
    if s.hol == "HOL":
        return f" [holiday: {s.hol_name}]"
    if s.hol == "PERI":
        return " [peri-holiday]"
    return ""


def shift_desc(s, who=True):
    """'Mon 10/05 B 9aC 0900-1700 (B ED, level C)' plus tags."""
    bits = [f"{s.start:%a %m/%d} {s.code} {s.start:%H%M}-{s.end:%H%M} ({s.site}, level {s.level})"]
    if s.is_ml:
        bits.append("[ML]")
    t = hol_tag(s)
    if t:
        bits.append(t.strip())
    if who and s.who:
        bits.append(f"- {s.who.name}")
    return " ".join(bits)


def pool_list(txt):
    if not txt:
        return []
    out = []
    for x in id_list(txt):
        if x.isdigit() and int(x) in TIER_NAME:
            out.append(int(x))
        else:
            hit = [n for n, name in TIER_NAME.items() if name.lower().startswith(x.lower())]
            if len(hit) != 1:
                print(f"ERROR: '{x}' isn't a pool; use tier numbers 1-5 (run `inquiry tiers`).")
                sys.exit(2)
            out.append(hit[0])
    return sorted(set(out))


# ---------------------------------------------------------------- matching
def why_not(p, v, donor):
    """Can p leave `donor` and cover vacated shift v? -> '' when yes, else the reason in plain words."""
    if p.role == "Moonlighter":
        return "a moonlighter (not assigned regular coverage)"
    if not sm.eligible(p, v, p, True):
        key = p.status_on(v.sdate)[0]
        if v.is_jeop:
            return f"not in the Jeop {v.level} pool ({sm.role_label(p)})"
        return f"not credentialed for {v.site} level {v.level} shifts ({key})"
    if sm.on_vacation(p, v):
        return "on vacation that day (ShiftAdmin)"
    ok, reason, _ = sm.check(p.shifts, v, remove_ids={donor.id} if donor else set(), b2b=False)
    if not ok:
        return plain_rule(reason)
    return ""


def plain_rule(reason):
    r = reason
    r = r.replace("under 8 h rest after", "less than 8 hours' rest after their").replace(
        "under 8 h rest before", "less than 8 hours' rest before their")
    r = re.sub(r"^overlaps ", "already working at that time (", r)
    if r.startswith("already working at that time ("):
        r += ")"
    r = re.sub(r"^(\d+) days in a row$", r"would make \1 days in a row (the limit is 7)", r)
    return r


def can_donate(d, v):
    """A donor shift must be less protected than the shift it would cover (no robbing core coverage to fill core
    coverage). Jeopardy (tier 5) is the exception both ways: picking pool 5 means using Jeopardy backup for a core
    shift (tiers 3-4), and a vacated Jeopardy shift is refilled only from tiers 1-2, never by pulling someone off core
    coverage."""
    td, tv = tier_of(d), tier_of(v)
    if tv == 5:
        return td <= 2
    if td == 5:
        return tv in (3, 4)   # Jeopardy backup is used for core coverage only, never to keep an enhancement going
    return td < tv


def match(c, vac, pools):
    """For each vacated shift: [(donor shift, person, reason or '')] over donor shifts in the pools that day."""
    by_day = {}
    for s in c.shifts:
        if s.who is not None and s.who is not c.person and tier_of(s) in pools:
            by_day.setdefault(s.sdate, []).append(s)
    res = {}
    c.skipped = {}
    for v in vac:
        rows = []
        for d in sorted(by_day.get(v.sdate, []), key=lambda x: (x.site != v.site, x.start, x.code)):
            if d.start <= sm.now():
                continue
            if not can_donate(d, v):
                c.skipped[v.id] = c.skipped.get(v.id, 0) + 1
                continue
            rows.append((d, d.who, why_not(d.who, v, d)))
        res[v.id] = rows
    return res


# ---------------------------------------------------------------- commands
def cmd_tiers(args):
    print("SI_TIERS: protection tiers, least protected first. Donor pools come from these; pick by number.")
    for n, name, why, _ in TIERS:
        print(f"  {n}. {name}: {why}")
    print("SI_NEXT: the tiers are a starting point from the leadership email and the shift names; say which to move.")


def print_vacated(c, vac):
    if not vac:
        print(f"SI_NONE: {c.person.name} has no shifts from {c.frm:%m/%d/%y}"
              + (f" to {c.to:%m/%d/%y}" if c.to != c.last else "") + " that need cover.")
        return
    hol = sum(1 for s in vac if s.hol == "HOL")
    tiers = {}
    for s in vac:
        tiers[tier_of(s)] = tiers.get(tier_of(s), 0) + 1
    print(f"SI_VACATED: {len(vac)} shift(s) of {c.person.name} from {c.frm:%m/%d/%y} need a replacement"
          + (f", {hol} on a holiday" if hol else "") + ". By tier: "
          + ", ".join(f"{TIER_NAME[t]} {n}" for t, n in sorted(tiers.items())) + ".")
    for i, s in enumerate(vac[:MAX_LINES], 1):
        print(f"  {i}. {shift_desc(s, who=False)} [tier {tier_of(s)}] (id {s.id})")
    if len(vac) > MAX_LINES:
        print(f"SI_MORE: {len(vac) - MAX_LINES} more not listed; narrow with --to or --shifts.")
    optional = [s for s in vac if tier_of(s) <= 2]
    if optional:
        print(f"SI_OPTIONAL: {len(optional)} of these are tier 1-2 shifts (Enhancement or Extra capacity); they could be "
              "left unfilled (repurposed) instead of replaced: " + ", ".join(f"{s.start:%m/%d} {s.code}" for s in optional[:8])
              + (f" and {len(optional) - 8} more" if len(optional) > 8 else "") + ".")


def cmd_vacated(args):
    c = load(args)
    vac = vacated(c, args)
    print_vacated(c, vac)
    if vac:
        print("SI_NEXT: ask the Audit question (Replace Clinician 2) first; after a yes, Pool Selection (Replace Clinician 3): "
              "run `inquiry pools` for the shifts they chose.")


def cmd_pools(args):
    c = load(args)
    vac = vacated(c, args)
    if not vac:
        print_vacated(c, vac)
        return
    days = {v.sdate for v in vac}
    counts = {n: [0, 0, set()] for n in TIER_NAME}   # shifts, people, codes
    people = {n: set() for n in TIER_NAME}
    for s in c.shifts:
        if s.sdate in days and s.who is not None and s.who is not c.person and s.start > sm.now():
            t = tier_of(s)
            counts[t][0] += 1
            people[t].add(s.who.name)
            counts[t][2].add(s.code)
    print(f"SI_POOLS: donor shifts on the {len(days)} day(s) of {c.person.name}'s {len(vac)} vacated shift(s), "
          "least protected first. Pick one or more (default: 1 and 2). A donor shift is only used for a vacated shift "
          "in a more protected tier (Jeopardy backup, pool 5, covers core shifts only).")
    for n, name, why, _ in TIERS:
        k, _, codes = counts[n]
        ex = ", ".join(sorted(codes)[:4]) + (" ..." if len(codes) > 4 else "")
        print(f"  {n}. {name}: {k} shift(s), {len(people[n])} clinician(s)" + (f" (e.g. {ex})" if k else "")
              + (" [last resort]" if n == 5 else ""))
    print("SI_NEXT: Eligibility Matching (Replace Clinician 4): run `inquiry candidates --pools <numbers>`.")


def cmd_candidates(args):
    c = load(args)
    vac = vacated(c, args)
    if not vac:
        print_vacated(c, vac)
        return
    pools = pool_list(args.pools) or [1, 2]
    res = match(c, vac, pools)
    per = {}   # person -> [viable count, donor shifts, first reason]
    for v in vac:
        for d, p, why in res[v.id]:
            e = per.setdefault(p.name, [0, set(), "", p])
            e[1].add(f"{d.start:%m/%d} {d.code}")
            if not why:
                e[0] += 1
            elif not e[2]:
                e[2] = why
    names = ", ".join(f"{n} {TIER_NAME[n]}" for n in pools)
    if not per:
        print(f"SI_CANDIDATES: nobody works a shift in pools {names} on those days that is less protected than the "
              "vacated shifts. Try adding a pool (Pool Selection, Replace Clinician 3) or go to Moonlighting Offers.")
        return
    good = sum(1 for e in per.values() if e[0])
    print(f"SI_CANDIDATES: {len(per)} clinician(s) work donor shifts in pools {names} on those days; "
          f"{good} eligible for at least one vacated shift. Paste this table as printed.")
    print(f"| | Clinician | Role | Donor shift(s) | Can cover |")
    print(f"|:-:|---|---|---|---|")
    rows = sorted(per.items(), key=lambda kv: (-kv[1][0], kv[0]))
    for i, (nm, (k, donors, why, p)) in enumerate(rows):
        if i >= MAX_LINES:
            print(f"SI_MORE: {len(rows) - MAX_LINES} more clinicians not listed.")
            break
        mark = OK if k else NO
        cover = f"{k} of {len(vac)}" if k else f"none: {why}"
        print(f"| {mark} | {nm} | {sm.role_label(p)} | {'; '.join(sorted(donors)[:3])}"
              f"{' ...' if len(donors) > 3 else ''} | {cover} |")
    print("SI_NEXT: Resolution Output (Replace Clinician 5): run `inquiry resolve` with the same pools.")


def cmd_resolve(args):
    c = load(args)
    vac = vacated(c, args)
    if not vac:
        print_vacated(c, vac)
        return
    pools = pool_list(args.pools) or [1, 2]
    res = match(c, vac, pools)
    names = ", ".join(f"{n} {TIER_NAME[n]}" for n in pools)
    good = [v for v in vac if any(not w for _, _, w in res[v.id])]
    bad = [v for v in vac if v not in good]
    print(f"SI_RESOLVED: {len(good)} of {len(vac)} vacated shift(s) have a viable replacement from pools {names} "
          "(role and site eligibility, no ShiftAdmin vacation, 8 h rest, 7 days in a row; blocked dates ignored).")
    plan = suggest_plan(good, res)
    for v in good[:MAX_RESOLVE]:
        opts = [(d, p) for d, p, w in res[v.id] if not w]
        print(f"  {shift_desc(v, who=False)} (id {v.id})")
        for d, p in opts[:5]:
            print(f"      {OK} {p.name} ({sm.role_label(p)}), moving off {d.code} {d.start:%H%M}-{d.end:%H%M} "
                  f"({d.site}, tier {tier_of(d)} {TIER_NAME[tier_of(d)]})")
        if len(opts) > 5:
            print(f"      ... and {len(opts) - 5} more")
    if len(good) > MAX_RESOLVE:
        print(f"SI_MORE: {len(good) - MAX_RESOLVE} more shifts with a replacement not listed; narrow with --to or --shifts.")
    if plan:
        print(f"SI_PLAN: one suggestion per shift, spreading the moves so nobody is asked twice where it can be helped "
              f"({len(set(p.name for _, _, p in plan))} clinicians for {len(plan)} shifts):")
        for v, d, p in plan[:MAX_RESOLVE]:
            print(f"      {v.start:%a %m/%d} {v.code}: {p.name}, off {d.code}")
        if len(plan) > MAX_RESOLVE:
            print(f"SI_MORE: {len(plan) - MAX_RESOLVE} more suggestions not listed.")
    print(f"SI_UNRESOLVED: {len(bad)} vacated shift(s) have no viable replacement from these pools.")
    if len(bad) > MAX_RESOLVE:
        print(f"SI_MORE: only the first {MAX_RESOLVE} are listed; narrow with --to or --shifts.")
    for v in bad[:MAX_RESOLVE]:
        rows = res[v.id]
        print(f"  {shift_desc(v, who=False)} (id {v.id})")
        skipped = c.skipped.get(v.id, 0)
        if skipped:
            rule = ("a vacated Jeopardy shift is refilled only from tiers 1-2" if tier_of(v) == 5 else
                    "nothing is less protected than an Enhancement shift; it can be left unfilled" if tier_of(v) == 1
                    else f"a donor must be less protected than this shift (tier {tier_of(v)} {TIER_NAME[tier_of(v)]})")
            print(f"      {skipped} donor shift(s) in pools {names} on {v.sdate:%m/%d} not used: {rule}.")
        if not rows:
            if not skipped:
                print(f"      no shifts in pools {names} on {v.sdate:%m/%d}.")
            continue
        if len(rows) <= 8:
            for d, p, w in rows:
                print(f"      {NO} {p.name}, on {d.code} {d.start:%H%M}-{d.end:%H%M} ({d.site}, tier {tier_of(d)}): {w}")
            continue
        groups = {}   # more than 8 candidates: one line per reason, every candidate named
        for d, p, w in rows:
            groups.setdefault(w, []).append(f"{p.name} ({d.code})")
        for w, who in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            print(f"      {NO} {w}: {', '.join(who)}")
    if bad:
        print("SI_NEXT: offer these as moonlighting (Moonlighting Offers: run `inquiry mloffers` with the same name, dates "
              "and pools), or add a pool and run `inquiry resolve` again.")
    else:
        print("SI_NEXT: every vacated shift has an option. Confirm the moves with the clinicians before changing "
              "ShiftAdmin.")


def suggest_plan(good, res):
    """A simple one-to-one suggestion: for each vacated shift (fewest options first), the viable candidate asked the
    fewest times so far (ties: least protected donor shift, then name). Never the same person twice on one day."""
    used, day_used, plan = {}, set(), []
    for v in sorted(good, key=lambda v: (sum(1 for _, _, w in res[v.id] if not w), v.start)):
        opts = [(d, p) for d, p, w in res[v.id] if not w and (p.name, v.sdate) not in day_used]
        if not opts:
            continue
        d, p = min(opts, key=lambda o: (used.get(o[1].name, 0), tier_of(o[0]), o[1].name))
        used[p.name] = used.get(p.name, 0) + 1
        day_used.add((p.name, v.sdate))
        plan.append((v, d, p))
    return sorted(plan, key=lambda x: x[0].start)


def site_list(txt):
    if not txt:
        return list(sm.ALL_SITES)
    out = []
    for x in re.split(r"[,;]+", txt):
        if x.strip().lower() in ("jeopardy", "jeop"):
            out.append("Jeopardy")
            continue
        s = sm.norm_site(x)
        if not s:
            print(f"ERROR: '{x.strip()}' isn't a site; use {', '.join(sm.ALL_SITES)} or Jeopardy.")
            sys.exit(2)
        out.append(s)
    return out


def cmd_snapshot(args):
    c = load(args, need_person=False, clamp_past=False)
    if not args.to:
        c.to = c.frm
    sites = site_list(args.sites)
    if args.sites is None:
        sites.append("Jeopardy")
    rows = [s for s in c.shifts if in_window(c, s) and s.site in sites]
    ndays = (c.to - c.frm).days + 1
    unfilled_names = sum(1 for s in rows if s.who is None)
    print(f"SI_SNAPSHOT: {len(rows)} shift(s) at {', '.join(sites)} from {c.frm:%m/%d/%y} to {c.to:%m/%d/%y} "
          f"({ndays} day(s)).")
    if unfilled_names:
        print(f"SI_NOTE: {unfilled_names} shift(s) have a name the roster doesn't know (shown as 'not on roster').")
    if ndays > 31 and not args.detail:   # a long range: one row per week (Monday start)
        used = [x for x in sites if any(s.site == x for s in rows)]
        print("| Week of | " + " | ".join(used) + " |")
        print("|---|" + "---|" * len(used))
        wk = c.frm - timedelta(days=c.frm.weekday())
        while wk <= c.to:
            days = [s for s in rows if wk <= s.sdate < wk + timedelta(days=7)]
            hol = any(s.hol == "HOL" for s in days)
            print(f"| {max(wk, c.frm):%m/%d}{' (holiday)' if hol else ''} | "
                  + " | ".join(str(sum(1 for s in days if s.site == x)) for x in used) + " |")
            wk += timedelta(days=7)
        print("SI_NEXT: weekly totals; ask for up to 31 days for a row per day, or 1-3 days for names.")
        return
    if ndays > 3 and not args.detail:
        # counts: one row per day, one column per site
        used = [x for x in sites if any(s.site == x for s in rows)]
        print("| Date | " + " | ".join(used) + " |")
        print("|---|" + "---|" * len(used))
        d = c.frm
        while d <= c.to:
            day = [s for s in rows if s.sdate == d]
            hol = any(s.hol == "HOL" for s in day)
            print(f"| {d:%a %m/%d}{' (holiday)' if hol else ''} | "
                  + " | ".join(str(sum(1 for s in day if s.site == x)) for x in used) + " |")
            d += timedelta(days=1)
        print("SI_NEXT: for who's on each shift, run `inquiry snapshot --detail` for one to three days.")
        return
    d = c.frm
    n, cap = 0, MAX_LINES * 3
    while d <= c.to and n < cap:
        day = sorted([s for s in rows if s.sdate == d], key=lambda s: (sites.index(s.site), s.start, s.code))
        hol = next((s.hol_name for s in day if s.hol == "HOL"), "")
        print(f"DAY: {day_label(d)}{' (holiday: ' + hol + ')' if hol else ''}: {len(day)} shift(s)")
        for x in sites:
            here = [s for s in day if s.site == x]
            if not here or n >= cap:
                continue
            print(f"  {x}:")
            for s in here:
                if n >= cap:
                    break
                n += 1
                who = s.who.name if s.who else "not on roster"
                print(f"    {s.code} {s.start:%H%M}-{s.end:%H%M} - {who}{' [ML]' if s.is_ml else ''}"
                      f" [tier {tier_of(s)}]")
        d += timedelta(days=1)
    if n >= cap and (d <= c.to or len(rows) > n):
        print(f"SI_MORE: the list stops at {cap} shifts ({len(rows) - n} more); ask for fewer days or sites.")


def cmd_enhancements(args):
    c = load(args, need_person=False, clamp_past=False)
    sites = site_list(args.sites)
    tiers = pool_list(args.tiers) or [1, 2]
    rows = sorted([s for s in c.shifts if in_window(c, s) and s.site in sites and tier_of(s) in tiers],
                  key=lambda s: (s.start, s.site, s.code))
    names = ", ".join(f"{n} {TIER_NAME[n]}" for n in tiers)
    if not rows:
        print(f"SI_NONE: no tier {names} shifts from {c.frm:%m/%d/%y} to {c.to:%m/%d/%y}.")
        return
    by_code = {}
    for s in rows:
        by_code.setdefault((tier_of(s), s.site, s.code.replace(" ML", "")), []).append(s)
    print(f"SI_ENHANCEMENTS: {len(rows)} shift(s) in tiers {names} from {c.frm:%m/%d/%y} to {c.to:%m/%d/%y}, "
          f"{sum(1 for s in rows if s.hol == 'HOL')} on holidays. These are the first candidates to repurpose into "
          "core coverage.")
    print("| Tier | Site | Shift | How many | Assigned | First date |")
    print("|---|---|---|---|---|---|")
    for (t, site, code), ss in sorted(by_code.items()):
        filled = sum(1 for s in ss if s.who is not None)
        print(f"| {t} {TIER_NAME[t]} | {site} | {code} | {len(ss)} | {filled} | {ss[0].start:%m/%d} |")
    if args.list or len(rows) <= 20:
        print("SI_LIST:")
        for s in rows[:MAX_LINES]:
            print(f"  {shift_desc(s)} [tier {tier_of(s)}] (id {s.id})")
        if len(rows) > MAX_LINES:
            print(f"SI_MORE: {len(rows) - MAX_LINES} more not listed; narrow the dates or sites.")
    else:
        print("SI_NEXT: run with --list for every shift and who's on it (or narrow the dates or sites).")


def free_for(c, v):
    """Clinicians who could pick up v as an extra (moonlighting) shift: eligible, not on vacation, rest and 7-day OK."""
    out = []
    for p in c.people:
        if p is c.person or p.role == "Moonlighter":
            continue
        if not sm.eligible(p, v, p, True) or sm.on_vacation(p, v):
            continue
        ok, _, _ = sm.check(p.shifts, v, b2b=False)
        if ok:
            out.append(p)
    return sorted(out, key=lambda p: p.name)


def cmd_mloffers(args):
    c = load(args)
    vac = vacated(c, args)
    if not vac:
        print_vacated(c, vac)
        return
    pools = pool_list(args.pools)
    optional = [v for v in vac if tier_of(v) <= 2]
    if optional and not args.include_optional:
        vac = [v for v in vac if tier_of(v) > 2]
        print(f"SI_SKIPPED_OPTIONAL: {len(optional)} tier 1-2 shift(s) (Enhancement or Extra capacity) left out; they can "
              "be left unfilled. Add --include-optional to offer them too.")
        if not vac:
            print("SI_NONE: nothing else to offer as moonlighting.")
            return
    if pools:
        res = match(c, vac, pools)
        vac = [v for v in vac if not any(not w for _, _, w in res[v.id])]
        if not vac:
            print("SI_NONE: every vacated shift has a replacement from those pools; nothing to offer as moonlighting.")
            return
    hol = [v for v in vac if v.hol in ("HOL", "PERI")]
    print(f"SI_ML_OFFERS: {len(vac)} shift(s) to offer as moonlighting"
          + (f" (still open after pools {', '.join(str(p) for p in pools)})" if pools else "")
          + (f"; {len(hol)} on or next to a holiday, listed first" if hol else "") + ".")
    order = sorted(vac, key=lambda v: (v.hol not in ("HOL", "PERI"), v.start))
    for v in order[:MAX_LINES]:
        who = free_for(c, v)
        names = ", ".join(p.name for p in who[:6]) + (f" and {len(who) - 6} more" if len(who) > 6 else "")
        print(f"  {shift_desc(v, who=False)} (id {v.id}): {len(who)} eligible and free" + (f": {names}" if who else ""))
    if len(order) > MAX_LINES:
        print(f"SI_MORE: {len(order) - MAX_LINES} more not listed.")
    print("SI_NEXT: 'eligible and free' means credentialed for the shift, not working then, no ShiftAdmin vacation, "
          "8 h rest and 7 days in a row kept (blocked dates ignored). Post the shifts in ShiftAdmin as ML.")


def main(argv=None):
    """argv: the words after `inquiry` when shiftmate.py runs this (the 0.01.08b hook), else sys.argv."""
    ap = argparse.ArgumentParser(prog="inquiry", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("tiers").add_argument("--ics", help="accepted and ignored: the tiers don't need the schedule")
    for name in ("vacated", "pools", "candidates", "resolve", "mloffers", "snapshot", "enhancements"):
        p = sub.add_parser(name)
        p.add_argument("--ics", help="attached or frozen ShiftAdmin calendar file")
        p.add_argument("--from", dest="frm", required=name in ("vacated", "pools", "candidates", "resolve",
                                                               "mloffers", "snapshot"),
                       help="first date (YYYY-MM-DD); for a departure, the effective date")
        p.add_argument("--to", help="last date (default: the end of the schedule; snapshot: the --from date)")
        if name in ("vacated", "pools", "candidates", "resolve", "mloffers"):
            p.add_argument("--name", required=True, help="the departing clinician (their roster name)")
            p.add_argument("--shifts", help="only these shift ids (from `vacated`), comma-separated")
        if name in ("candidates", "resolve", "mloffers"):
            p.add_argument("--pools", help="donor tiers by number, e.g. 1,2 (default 1,2; mloffers: none)")
        if name == "mloffers":
            p.add_argument("--include-optional", action="store_true", help="also offer vacated tier 1-2 shifts")
        if name in ("snapshot", "enhancements"):
            p.add_argument("--sites", help="sites, comma-separated (default: all, plus Jeopardy for snapshot)")
        if name == "snapshot":
            p.add_argument("--detail", action="store_true", help="who's on each shift, even for more than 3 days")
        if name == "enhancements":
            p.add_argument("--tiers", help="tiers to list (default 1,2)")
            p.add_argument("--list", action="store_true", help="list every shift, not only the counts")
    if hasattr(signal, "SIGPIPE") and argv is None:
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    a = ap.parse_args(argv)
    {"tiers": cmd_tiers, "vacated": cmd_vacated, "pools": cmd_pools, "candidates": cmd_candidates,
     "resolve": cmd_resolve, "snapshot": cmd_snapshot, "enhancements": cmd_enhancements,
     "mloffers": cmd_mloffers}[a.cmd](a)
    for f in sm.FEEDBACK:
        print("FEEDBACK: " + f)


if __name__ == "__main__":
    main()
