"""Encrypt feedback so only the maintainer can read it (standard library + vendored pyaes).

The skill carries only the public key (feedback_pubkey.json). A random key locks the
feedback (AES-256-CTR + HMAC-SHA256); RSA-OAEP (SHA-256) locks that random key with the
public key. Only the private key on the maintainer's computer can open it.

Binary layout: MAGIC | len(ek) (2 bytes) | ek | nonce (16) | body | tag (32)
"""
import base64, hashlib, hmac, json, os, zlib

VERSION = "0.01.82"
MAGIC = b"CPFB1\n"
ARMOR = ("-----BEGIN CINCIPEM FEEDBACK-----", "-----END CINCIPEM FEEDBACK-----")
HERE = os.path.dirname(os.path.abspath(__file__))


def _mgf1(seed, length):
    out, c = b"", 0
    while len(out) < length:
        out += hashlib.sha256(seed + c.to_bytes(4, "big")).digest()
        c += 1
    return out[:length]


def oaep_encrypt(msg, n, e):
    """RSA-OAEP with SHA-256 and MGF1-SHA-256, empty label (RFC 8017)."""
    k = (n.bit_length() + 7) // 8
    h = 32
    if len(msg) > k - 2 * h - 2:
        raise ValueError("message too long for the key")
    db = hashlib.sha256(b"").digest() + b"\x00" * (k - len(msg) - 2 * h - 2) + b"\x01" + msg
    seed = os.urandom(h)
    mdb = bytes(a ^ b for a, b in zip(db, _mgf1(seed, k - h - 1)))
    mseed = bytes(a ^ b for a, b in zip(seed, _mgf1(mdb, h)))
    em = b"\x00" + mseed + mdb
    return pow(int.from_bytes(em, "big"), e, n).to_bytes(k, "big")


def load_pubkey(path=None):
    d = json.load(open(path or os.path.join(HERE, "feedback_pubkey.json"), encoding="utf-8"))
    return int(d["n"], 16), int(d["e"]), d.get("id", "")


def _keys(seed):
    return hashlib.sha256(b"enc" + seed).digest(), hashlib.sha256(b"mac" + seed).digest()


def encrypt(text, pubkey=None):
    """Armored text that only the private key can open."""
    import securebundle  # reuse its AES-CTR (cryptography if present, pyaes otherwise)
    n, e, _ = pubkey or load_pubkey()
    seed, nonce = os.urandom(32), os.urandom(16)
    ek = oaep_encrypt(seed, n, e)
    kenc, kmac = _keys(seed)
    head = MAGIC + len(ek).to_bytes(2, "big") + ek + nonce
    body = securebundle._ctr(kenc, nonce, zlib.compress(text.encode("utf-8"), 9))
    blob = head + body + hmac.new(kmac, head + body, hashlib.sha256).digest()
    b64 = base64.b64encode(blob).decode()
    return "\n".join([ARMOR[0]] + [b64[i:i + 76] for i in range(0, len(b64), 76)] + [ARMOR[1]])


def split(armored):
    """(encrypted key, nonce, body, tag, head+body) from armored text; used by the maintainer's tools."""
    b64 = armored.split(ARMOR[0], 1)[1].split(ARMOR[1], 1)[0]
    blob = base64.b64decode("".join(b64.split()))
    if not blob.startswith(MAGIC):
        raise ValueError("not CinciPEM feedback")
    i = len(MAGIC)
    ln = int.from_bytes(blob[i:i + 2], "big")
    ek = blob[i + 2:i + 2 + ln]
    nonce = blob[i + 2 + ln:i + 18 + ln]
    return ek, nonce, blob[i + 18 + ln:-32], blob[-32:], blob[:-32]


def open_with_seed(armored, seed):
    """Decrypt once the maintainer's private key has recovered the random seed."""
    import securebundle
    ek, nonce, body, tag, signed = split(armored)
    kenc, kmac = _keys(seed)
    if not hmac.compare_digest(tag, hmac.new(kmac, signed, hashlib.sha256).digest()):
        raise ValueError("feedback was altered or the key is wrong")
    return zlib.decompress(securebundle._ctr(kenc, nonce, body)).decode("utf-8")
