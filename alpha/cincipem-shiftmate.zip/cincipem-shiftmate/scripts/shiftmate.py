#!/usr/bin/env python3
"""CinciPEM ShiftMate engine.

All schedule parsing, rule checks and matching happen here so the schedule never
enters the AI's context. Every command prints a short plain-text report.

Commands (see SKILL.md for when to use each):
  startup                              the ordered startup checklist (banner, what's new, updates, checks)
  refresh   [--ics FILE]                 load/refresh the ShiftAdmin feed
  whoami    --name NAME [--setup]        match a person to the roster (--setup: first-setup name check)
  shifts    --req REQ.json               list a clinician's shifts on given dates
  avail     --req REQ.json               days available with shifts to trade into
  swap      --req REQ.json               trade options (by tier)
  locswitch --req REQ.json               same-day site-switch options
  mlpickup  --req REQ.json --xls FILE    open shifts the primary user can pick up
  contacts  --names "A; B; C"            contact details for message drafting
  unlock    --passphrase P               unlock a released copy's encrypted data (once per conversation)
  banner    --installed DATE --channel C the launch title box
  outlook   --req MSGS.json              Outlook on the web links for prepared emails
  whatsnew  --from V [--to V] --channel C  changelog entries between two versions
  update    --check | --download stable|beta   compare with / fetch the published versions
  newlink   --url U --last L --first F   try a schedule link the user made; give it an ID if valid
  feedback  --prepare FILE | --submit FILE [--dry-run]   privacy-check (and send) feedback
  demo      --schedule [--stdin] | --end     a demo's schedule (live, else the archived copy); end the demo
"""
import argparse, csv, hashlib, io, json, os, re, shutil, signal, sys, tempfile, urllib.error, urllib.parse, urllib.request, zipfile
from datetime import datetime, date, timedelta, timezone
from zoneinfo import ZoneInfo

VERSION = "0.01.08"  # X.XX.XX; builds +0.00.01; minor release -> x.(yy+1).00; major -> (x+1).00.00
# A version ending in .00 is a stable release; anything else is a beta (every unpublished test build is a beta).
BUILD_DATE = "2026-09-27"
ROSTER_DATE = "2026-09-22"
ROSTER_FY = 27  # fellow years in staff.csv are valid through June 30 of 20(ROSTER_FY)
try:
    ET = ZoneInfo("America/New_York")
except Exception:   # Windows without the tzdata package: stop with a clear line instead of a traceback
    print("ERROR: this computer's Python has no time-zone data (install the tzdata package, or reinstall the "
          "ShiftMate extension). Tell the user the skill can't start and send feedback.")
    sys.exit(7)
HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.normpath(os.path.join(HERE, ".."))
WORK = os.environ.get("SHIFTSWAP_WORK", os.path.join(tempfile.gettempdir(), "cincipem_shiftswap"))
BUNDLE = os.path.join(SKILL_DIR, "secure.bin")
UNLOCKED = os.path.join(WORK, "unlocked")
if os.path.exists(os.path.join(SKILL_DIR, "data", "staff.csv")):
    # Development copy: plain data files next to the script.
    RELEASE = False
    DATA = os.path.join(SKILL_DIR, "data")
    SENSITIVE = os.path.join(SKILL_DIR, "SKILL_SENSITIVE.md")
else:
    # Released copy: data and SKILL_SENSITIVE.md live only inside the encrypted secure.bin.
    RELEASE = True
    DATA = os.path.join(UNLOCKED, "data")
    SENSITIVE = os.path.join(UNLOCKED, "SKILL_SENSITIVE.md")
CACHE_HOURS = 2
PUBLIC_REPO = "https://raw.githubusercontent.com/patricksd91/CinciPEMHub/main/"  # public, not sensitive
NO_UNLOCK = {"unlock", "banner", "outlook", "whatsnew", "update", "sites-check"}  # commands that never read the encrypted data
H = timedelta(hours=1)
DAY_START = 5 * 60 + 30   # 05:30. Day shifts start 05:30-15:59; a shift starting before 05:30 belongs to the day before
FEEDBACK = []  # automatic-feedback lines collected during a command


def vkey(v):
    """Versions compare number by number, so 0.1.06 < 0.01.07 < 0.02.00 (the dots removed: 00106 < 00107 < 00200).
    Fix 3 #3: text around the version ("0.01.07 (2026-09-10)") is ignored, and a value with no version in it counts as
    unknown (older than every version), never a crash."""
    m = re.search(r"\d+(?:\.\d+)*", str(v or ""))
    return tuple(int(x) for x in m.group(0).split(".")) if m else (0,)


def split_installed(s):
    """'0.01.07', '0.01.07 (2026-09-10)', '0.01.07 on 2026-09-10' -> (version, date or ''). Without a version in it:
    (the text as given, '')."""
    s = str(s or "").strip()
    m = re.match(r"^v?(\d+(?:\.\d+)+)\s*(?:\(\s*(?:installed\s+)?(?:on\s+)?(\d{4}-\d{2}-\d{2})\s*\)|on\s+(\d{4}-\d{2}-\d{2}))?",
                 s, re.I)
    if not m:
        return s, ""
    return m.group(1), m.group(2) or m.group(3) or ""


ALPHA_VERSIONS = {"0.01.08"}   # builds published as an alpha (plan 7.3): an early preview, not an official beta
# The maintainer (always offered the newest version of any kind, plan 7.3) is SKILL_SENSITIVE feedback_name: see is_maintainer().


def channel_of(v):
    """'stable' for x.yy.00, 'alpha' for a build published as an alpha, otherwise 'beta'."""
    if str(v) in ALPHA_VERSIONS:
        return "alpha"
    return "stable" if str(v).split(".")[-1] == "00" else "beta"


VERSION = os.environ.get("SHIFTSWAP_TEST_VERSION") or VERSION   # tests only: pretend to be another version
CHANNEL = channel_of(VERSION)


def now():
    o = os.environ.get("SHIFTSWAP_NOW")
    return datetime.fromisoformat(o).replace(tzinfo=ET) if o else datetime.now(ET)


def sensitive(key):
    """A value from the '- key: value' lines of SKILL_SENSITIVE.md, or None."""
    try:
        for line in open(SENSITIVE, encoding="utf-8"):
            m = re.match(r"^- (\w+): (.+?)\s*$", line)
            if m and m.group(1) == key:
                return m.group(2)
    except OSError:
        pass
    return None


def maintainers():
    """The maintainers' names, only from SKILL_SENSITIVE.md (encrypted in releases; unknown before unlocking): the
    feedback contact (feedback_name) plus any in a 'maintainers' line (names separated by ';'). Never written here."""
    names = [sensitive("feedback_name")] + (sensitive("maintainers") or "").split(";")
    return [n.strip() for n in names if n and n.strip()]


def is_maintainer(name):
    """True for a maintainer (answer 19): always offered test mode and, as a clinician, every workflow."""
    return bool(name) and nkey(name) in {nkey(m) for m in maintainers()}


def fb(msg):
    if msg not in FEEDBACK:
        FEEDBACK.append(msg)


# ---------------------------------------------------------------- sites & levels
FACILITY = {
    "Burnet ED": ("B ED", "ED", "B"), "Liberty ED": ("Lib ED", "ED", "LT"),
    "Burnet Urgent Care": ("BUC", "HBUC", "BUC"), "Liberty Urgent Care": ("LT UC", "HBUC", "LT UC"),
    "Outpatient Eastgate Urgent Care": ("OPE", "NUC", "OPE"),
    "Outpatient Green Township Urgent Care": ("OPGT", "NUC", "OPGT"),
    "Outpatient Mason Urgent Care": ("OPM", "NUC", "OPM"),
    "Outpatient Kentucky Crestview Hills": ("OPKY", "NUC", "OPKY"),
    "Virtual Urgent Care": ("VUC", "VUC", "VUC"),
    "Jeopardy": ("Jeopardy", "JEOP", "J"), "Jeopardy APP": ("Jeopardy", "JEOP", "J APP"),
    "Jeopardy CL": ("Jeopardy", "JEOP", "J CL"), "Jeopardy F": ("Jeopardy", "JEOP", "J F"),
}
SKIP_FACILITIES = {"Administrator On Call"}
SKIP_SHIFTS = {"AOS"}
ALL_SITES = ["B ED", "Lib ED", "BUC", "LT UC", "OPE", "OPM", "OPKY", "OPGT", "VUC"]
WHO = "you"   # 4.7: request field "who", set by Claude: "you" for the user's own search, else the clinician's preferred name


def Y(mine, theirs):
    """4.7: the "you" wording, or the same words about the clinician by name ({n} is the name)."""
    return mine if WHO.lower() == "you" else theirs.format(n=WHO)


def YOUR():
    return Y("your", "{n}'s")


def YOURE():
    return Y("you're", "{n} is")
SITE_ALIASES = {"B": "B ED", "BED": "B ED", "BURNET": "B ED", "BASE": "B ED", "LT": "Lib ED", "LTED": "Lib ED",
                "LIB": "Lib ED", "LIBERTY": "Lib ED", "LTUC": "LT UC", "LIBUC": "LT UC", "OPA": "OPE", "ANDERSON": "OPE",
                "EASTGATE": "OPE", "MASON": "OPM", "KENTUCKY": "OPKY", "CRESTVIEW": "OPKY", "GREEN": "OPGT"}
STYPE_LEVEL = {"Faculty": "F", "Senior Clinical": "C*", "Clinical": "C", "NP": "E",
               "Non-Faculty Clinical": "E", "Senior APRN": "SrAPP", "Supertrack": "E"}
LEVELS = {}   # role key ("Faculty", ..., "Fellow Y1".."Fellow Y4") -> {location type: allowed shift levels}; from data/roles.csv
ROLES = {}    # role key -> {"sites", "jeopardy", "trade_partner", "levels"}; from data/roles.csv (load_roles)
FELLOW_JUNIOR = {"Fellow Y1", "Fellow Y2"}   # regular trades only with each other
FELLOW_SENIOR = {"Fellow Y3", "Fellow Y4"}   # presumed faculty from the next July 1
LOC_TYPES = ("ED", "HBUC", "NUC", "VUC")
PERM_KEYS = ("sites", "jeopardy", "trade_partner")


def norm_site(s):
    s = s.strip()
    if s in ALL_SITES:
        return s
    k = re.sub(r"[^A-Z]", "", s.upper())
    for a, v in SITE_ALIASES.items():
        if k == re.sub(r"[^A-Z]", "", a):
            return v
    for v in ALL_SITES:
        if k == re.sub(r"[^A-Z]", "", v.upper()):
            return v
    return None


def jeop_tier(stype, name):
    t = (stype or "") + " " + (name or "")
    if "Call 3" in t or re.search(r"Jeop F\b", t):
        return "F"
    if "Call 2" in t or "Jeop CL" in t:
        return "CL"
    if "Call 1" in t or "Jeop APP" in t or "Jeop E" in t:
        return "APP"
    return None


def level_from_name(name, loc):
    n = name.replace("CL*", "C*").replace(" ML", " ").replace("ML", " ")
    if "M3" in n or "Physician Only" in n:
        return "C"
    if loc == "HBUC":
        return "SrAPP" if "*" in n else "E"
    if loc == "VUC":
        return "E"
    if re.search(r"C\*", n):
        return "C*"
    if re.search(r"(\d[ap]?\s?C\b|\bCL?\b)", n):
        return "C"
    if re.search(r"(\d[ap]?\s?[ER]\b|\b[ER]\b|Short|Bullpen|Psych|Flex|Lec|\bST\b)", n):
        return "E"
    if re.search(r"(\d[ap]?\s?F\d?\b)", n):
        return "F"
    if loc == "ED" and name.startswith("Lib"):
        return "E"  # e.g. "Lib 6p-12aML" (confirmed E)
    return None


def classify_level(facility, stype, fullname, shortname, loc):
    if loc == "JEOP":
        return jeop_tier(stype, fullname or shortname)
    if stype and stype != "Moonlighting" and stype in STYPE_LEVEL:
        return STYPE_LEVEL[stype]
    lv = level_from_name(fullname or shortname, loc) or level_from_name(shortname or "", loc)
    if lv is None:
        fb(f"Unknown shift level: '{fullname or shortname}' at {facility} (type '{stype}').")
    return lv


# ---------------------------------------------------------------- categories
CAT_LABEL = {"WD_DAY": "weekday day", "MT_EVE": "Mon-Thu evening", "FRI_EVE": "Friday evening",
             "WE_DAY": "weekend day", "WE_EVE": "weekend evening", "MT_ON": "Mon-Thu overnight",
             "FRI_ON": "Friday overnight", "WE_ON": "weekend overnight", "PERI": "pre-scheduled peri-holiday",
             "HOL_DAY": "holiday day", "HOL_EVE": "holiday evening", "HOL_ON": "holiday overnight"}
HOL_TIMES = ["HOL_DAY", "HOL_EVE", "HOL_ON"]   # holiday split into three shift times (plan 3.1)
HOL_OF_TC = {"day": "HOL_DAY", "evening": "HOL_EVE", "overnight": "HOL_ON"}
DEFAULT_ORDER = ["WD_DAY", "MT_EVE", "FRI_EVE", "WE_DAY", "WE_EVE", "MT_ON", "FRI_ON", "WE_ON"] + HOL_TIMES
TIME_IDX = {"day": 0, "evening": 1, "overnight": 2}


def expand_hol(keys):
    """Shift-time lists: "HOL"/"holiday" (the old single slot) means all three holiday times, at that position."""
    out = []
    for k in keys or []:
        for x in (HOL_TIMES if str(k).strip().upper() in ("HOL", "HOLIDAY") else [k]):
            if x not in out:
                out.append(x)
    return out


def minute_of_day(t):
    return t.hour * 60 + t.minute


def time_cat(start):
    m = minute_of_day(start)
    return "day" if DAY_START <= m < 16 * 60 else ("evening" if 16 * 60 <= m < 22 * 60 else "overnight")


def base_cat(sdate, tc):
    wd = sdate.weekday()
    if tc == "day":
        return "WE_DAY" if wd >= 5 else "WD_DAY"
    if tc == "evening":
        return "MT_EVE" if wd <= 3 else ("FRI_EVE" if wd == 4 else "WE_EVE")
    return "MT_ON" if wd <= 3 else ("FRI_ON" if wd == 4 else "WE_ON")


HOLIDAYS = {}  # date -> row
HOL_FYS = set()


def load_holidays():
    for fn in os.listdir(DATA):
        if fn.startswith("holidays_") and fn.endswith(".csv"):
            for r in csv.DictReader(open(os.path.join(DATA, fn), encoding="utf-8")):
                d = date.fromisoformat(r["date"])
                HOLIDAYS[d] = r
                HOL_FYS.add(r["academic_year"].strip().upper())


def fy_of(d):
    return "FY%02d" % ((d.year + 1 if d.month >= 7 else d.year) % 100)


def holiday_status(s):
    """Return ('HOL'|'PERI'|None, holiday name, block)."""
    r = HOLIDAYS.get(s.sdate)
    if not r:
        return None, "", ""
    tag = ("JEOP_" + s.level) if s.loc == "JEOP" else {"day": "DAY", "evening": "EVENING", "overnight": "OVERNIGHT"}[s.tc]
    hs = set(x for x in r["holiday_scopes"].split(";") if x)
    ps = set(x for x in r["prescheduled_scopes"].split(";") if x)
    if "ALL" in hs or tag in hs:
        return "HOL", r["holiday"], r["block"]
    if "ALL" in ps or tag in ps or "ALL_OTHER" in ps:
        return "PERI", r["holiday"], r["block"]
    return None, "", ""


# ---------------------------------------------------------------- shifts
class Shift:
    __slots__ = ("id", "facility", "site", "loc", "prefix", "full", "code", "stype", "level", "start", "end",
                 "hours", "sdate", "tc", "cat", "hol", "hol_name", "block", "is_ml", "is_jeop", "is_m3",
                 "notes", "buddy", "ml_pay", "who", "posted_by", "status", "src")

    def label(self):
        return f"{self.start:%m/%d %a} {self.code} {self.start:%H%M}-{self.end:%H%M}"

    def types(self):
        if self.hol == "HOL":
            return {HOL_OF_TC[self.tc]}
        t = {self.cat}
        if self.hol == "PERI":
            t.add("PERI")
        return t

    def rank(self, order):
        if self.is_jeop:  # Jeopardy: weekday (Mon-Thu) > weekend (Fri-Sun) > holiday
            if self.hol == "HOL":
                return 2
            return 1 if self.sdate.weekday() >= 4 else 0
        if self.hol == "HOL":
            k = HOL_OF_TC[self.tc]
            return order.index(k) if k in order else 99
        return order.index(self.cat) if self.cat in order else 98


def finish_shift(s):
    s.hours = round((s.end - s.start).total_seconds() / 3600, 2)
    s.sdate = (s.start - timedelta(days=1)).date() if minute_of_day(s.start) < DAY_START else s.start.date()
    s.tc = time_cat(s.start)
    s.cat = base_cat(s.sdate, s.tc)
    s.is_jeop = s.loc == "JEOP"
    s.is_m3 = "M3" in (s.full or s.code)
    s.hol, s.hol_name, s.block = holiday_status(s)
    return s


KNOWN_CODES = None


def known_code(fac, name):
    global KNOWN_CODES
    if KNOWN_CODES is None:
        KNOWN_CODES = set()
        fn = os.path.join(DATA, "shift_codes.csv")
        if os.path.exists(fn):
            for r in csv.DictReader(open(fn, encoding="utf-8")):
                KNOWN_CODES.add((r["facility"], r["shift_name"]))
                KNOWN_CODES.add((r["facility"], r["calendar_code"]))
    if (fac, name) not in KNOWN_CODES:
        fb(f"New shift code not in shift_codes.csv: '{name}' at {fac}.")


def unfold(txt):
    return re.sub(r"\r?\n[ \t]", "", txt)


VACS = []  # (schedule name, 'YYYYMMDD') from VCTN entries in the feed; attached only for the search window
NAME_RE = re.compile(r"((?:ML )?[A-Z][A-Za-z'\-]+(?:, ?[A-Z][a-z]?\.?)?)\s*$")


def parse_ics(txt):
    out = []
    floor = (now() - timedelta(days=8)).strftime("%Y%m%d")
    for blk in unfold(txt).split("BEGIN:VEVENT")[1:]:
        blk = blk.split("END:VEVENT")[0]
        d = {}
        for line in blk.strip().splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                d[k.split(";")[0]] = v
        summ0 = d.get("SUMMARY", "").replace("\\,", ",").strip()
        if summ0.startswith("VCTN "):
            ds = d.get("DTSTART", "")[:8]
            if ds.isdigit() and ds >= floor:
                VACS.append((summ0[5:].strip(), ds))
            continue
        desc = d.get("DESCRIPTION", "").replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";")
        f = {}
        for l in desc.split("\n"):
            if ":" in l:
                a, b = l.split(":", 1)
                f[a.strip()] = b.strip()
        fac = f.get("Facility", "")
        full = f.get("Shift", "")
        if fac in SKIP_FACILITIES or full in SKIP_SHIFTS:
            continue
        if fac not in FACILITY:
            fb(f"Unknown facility in feed: '{fac}' (shift '{full}').")
            continue
        summ = d.get("SUMMARY", "").replace("\\,", ",").strip()
        m = NAME_RE.search(summ)
        if not m:
            fb(f"Could not read a name from feed entry '{summ}'.")
            continue
        who = m.group(1)
        label_ml = who.startswith("ML ")
        if label_ml:
            who = who[3:]
        site, loc, prefix = FACILITY[fac]
        head = summ[:m.start()].strip()
        code = head[len(prefix) + 1:] if head.startswith(prefix + " ") else head
        if label_ml:
            code = code + " ML"
        s = Shift()
        uid = d.get("UID", "")
        s.id = (re.search(r"(\d+)@", uid) or re.search(r"(\d+)", uid) or re.search("(.*)", uid)).group(1)
        s.facility, s.site, s.loc, s.prefix, s.full, s.code = fac, site, loc, prefix, full, code
        s.stype = f.get("Shift Type", "")
        try:
            s.start = datetime.strptime(d["DTSTART"], "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc).astimezone(ET)
            s.end = datetime.strptime(d["DTEND"], "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc).astimezone(ET)
        except Exception:
            fb(f"Could not read the time of feed entry '{summ}'.")
            continue
        s.level = classify_level(fac, s.stype, full, code, loc)
        known_code(fac, full)
        note = f.get("Shift Note", "")
        s.notes = []
        if note:
            s.notes.append(note)
        if "Split Shift" in f:
            s.notes.append("segment of a split shift")
        nl = note.lower()
        s.buddy = "buddy" in nl
        s.ml_pay = "ml pay" in nl
        hours_not_ml = "not ml" in nl
        s.is_ml = (("ML" in full.upper().replace("HTML", "")) or label_ml or s.stype == "Moonlighting") and not hours_not_ml
        if hours_not_ml:
            s.notes.append("counted as a regular shift ('hours not ML')")
        s.who, s.posted_by, s.status, s.src = who, "", "", "feed"
        out.append(finish_shift(s))
    return out


# ---------------------------------------------------------------- feed loading
def feed_links():
    """Shipped ShiftAdmin links from SKILL_SENSITIVE.md, most reliable first: [(id, url)]."""
    rows = []
    try:
        for line in open(SENSITIVE, encoding="utf-8"):
            m = re.match(r"^- link: (\S+) \| (\S+) \| (\d+) \| (\d+)", line)
            if m:
                rows.append((m.group(1), m.group(2), int(m.group(3)), int(m.group(4))))
    except OSError:
        pass
    rows.sort(key=lambda r: (-(r[2] - r[3]), -r[2]))
    return [(r[0], r[1]) for r in rows]


def user_links(spec):
    """--links: JSON list (or a file holding one) of {"id", "url", "works": true/false} from memory."""
    if not spec:
        return []
    try:
        data = json.loads(open(spec, encoding="utf-8").read() if os.path.exists(spec) else spec)
    except (ValueError, OSError):
        print("ERROR: --links must be a JSON list of {\"id\", \"url\", \"works\"}.")
        sys.exit(2)
    return data


def net_problem(e):
    """'blocked' when the sandbox can't reach the site at all; otherwise a short reason."""
    if isinstance(e, urllib.error.HTTPError):
        return f"http {e.code}"
    msg = str(getattr(e, "reason", e))
    if "Tunnel connection failed" in msg or "403" in msg or "Name or service not known" in msg \
            or "Temporary failure in name resolution" in msg or "Network is unreachable" in msg:
        return "blocked"
    return type(e).__name__


def validate_schedule(shifts, txt):
    """Problems with a group schedule, as (check, found, usual, fix) tuples. Thresholds set 2026-09-23."""
    probs = []
    n = now().date()
    stamps = re.findall(r"^DTSTART(;[^:\n]*)?:(\S+)", txt, re.M)
    timed = [v for opt, v in stamps if not (opt or "").upper().startswith(";VALUE=DATE")]
    if timed and sum(1 for v in timed if not v.endswith("Z")) > 0.1 * len(timed):
        probs.append(("times in UTC", "local times", "UTC", "remake the link with Time Zone set to UTC"))
    fut = [s for s in shifts if s.sdate >= n]
    ahead = (max(s.sdate for s in fut) - n).days if fut else 0
    if ahead < 60:
        probs.append(("how far ahead", f"{ahead} days", "about 5 months", "remake the link without a short date range"))
    d30 = [s for s in fut if s.sdate < n + timedelta(days=30)]
    per_day = len(d30) / 30
    if per_day < 30:
        probs.append(("shifts per day (next 30 days)", f"{per_day:.0f}", "about 40",
                      "use the group schedule (Group Schedule > Cincinnati CDEM), not a personal or filtered one"))
    missing = [x for x in ALL_SITES + ["Jeopardy"] if x not in set(s.site for s in d30)]
    if missing:
        probs.append(("sites (next 30 days)", "missing " + ", ".join(missing), "all 9 sites plus Jeopardy",
                      "use the whole group schedule, not one site or group"))
    people = len(set(s.who for s in fut if s.sdate < n + timedelta(days=60)))
    if people < 100:
        probs.append(("people with shifts (next 60 days)", str(people), "about 125", "use the whole group schedule"))
    if not VACS:
        probs.append(("vacation entries", "none", "about 1,300", "remake the link with Include Vacation checked"))
    return probs


def report_schedule(shifts, txt, source, quiet):
    probs = validate_schedule(shifts, txt)
    for chk, found, usual, fix in probs:
        print(f"SCHEDULE_PROBLEM: {chk}: found {found} (usual: {usual}). Fix: {fix}.")
    if probs:
        fb(f"Invalid schedule from {source}: " + "; ".join(f"{c} = {f}" for c, f, _, _ in probs) + ".")
    elif not quiet:
        print("SCHEDULE_OK: the schedule looks complete.")
    return probs


def load_feed(ics=None, quiet=False, links=None, fail_ok=False):
    os.makedirs(WORK, exist_ok=True)
    cache = os.path.join(WORK, "feed.ics")
    src = None
    fresh = True
    if not ics and demo_active() and os.path.exists(DEMO_FEED):   # 2.11: the demo's archived copy (demo --schedule)
        txt, src, fresh = open(DEMO_FEED, encoding="utf-8").read(), "archived copy (demo)", False
    elif ics:
        txt = open(ics, encoding="utf-8", errors="replace").read()
        if "BEGIN:VCALENDAR" not in txt:
            print("ERROR: the attached file is not a calendar (.ics) file.")
            sys.exit(2)
        open(cache, "w", encoding="utf-8").write(txt)
        src = "attached file"
    elif os.path.exists(cache) and (datetime.now().timestamp() - os.path.getmtime(cache)) < CACHE_HOURS * 3600:
        txt = open(cache, encoding="utf-8").read()
        src = "cached copy (%d min old)" % ((datetime.now().timestamp() - os.path.getmtime(cache)) / 60)
        fresh = False
    else:
        saved = os.path.join(WORK, "links.json")   # the user's own links, kept from the last refresh --links
        if links is not None:
            mine = user_links(links)
            json.dump(mine, open(saved, "w", encoding="utf-8"))
        else:
            mine = user_links(saved if os.path.exists(saved) else None)
        rejected_by_user = {x["id"] for x in mine if not x.get("works", True)}
        order = [(x["id"], x["url"]) for x in mine if x.get("works", True)]
        order += [lk for lk in feed_links() if lk[0] not in {i for i, _ in order} | rejected_by_user]
        order += [(x["id"], x["url"]) for x in mine if not x.get("works", True)]
        txt, blocked, tried = None, False, 0
        for lid, url in order:
            tried += 1
            stamp = now().strftime("%Y-%m-%d %H:%M")
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "cincipem-shiftmate"})
                body = urllib.request.urlopen(req, timeout=90).read().decode("utf-8", "replace")
                if "BEGIN:VCALENDAR" not in body:
                    print(f"LINK_ATTEMPT: {lid} rejected (not a calendar) {stamp}")
                    continue
                print(f"LINK_ATTEMPT: {lid} worked {stamp}")
                txt, src = body, f"link {lid}"
                open(cache, "w", encoding="utf-8").write(txt)
                break
            except Exception as e:
                why = net_problem(e)
                if why == "blocked":
                    print(f"LINK_ATTEMPT: {lid} blocked {stamp}")
                    blocked = True
                    break  # every link is on the same site
                print(f"LINK_ATTEMPT: {lid} rejected ({why}) {stamp}")
        if txt is None:
            if os.path.exists(cache):
                txt = open(cache, encoding="utf-8").read()
                src = "older cached copy (live download failed)"
                fresh = False
                fb("Feed could not be fetched directly; used an older cached copy.")
            elif fail_ok:
                return None, "blocked" if blocked else "rejected"
            elif blocked:
                print("FETCH_FAILED: BLOCKED. The schedule site isn't in allowed domains. Give the allow-domain "
                      "steps, or have the primary user attach the schedule file, then run: refresh --ics <file>")
                sys.exit(3)
            else:
                print(f"FETCH_FAILED: LINK_REJECTED. ShiftAdmin rejected all {tried} link(s). Give the make-your-own-"
                      "link steps (SKILL.md), then run newlink with it, or have them attach the file.")
                sys.exit(3)
    load_holidays()
    shifts = parse_ics(txt)
    if fresh:
        report_schedule(shifts, txt, src, quiet)
    if not quiet:
        first = min(s.start for s in shifts)
        last = max(s.start for s in shifts)
        print(f"Feed: {src}; {len(shifts)} shifts, {first:%m/%d/%y}-{last:%m/%d/%y}.")
    return shifts, src


# ---------------------------------------------------------------- roster
def nkey(s):
    return re.sub(r"[^a-z]", "", s.lower())


def read_csv(fn):
    path = os.path.join(DATA, fn)
    return list(csv.DictReader(open(path, encoding="utf-8"))) if os.path.exists(path) else []


PREFS = {}  # "site"/"time" -> {name: [(key, rank, rating)] best first}


def load_prefs():
    """Shift-time and location preferences from data/time_prefs.csv and data/site_prefs.csv.
    Memory (sent in the request) overrides these; people with neither use the defaults."""
    if PREFS:
        return PREFS
    for kind, fn, col in (("time", "time_prefs.csv", "shift_time"), ("site", "site_prefs.csv", "site")):
        d = {}
        for r in read_csv(fn):
            try:
                d.setdefault(r["name"], []).append((r[col], int(r["rank"]), float(r["rating"] or 5)))
            except (KeyError, ValueError):
                fb(f"Bad row in {fn}: {r}")
        PREFS[kind] = {k: sorted(v, key=lambda x: x[1]) for k, v in d.items()}
    return PREFS


def site_order(req=None, clin=None):
    """Location order for every site list and table: memory's order, else site_prefs.csv, else the default."""
    order = []
    if req and req.get("site_order"):
        order = [x for x in (norm_site(v) for v in req["site_order"]) if x]
    elif clin is not None:
        order = [k for k, _, _ in load_prefs().get("site", {}).get(clin.name, [])]
    return order + [x for x in ALL_SITES if x not in order]


def sort_sites(sites, order):
    return sorted(sites, key=lambda x: order.index(x) if x in order else 99)


def role_key(role, fellow_year=""):
    return f"Fellow {fellow_year}" if role == "Fellow" else role


def roster_error(msg):
    """The roster can't be read safely: stop rather than guess anyone's permissions (packaging refuses the build too)."""
    print(f"ROSTER_ERROR: {msg} Tell the user the skill's roster file has a problem and to send feedback; don't search.")
    sys.exit(3)


def load_roles():
    """Standard permissions per role, from data/roles.csv (replaces the built-in table)."""
    if ROLES:
        return ROLES
    for r in read_csv("roles.csv"):
        k = role_key(r["role"].strip(), r["fellow_year"].strip())
        lv = {}
        for loc in LOC_TYPES:
            v = set(x for x in r[loc.lower() + "_levels"].split(";") if x)
            if v:
                lv[loc] = v
        tp = r["trade_partner"].strip()
        if tp not in ("Y", "N"):
            roster_error(f"roles.csv: trade_partner for {k} must be Y or N, not '{tp}'.")
        ROLES[k] = {"sites": set(x for x in r["sites"].split(";") if x), "levels": lv, "trade_partner": tp,
                    "jeopardy": set(x for x in r["jeopardy_pools"].split(";") if x)}
        LEVELS[k] = lv
    if not ROLES:
        roster_error("roles.csv is missing or empty.")
    return ROLES


def parse_exceptions(name, text):
    """staff.csv permission_exceptions: 'none', or 'sites=HBUC;NUC; jeopardy=none; trade_partner=N'."""
    text = (text or "").strip()
    if text.lower() in ("", "none"):
        return {}
    out = {}
    for m in re.finditer(r"\s*(\w+)\s*=\s*([^=]*?)\s*(?=;\s*\w+\s*=|$)", text):
        k, v = m.group(1), m.group(2).strip().strip(";")
        if k not in PERM_KEYS or k in out:
            roster_error(f"staff.csv: can't read the permission exception '{k}' for {name}.")
        vals = set(x.strip() for x in v.split(";") if x.strip() and x.strip().lower() != "none")
        ok = {"sites": set(LOC_TYPES), "jeopardy": {"F", "CL", "APP"}}.get(k)
        if k == "trade_partner":
            if v not in ("Y", "N"):
                roster_error(f"staff.csv: trade_partner exception for {name} must be Y or N.")
            out[k] = v
        elif not vals <= ok:
            roster_error(f"staff.csv: unknown value in the {k} exception for {name}: {', '.join(sorted(vals - ok))}.")
        else:
            out[k] = vals
    if re.sub(r"[\s;]", "", re.sub(r"(\w+)\s*=\s*([^=]*?)(?=;\s*\w+\s*=|$)", "", text)):
        roster_error(f"staff.csv: can't read the permission exceptions for {name}: '{text}'.")
    return out


BLOCK_DATE = r"\d{4}-\d{2}-\d{2}(?:\.\.\d{4}-\d{2}-\d{2})?"
BLOCK_WHEN = r"(?:day|evening|overnight|all|\d{2}:\d{2}-\d{2}:\d{2})"
BLOCK_RE = re.compile(rf"^{BLOCK_DATE} {BLOCK_WHEN}$")
RECUR_RE = re.compile(r"^(?:every|1st|2nd|3rd|4th|5th|last) (?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) (?:day|evening|overnight|all|\d{2}:\d{2}-\d{2}:\d{2})$")


def check_block_columns(r):
    """Blocked-date columns (plan 3.2, hour ranges 9.9): refuse a roster entry the script can't read."""
    for col, rx in (("blocked_dates", BLOCK_RE), ("recurring_blocked_dates", RECUR_RE),
                    ("exceptions_to_recurring_blocked_dates_or_vacations", BLOCK_RE)):
        for item in [x.strip() for x in (r.get(col) or "").split(";") if x.strip()]:
            if not rx.match(item):
                roster_error(f"staff.csv: can't read '{item}' in {col} for {r['name']}.")


class Person:
    def __init__(self, r):
        self.__dict__.update(r)
        roles = load_roles()
        key = role_key(r["role"], r["fellow_year"])
        if key not in roles:
            roster_error(f"staff.csv: {r['name']} has the role '{key}', which isn't in roles.csv.")
        exc = parse_exceptions(r["name"], r.get("permission_exceptions"))
        check_block_columns(r)
        self.exceptions = exc
        self.sites_set = set(exc.get("sites", roles[key]["sites"]))
        self.jeop_set = set(exc.get("jeopardy", roles[key]["jeopardy"]))
        self.trade_partner = exc.get("trade_partner", roles[key]["trade_partner"])
        self.shifts = []
        mine = []
        for k in expand_hol([k for k, _, _ in load_prefs().get("time", {}).get(r["name"], [])]):
            if k in CAT_LABEL and k not in mine:
                mine.append(k)
        self.order = mine + [k for k in DEFAULT_ORDER if k not in mine] if mine else DEFAULT_ORDER

    def status_on(self, d):
        """(role key for LEVELS and ROLES, sites, jeopardy set, fellow-year label) on date d."""
        if self.role != "Fellow":
            return self.role, self.sites_set, self.jeop_set, ""
        orig = y = int(self.fellow_year[1])
        if y == 4:
            y = 3
        promos = 0
        cutoff = date(2000 + ROSTER_FY, 7, 1)
        while d >= cutoff:
            promos += 1
            cutoff = date(cutoff.year + 1, 7, 1)
        y += promos
        if y >= 4:
            fac = load_roles()["Faculty"]
            return "Faculty", set(fac["sites"]), set(fac["jeopardy"]), "graduated (presumed faculty)"
        key = "Fellow Y4" if orig == 4 and not promos else "Fellow Y%d" % y
        if promos:   # moved up a year: the new year's standard permissions
            return key, set(ROLES[key]["sites"]), set(ROLES[key]["jeopardy"]), "Y%d" % y
        return key, self.sites_set, self.jeop_set, key.split()[-1]   # a Y4 year is Y4 (fix 3 #6), not Y3

    def first(self):
        return self.name.split()[0]


def load_roster():
    people = [Person(r) for r in read_csv("staff.csv")]
    by_sched = {}
    for p in people:
        by_sched[nkey(p.schedule_name)] = p
    return people, by_sched


def attach(shifts, people, by_sched):
    unknown = {}
    for s in shifts:
        p = by_sched.get(nkey(s.who))
        if p is None:
            # fall back: last name + first initial
            m = re.match(r"(.+?),\s*([A-Z])", s.who)
            if m:
                cands = [q for q in people if nkey(q.schedule_name).startswith(nkey(m.group(1)) + m.group(2).lower())]
                p = cands[0] if len(cands) == 1 else None
        if p is None:
            unknown[s.who] = unknown.get(s.who, 0) + 1
            s.who = None
            continue
        s.who = p
        p.shifts.append(s)
    for p in people:
        p.shifts.sort(key=lambda x: x.start)
        p.vac = set()
    for n, c in unknown.items():
        fb(f"Name in schedule not on roster: '{n}' ({c} shifts). Needs role and email.")
    return unknown


def attach_vacations(people, by_sched, lo, hi):
    """Read ShiftAdmin vacations only for dates lo..hi (the search window)."""
    a, b = lo.strftime("%Y%m%d"), hi.strftime("%Y%m%d")
    for nm, ds in VACS:
        if not (a <= ds <= b):
            continue
        d = datetime.strptime(ds, "%Y%m%d").date()
        p = by_sched.get(nkey(nm))
        if p is None:
            m = re.match(r"(.+?),\s*([A-Z])", nm)
            if m:
                cands = [q for q in people if nkey(q.schedule_name).startswith(nkey(m.group(1)) + m.group(2).lower())]
                p = cands[0] if len(cands) == 1 else None
        if p is not None:
            p.vac.add(d)


def find_person(people, name):
    k = nkey(name)
    for p in people:
        keys = [nkey(p.name), nkey(p.schedule_name)] + [nkey(a) for a in p.aliases.split(";") if a]
        if k in keys:
            return [p]
    toks = [t for t in re.split(r"[\s,]+", name.lower()) if t]
    hits = [p for p in people if all(any(nkey(t) in nkey(x) for x in [p.name, p.aliases, p.schedule_name]) for t in toks)]
    return hits


class Admin:
    """An administrative user (data/admins.csv): runs the skill for clinicians, never a clinician or colleague."""
    is_admin = True
    role = "Administrator"
    fellow_year = ""

    def __init__(self, r):
        self.__dict__.update(r)


def load_admins():
    return [Admin(r) for r in read_csv("admins.csv")]


NICKNAMES = {  # short form -> formal first names it can stand for
    "becca": ["rebecca"], "becky": ["rebecca"], "beth": ["elizabeth"], "liz": ["elizabeth"], "lizzie": ["elizabeth"],
    "betsy": ["elizabeth"], "kate": ["katherine", "kathryn", "kate"], "katie": ["katherine", "kathryn"],
    "kathy": ["katherine", "kathryn"], "chris": ["christopher", "christina"], "tim": ["timothy"], "ben": ["benjamin"],
    "dan": ["daniel"], "danny": ["daniel"], "matt": ["matthew"], "nate": ["nathan"], "steve": ["stephen", "steven"],
    "jen": ["jennifer", "jenn"], "jenn": ["jennifer"], "jenny": ["jennifer"], "sam": ["samantha", "samuel"],
    "alex": ["alexander", "alexandra"], "vicky": ["victoria"], "vicki": ["victoria"], "tori": ["victoria"],
    "connie": ["constance"], "gwen": ["gwendolyn"], "maggie": ["margaret"], "meg": ["megan", "margaret"],
    "rick": ["richard"], "rich": ["richard"], "dick": ["richard"], "bill": ["william"], "will": ["william"],
    "pat": ["patrick", "patricia"], "jim": ["james"], "jamie": ["james"], "mike": ["michael"], "fred": ["fredrick"],
    "freddie": ["fredrick"], "tom": ["thomas"], "tony": ["anthony"], "andy": ["andrew"], "abby": ["abigail"],
    "annie": ["anna", "anne", "annemarie"], "mel": ["melinda", "melissa"], "melinda": ["e. melinda"],
}


def split_name(txt):
    """'Dr. Jane Q. Doe, MD' / 'Doe, Jane' -> ('jane', 'doe', all tokens)."""
    t = re.sub(r"\b(dr|md|do|phd|np|pa|aprn|rn|mph|med|ms|msn|pa-c)\b\.?", " ", txt, flags=re.I)
    if "," in t:
        last, _, first = t.partition(",")
        t = first + " " + last
    toks = [x for x in re.split(r"[\s.]+", t.strip()) if x]
    return toks


def similar(a, b):
    import difflib
    a, b = nkey(a), nkey(b)
    if not a or not b:
        return False
    return a == b or difflib.SequenceMatcher(None, a, b).ratio() >= 0.8


ASK_MAINTAINER = ("Someone new to the division, or whose name changed recently, can ask the maintainer (feedback_name / "
                  "feedback_email in SKILL_SENSITIVE.md) to be added.")


def reads(*paths):
    """' (read <file> and <file>)': the workflow or branch file a marker needs (plan 1.4). Claude reads it before acting."""
    return " (read " + " and ".join(paths) + ")"


NAME_REPLIES = "workflows/setup/name-check-replies.md"
NEW_VERSION = "workflows/startup/new-version.md"


def cmd_whoami_setup(args, people, admins):
    """First-setup name check: exact match, 'did you mean' (first AND last name both close), or a miss.
    Three tries in total; setup locks for 24 h after the third miss (the count lives in Local Data's lockout.json;
    --tries-used is for tests without Local Data)."""
    toks = split_name(args.name)
    demo = len(toks) >= 3 and toks[-1].lower() == "demo"   # 2.11: "<name> Demo" starts a demo; "Demo" isn't a try
    if demo:
        toks = toks[:-1]
        args.name = " ".join(toks)
    used = max(0, args.tries_used)
    if LD_ROOT and not demo:
        used = ld_name_tries()
    also_admin = {nkey(a.staff_row) for a in admins if getattr(a, "staff_row", "")}
    everyone = [(p, False) for p in people] + [(a, True) for a in admins if not getattr(a, "staff_row", "")]
    if used >= 3:
        print("LOCKED_OUT" + reads("workflows/startup/lockout.md") + ": three names that weren't on the roster have been tried; setup is locked for 24 hours from the "
              "third. " + ASK_MAINTAINER + " Stop.")
        return
    if len(toks) < 2 or len(nkey(toks[-1])) <= 1:
        print("NEED_FULL_NAME: ask for their first and last name (the whole last name). This doesn't use up a try.")
        return
    first, last = toks[0], toks[-1]
    exact, close = [], []
    for p, adm in everyone:
        forms = [split_name(f) for f in [p.name] + [a for a in (p.aliases or "").split(";") if a.strip()]]
        forms = [ft for ft in forms if len(ft) >= 2]
        verdict = None
        for ft in forms:
            pf, pl = ft[0], ft[-1]
            last_forms = [pl, "".join(ft[1:])]   # last names of two or more words
            last_exact = any(nkey(last) == nkey(x) for x in last_forms) or nkey("".join(toks[1:])) in [nkey(x) for x in last_forms]
            if nkey(first) == nkey(pf) and last_exact:
                verdict = "exact"
                break
            first_close = similar(first, pf) or nkey(pf) in NICKNAMES.get(nkey(first), []) or \
                nkey(first) in NICKNAMES.get(nkey(pf), [])
            if first_close and (last_exact or any(similar(last, x) for x in last_forms)):
                verdict = "close"
        if verdict == "exact":
            exact.append((p, adm))
        elif verdict == "close":
            close.append((p, adm))
    def desc(p, adm, mark=False):
        return f"{p.name} ({'Administrator' if adm else role_label(p)})"
    if len(exact) == 1:
        p, adm = exact[0]
        if not adm and p.role == "Moonlighter":
            print(f"SETUP_MATCH_MOONLIGHTER{reads(NAME_REPLIES)}: {desc(p, adm)}. This skill is for regular division staff; moonlighters "
                  "aren't set up to use it. Explain kindly; this isn't a miss.")
            return
        if demo:
            demo_begin()
            print(f"SETUP_MATCH: {desc(p, adm)} | DEMO: setup stops here (nothing is saved)"
                  + ("; an administrator: the demo searches for a clinician they name." if adm else "."))
            for x in demo_lines():
                print(x)
            return
        print(f"SETUP_MATCH: {desc(p, adm)}{' | ADMIN' + reads('workflows/setup/administrator.md') + ': always ask who they are running it for' if adm else ''}"
              f"{' | ALSO_ADMIN' + reads('workflows/startup/role-question.md') + ': also an administrator (admins.csv): ask the role question now; Administrator: administrator setup (workflows/setup/administrator.md), save clinician setup: not done; Clinician: the full clinician setup' if not adm and nkey(p.name) in also_admin else ''}")
        if LD_ROOT:
            ld_name_try(reset=True)
        else:
            print("SAVE: name tries: 0")
        return
    cands = exact or close
    if cands:
        print("DID_YOU_MEAN: " + "; ".join(desc(p, a, True) for p, a in cands[:3]) + ". Ask with one button per name "
              "plus 'None of these'. After a yes, run whoami --setup again with that exact name (it checks moonlighters "
              "and administrators)" + (", followed by \" Demo\"" if demo else "") + ". This doesn't use up a try.")
        return
    left = max(0, 3 - (used + 1))
    if left:
        print(f"NO_MATCH{reads(NAME_REPLIES)}: '{args.name}' isn't on the CinciPEM roster. Tries left: {left}."
              + (" Say this is the last try before setup pauses for 24 hours." if left == 1 else ""))
        if LD_ROOT:
            ld_name_try()
        else:
            print(f"SAVE: name tries: {used + 1}")
    else:
        until = (now() + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M")
        print(f"LOCKOUT{reads(NAME_REPLIES)}: third name that isn't on the roster; setup is locked until {until}. Explain the skill is only "
              "for Division of Emergency Medicine staff. " + ASK_MAINTAINER + " Then ask (Yes / No) whether you may let "
              "the maintainer know now, so they can add them; on yes, send the feedback right away. Then stop.")
        if LD_ROOT:
            ld_name_try()
        else:
            print(f"SAVE: name tries: 3; locked until: {until}")
        fb(f"Setup locked after 3 names not on the roster (last tried: '{args.name}'). Possibly a new staff member to add.")
    print_feedback()


# ---------------------------------------------------------------- rules
def gap(a, b):
    if a.end <= b.start:
        return b.start - a.end
    if b.end <= a.start:
        return a.start - b.end
    return None  # overlap


def check(sched, add, remove_ids=(), b2b=False, m3=False):
    """Can this person work `add` after dropping `remove_ids`? -> (ok, reason, warnings)."""
    others = [o for o in sched if o.id not in remove_ids and o.id != add.id]
    warns = []
    b2b_hit = False
    for o in others:
        g = gap(o, add)
        if g is None:
            return False, f"overlaps {o.code} {o.start:%m/%d}", warns
        if g < 8 * H:
            if b2b and g <= H:
                b2b_hit = True
            elif b2b is None and g <= H:   # 4.1: back-to-back shifts are off for this clinician
                return False, f"back-to-back with {o.code} {o.start:%m/%d}; back-to-back shifts are off", warns
            elif m3 and add.is_m3 and o.start >= add.end:
                warns.append(f"M3 short rest: only {g.total_seconds()/3600:.1f} h before {o.code} {o.start:%m/%d %H%M}")
            else:
                side = "after" if o.end <= add.start else "before"
                return False, f"under 8 h rest {side} {o.code} {o.start:%m/%d}", warns
    if b2b_hit:
        chain = [add]
        grew = True
        while grew:
            grew = False
            for o in others:
                if o not in chain and any((gap(o, c) is not None and gap(o, c) <= H) for c in chain):
                    chain.append(o)
                    grew = True
        total = (max(c.end for c in chain) - min(c.start for c in chain)).total_seconds() / 3600
        if total > 12.25:
            return False, f"back-to-back would total {total:.1f} h", warns
        warns.append(f"BACK-TO-BACK with " + ", ".join(f"{c.code} {c.start:%m/%d %H%M}" for c in chain if c is not add)
                     + f": {total:g} h in a row")
    days = set(o.sdate for o in others) | {add.sdate}
    d = add.sdate
    while d - timedelta(days=1) in days:
        d -= timedelta(days=1)
    run = 0
    while d + timedelta(days=run) in days:
        run += 1
    if run > 7:
        return False, f"{run} days in a row", warns
    return True, "", warns


def rest_limit(sched, cands, remove_ids, b2b):
    """9.4: the same 8 h rest rule for every shift (Jeopardy, the R 12a-4a shift, anything ending in the early morning).
    When some of cands fit and others fail only on rest, say which starts or ends still fit -> text or None."""
    fit, rest = [], []
    for c in cands:
        ok, r, _ = check(sched, c, remove_ids=remove_ids, b2b=b2b)
        if ok:
            fit.append(c)
        elif "rest" in r:
            rest.append((c, r))
    if not fit or not rest:
        return None
    lo, hi = min(c.start for c in fit), max(c.end for c in fit)
    bits = []
    early = [r for c, r in rest if c.start < lo]
    late = [r for c, r in rest if c.end > hi]
    if early:
        bits.append(f"only shifts starting {lo:%H:%M} or later fit (earlier ones: {early[0]})")
    if late:
        bits.append(f"only shifts ending {hi:%H:%M} or earlier fit (later ones: {late[0]})")
    return "; ".join(bits) or None


# ---------------------------------------------------------------- request helpers
def parse_dates(spec, default_from, default_to):
    """spec: list of 'YYYY-MM-DD' or ['from','to'] or 'all'. -> set of dates."""
    if not spec or spec == "all":
        return set(default_from + timedelta(days=i) for i in range((default_to - default_from).days + 1))
    out = set()
    for x in spec:
        if isinstance(x, (list, tuple)):
            a, b = date.fromisoformat(x[0]), date.fromisoformat(x[1])
            out |= set(a + timedelta(days=i) for i in range((b - a).days + 1))
        else:
            out.add(date.fromisoformat(x))
    return out


WD = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}


def cat_covers(cat, s):
    """Does a block's shift time cover shift s? day/evening/overnight, a shift-time code (WE_DAY, HOL_EVE...),
    "holiday" (any holiday shift) or "all"/none (the whole day)."""
    if not cat or cat == "all":
        return True
    if cat in HOL_TIMES:
        return s.hol == "HOL" and HOL_OF_TC.get(s.tc) == cat
    return cat in (s.tc, s.cat) or (cat == "holiday" and s.hol == "HOL")


BLOCK_CATS = {"day", "evening", "overnight", "holiday", "all"} | set(CAT_LABEL)
HOURS_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d-([01]\d|2[0-3]):[0-5]\d$")


def bad_block(b):
    """Why a request block (or vacation) can't be read -> text, or None when it's fine (plan 7: bad entries rejected,
    never silently ignored: a block that can't be read would let a blocked date be offered)."""
    if not isinstance(b, dict):
        return "not a block ({...})"
    try:
        if "date" in b:
            date.fromisoformat(str(b["date"]))
        if "range" in b:
            r = b["range"]
            if not (isinstance(r, list) and len(r) == 2 and date.fromisoformat(r[0]) <= date.fromisoformat(r[1])):
                return "range must be [\"YYYY-MM-DD\", \"YYYY-MM-DD\"], earliest first"
    except (ValueError, TypeError):
        return "dates must be YYYY-MM-DD"
    if "hours" in b and not HOURS_RE.match(re.sub(r"\s+", "", str(b["hours"]))):
        return "hours must be HH:MM-HH:MM on a 24-hour clock (e.g. 18:00-20:00)"
    if b.get("cat") and b["cat"] not in BLOCK_CATS:
        return f"shift time must be one of day, evening, overnight, holiday, all or a shift-time code"
    if "weekday" in b and str(b["weekday"])[:3].lower() not in WD:
        return "weekday must be Mon-Sun"
    if "nth" in b and b["nth"] not in (1, 2, 3, 4, 5, -1):
        return "nth must be 1-5 or -1 (last)"
    if b.get("site") and not norm_site(b["site"]):
        return "unknown site"
    return None


NONE_WORDS = {"", "none", "no", "nothing", "n/a", "na", "-", "[]", "no dates", "no blocks", "no blocked dates"}
LIST_FIELDS = ("blocks", "my_blocks", "blocked_dates", "vacations", "work_on_vacation", "vacation_exceptions",
               "blocked_dates_shared")   # fix 3 #1: saved as lists; "none" (setup/main.md) is an empty list


def as_list(v, keep_str=False):
    """A list-type value however it was saved: None / "none" / "" -> [], a JSON string -> its list, a dict -> [dict],
    other text -> [text] (or the text itself with keep_str, for 'blocked dates shared' written in words). Never lets a
    caller iterate a string letter by letter."""
    if v is None:
        return []
    if isinstance(v, list):
        return v
    if isinstance(v, (dict, int, float)):
        return [v]
    s = str(v).strip()
    if s.lower().rstrip(".") in NONE_WORDS:
        return []
    if s[:1] in "[{":
        try:
            return as_list(json.loads(s), keep_str)
        except ValueError:
            pass
    return s if keep_str else [s]


def norm_req_lists(req):
    """Request (or filled-in Local Data) blocks, vacations and work_on_vacation as lists (fix 3 #1)."""
    for k in ("blocks", "vacations", "work_on_vacation"):
        if k in req:
            req[k] = as_list(req[k])
    return req


def check_blocks(req):
    """Stop with BAD_BLOCK when any request block or vacation can't be read (never search around a block silently
    dropped)."""
    norm_req_lists(req)
    bad = []
    for b in req.get("blocks") or []:
        why = bad_block(b)
        if why:
            shown = {k: v for k, v in b.items() if k != "label"} if isinstance(b, dict) else b   # C1:175: never the label
            bad.append(f"{json.dumps(shown)}: {why}")
    for v in req.get("vacations") or []:
        why = bad_block({"range": v} if isinstance(v, list) else {"date": v})
        if why:
            bad.append(f"vacation {json.dumps(v)}: {why}")
    if bad:
        print("BAD_BLOCK: these blocked dates can't be read, so nothing was searched: " + " | ".join(bad)
              + ". Fix them (ask the user if it isn't clear what they meant) and run it again.")
        sys.exit(2)


def blocked(s, blocks, vacations):
    """Is shift s blocked for the clinician? -> reason or None."""
    for v in as_list(vacations):
        if (isinstance(v, list) and date.fromisoformat(v[0]) <= s.sdate <= date.fromisoformat(v[1])) or \
                (isinstance(v, str) and date.fromisoformat(v) == s.sdate):
            return "vacation"
    for b in as_list(blocks):
        if not isinstance(b, dict):
            continue   # check_blocks already stopped a search on a block it can't read
        if b.get("except") and any(block_match(s, e) for e in b["except"]):
            continue   # a date they said they CAN work (roster exceptions column, plan 3.2)
        if b.get("hours"):   # exact hours (plan 9.9, R7): any shift overlapping them
            if block_match(s, b):
                return block_reason(b)
            continue
        if not cat_covers(b.get("cat"), s):
            continue
        if "date" in b and date.fromisoformat(b["date"]) != s.sdate:
            continue
        if b.get("site") and norm_site(b["site"]) != s.site:
            continue
        if "range" in b and not (date.fromisoformat(b["range"][0]) <= s.sdate <= date.fromisoformat(b["range"][1])):
            continue
        if "weekday" in b:
            if s.sdate.weekday() != WD[b["weekday"][:3].lower()]:
                continue
            if "nth" in b:
                n = (s.sdate.day - 1) // 7 + 1
                if b["nth"] == -1:
                    if (s.sdate + timedelta(days=7)).month == s.sdate.month:
                        continue
                elif n != b["nth"]:
                    continue
        return block_reason(b)
    return None


SYSTEM_BLOCK_LABELS = ("blocked on the roster", "recurring block on the roster", "ShiftAdmin vacation")


def block_reason(b):
    """C1:175: a block's own label (what it's for) never appears in script output, counts or usage: just "blocked".
    Only the script's own labels (roster blocks, ShiftAdmin vacation) are named."""
    lb = b.get("label")
    return f"blocked ({lb})" if lb in SYSTEM_BLOCK_LABELS else "blocked"


def block_day(b, d):
    """Does block (or exception) b cover calendar date d? (date, range, weekday with nth; none of them = every day)"""
    if "date" in b and date.fromisoformat(b["date"]) != d:
        return False
    if "range" in b and not (date.fromisoformat(b["range"][0]) <= d <= date.fromisoformat(b["range"][1])):
        return False
    if "weekday" in b:
        if d.weekday() != WD[b["weekday"][:3].lower()]:
            return False
        if "nth" in b:
            if b["nth"] == -1:
                return (d + timedelta(days=7)).month != d.month
            return (d.day - 1) // 7 + 1 == b["nth"]
    return True


def block_match(s, b):
    """Does block (or exception) b cover shift s? Shift times by the shift's date; exact hours ("hours": "14:00-18:00")
    by overlap with the shift's real start and end, on each calendar day it touches (plan 9.9, R7)."""
    if b.get("site") and norm_site(b["site"]) != s.site:
        return False
    if b.get("hours"):
        h1, h2 = [minute_of_day(datetime.strptime(x.strip(), "%H:%M")) for x in re.sub(r"\s+", "", b["hours"]).split("-")]
        d = s.start.date() - timedelta(days=1)
        while d <= s.end.date():
            if block_day(b, d):
                ws = datetime(d.year, d.month, d.day, tzinfo=s.start.tzinfo) + timedelta(minutes=h1)
                we = datetime(d.year, d.month, d.day, tzinfo=s.start.tzinfo) + timedelta(minutes=h2 if h2 > h1 else h2 + 1440)
                if s.start < we and ws < s.end:
                    return True
            d += timedelta(days=1)
        return False
    if not cat_covers(b.get("cat"), s):
        return False
    return block_day(b, s.sdate)


ORDINAL = {"every": None, "1st": 1, "2nd": 2, "3rd": 3, "4th": 4, "5th": 5, "last": -1}


def roster_block(item, recurring=False):
    """One staff.csv blocked-date item -> a request block ('2026-11-25 evening', '2026-12-01..2026-12-03 all',
    '2026-12-10 14:00-18:00', 'every Wed day', '3rd Thu evening', 'last Fri 14:00-18:00')."""
    head, when = item.rsplit(" ", 1)
    if recurring:
        nth, wd = head.split(" ")
        b = {"weekday": wd}
        if ORDINAL[nth] is not None:
            b["nth"] = ORDINAL[nth]
    elif ".." in head:
        b = {"range": head.split("..")}
    else:
        b = {"date": head}
    if re.match(r"\d{2}:\d{2}-\d{2}:\d{2}$", when):
        b["hours"] = when
    elif when != "all":
        b["cat"] = when
    return b


def roster_blocks(p):
    """(blocks, exceptions) from a person's three blocked-date columns in staff.csv (plan 3.2)."""
    items = lambda col: [x.strip() for x in (getattr(p, col, "") or "").split(";") if x.strip()]
    blocks = [dict(roster_block(x), label="blocked on the roster") for x in items("blocked_dates")]
    exc = [roster_block(x) for x in items("exceptions_to_recurring_blocked_dates_or_vacations")]
    for x in items("recurring_blocked_dates"):
        b = dict(roster_block(x, True), label="recurring block on the roster")
        if exc:
            b["except"] = exc
        blocks.append(b)
    return blocks, exc


def add_roster_blocks(clin, req):
    """Load the clinician's own roster blocks into the search, merged with the request's (plan 3.2). A roster exception
    on a ShiftAdmin vacation day makes just that shift time (or those hours) workable. "roster_blocks": false skips it."""
    if req.get("roster_blocks") is False:
        return
    blocks, exc = roster_blocks(clin)
    have = [{k: v for k, v in b.items() if k != "label"} for b in req.get("blocks") or []]
    new = [b for b in blocks if {k: v for k, v in b.items() if k != "label"} not in have]
    for e in exc:
        for d in sorted(d for d in getattr(clin, "vac", set()) if block_day(e, d)):
            clin.vac.discard(d)
            new.append({"date": d.isoformat(), "label": "ShiftAdmin vacation", "except": [e]})
    if new:
        req["blocks"] = list(req.get("blocks") or []) + new
        print(f"ROSTER_BLOCKS: {len(new)} blocked-date item(s) from the roster for {clin.name} are used in this search "
              "(`myblocks` lists them). If they no longer apply, rerun with \"roster_blocks\": false and put the change "
              "in feedback (their own dates only).")


def work_on_vacation(clin, req, n):
    """Request "work_on_vacation": ShiftAdmin vacation days the clinician can work. A plain date (or [from, to], or
    "<date> all") frees the whole day; "<date> day|evening|overnight" or "<date> HH:MM-HH:MM" (the roster block
    grammar, dates or ranges) frees only that shift time or those hours, like a roster exception (Patrick 9/27)."""
    parts = []
    for x in req.get("work_on_vacation") or []:
        if isinstance(x, str) and " " in x.strip() and BLOCK_RE.match(x.strip()):
            e = roster_block(x.strip())
            days = sorted(d for d in clin.vac if block_day(e, d))
            if "cat" not in e and "hours" not in e:   # "all": the whole day
                clin.vac.difference_update(days)
                continue
            for d in days:
                clin.vac.discard(d)
                req["blocks"] = list(req.get("blocks") or []) + [
                    {"date": d.isoformat(), "hours": "00:00-23:59", "label": "ShiftAdmin vacation", "except": [e]}]
            when = e.get("hours") or e["cat"]
            parts.append(f"{x.strip()}: " + (f"only {when} {'shifts' if 'cat' in e else '(shifts overlapping those hours)'}"
                                             f" on {compress_dates(days)}; the rest of the day stays vacation" if days
                                             else "not a ShiftAdmin vacation day, nothing to free"))
            continue
        if isinstance(x, str) and " " in x.strip():
            parts.append(f"{x.strip()}: can't read it (use \"<date> day|evening|overnight|all|HH:MM-HH:MM\"), not used")
            continue
        for d in parse_dates([x], n, n):
            clin.vac.discard(d)
    if parts:
        print("WORK_ON_VACATION (vacation days freed for one shift time only): " + " | ".join(parts)
              + ". Tell them a shift time frees only that shift time, and confirm that's what they meant.")


def load_req(path):
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception as e:
        print(f"ERROR: could not read request file {path}: {e}")
        sys.exit(2)


def setup(args, need_clinician=True):
    shifts, src = load_feed(getattr(args, "ics", None), quiet=True)
    people, by_sched = load_roster()
    unknown = attach(shifts, people, by_sched)
    req = load_req(args.req) if getattr(args, "req", None) else {}
    if LD_ROOT and not demo_active():
        ld_fill_req(req, args.cmd)
    check_blocks(req)
    if demo_active():   # 2.11: a demo always searches with the defaults, whatever the request says
        dropped = [k for k in DEMO_DROP if req.pop(k, None) not in (None, "", [], {}, False)]
        req.update(roster_blocks=False, back_to_back=False, who="you")
        if dropped:
            print("DEMO_DEFAULTS: left out " + ", ".join(dropped) + " (a demo uses the default settings).")
    global WHO
    WHO = str(req.get("who") or "").strip() or "you"
    clin = None
    if need_clinician and not str(req.get("clinician") or "").strip():
        prim = ld_primary_name() if (LD_ROOT and not demo_active() and WHO.lower() == "you") else ""
        if prim:   # fix 3 #7: the primary user's own search defaults to their saved roster name (About you)
            req["clinician"] = prim
        else:
            print("ERROR: no clinician in the request: add \"clinician\": \"<their roster name>\" (the name whoami "
                  "matched) and run it again.")
            sys.exit(2)
    if need_clinician:
        hits = find_person(people, req.get("clinician", ""))
        if len(hits) != 1:
            print("ERROR: clinician '%s' matched %d roster entries: %s" % (
                req.get("clinician"), len(hits), "; ".join(h.name for h in hits[:6])))
            sys.exit(2)
        clin = hits[0]
        if demo_active():   # DEMO_DEFAULTS (C4:55): the default shift-time order and no location preference
            clin.order = list(DEFAULT_ORDER)
            for kind in ("site", "time"):
                load_prefs().get(kind, {}).pop(clin.name, None)
        role = req.get("role_override")
        want = (role or {}).get("role") or (role or {}).get("tier")   # "tier" accepted from 0.01.07 memory
        if want and want != clin.role:
            print(f"ROLE_OVERRIDE: searching as {want}{' ' + role.get('fellow_year', '') if role.get('fellow_year') else ''}"
                  f" (the roster says {clin.role}{' ' + clin.fellow_year if clin.fellow_year else ''}). The schedulers have the final say.")
            clin.role = want
            clin.fellow_year = role.get("fellow_year", "")
            std = load_roles().get(role_key(clin.role, clin.fellow_year), {})
            clin.sites_set = set(role.get("sites") or std.get("sites") or clin.sites_set)
            clin.jeop_set = set(role.get("jeopardy") or std.get("jeopardy") or clin.jeop_set)
    # window = the dates this search can touch (trade-into/pickup dates plus the shifts being given up)
    n = now().date()
    last = max(s.sdate for s in shifts)
    days = parse_dates(req.get("into") or req.get("dates"), n, last)
    ids = set(str(x) for x in req.get("give_ids", []))
    days |= set(s.sdate for s in shifts if s.id in ids)
    if days:
        attach_vacations(people, {nkey(p.schedule_name): p for p in people}, min(days) - timedelta(days=1),
                         max(days) + timedelta(days=1))
    if clin:
        work_on_vacation(clin, req, n)
        add_roster_blocks(clin, req)
    return shifts, people, clin, req, src


def all_vacations(req):
    return list(req.get("vacations") or [])


def on_vacation(p, s):
    """True if any calendar day the shift touches is a ShiftAdmin vacation day for p."""
    if not getattr(p, "vac", None):
        return False
    d, last = s.start.date(), (s.end - timedelta(minutes=1)).date()
    while d <= last:
        if d in p.vac:
            return True
        d += timedelta(days=1)
    return s.sdate in p.vac


VAC_EXC = {}   # (shift id, colleague name) -> date: a colleague freed from a ShiftAdmin vacation by a roster exception


def colleague_off(P, S):
    """Plan 3.2 (answer yes): is colleague P off for shift S by a ShiftAdmin vacation or their own roster blocks?
    -> the reason (a why-not count) or None. A roster exception on a vacation day frees only the shift time it names;
    no shift time ("all") frees the whole day; an hour range frees the shifts it overlaps (Patrick's reading, 9/27).
    A freed colleague is kept in VAC_EXC so the results can warn that ShiftAdmin still has them on vacation."""
    blocks, exc = roster_blocks(P)
    if on_vacation(P, S):
        if not any(block_match(S, e) for e in exc):
            return "colleagues on vacation that day"
        VAC_EXC[(S.id, P.name)] = S.sdate
    if blocks and blocked(S, blocks, []):
        return "colleagues' blocked dates (roster)"
    return None


def print_vac_exceptions(pairs):
    """COLLEAGUE_VACATION_EXCEPTION for the (shift id, colleague name) pairs in the results that a roster exception
    freed from a ShiftAdmin vacation (plan 3.2)."""
    hits = sorted({(n, VAC_EXC[(sid, n)]) for sid, n in pairs if (sid, n) in VAC_EXC}, key=lambda x: (x[1], x[0]))
    if hits:
        print("COLLEAGUE_VACATION_EXCEPTION: ShiftAdmin has these colleagues on vacation, but they've said on the roster "
              "that they might be available; say so next to them before offering: "
              + "; ".join(f"{n} ({d:%m/%d})" for n, d in hits))


def eligible(p, s, clin, trade_is_ml):
    """Can person p (as clinician or colleague) work shift s by privileges?"""
    if p.role == "Moonlighter":
        return False
    key, sites, jeop, fy = p.status_on(s.sdate)
    if s.loc == "JEOP":
        return s.level in jeop
    if s.loc not in sites:
        return False
    allowed = LEVELS.get(key, {}).get(s.loc, set())
    if s.level not in allowed:
        return False
    if p is not clin and key in FELLOW_JUNIOR and not trade_is_ml:
        ckey = clin.status_on(s.sdate)[0] if clin else ""
        if ckey not in FELLOW_JUNIOR:
            return False
    return True


def shift_line(s, extra="", buddy_tag=True):
    bits = [s.label()]
    if s.hol == "HOL":
        bits.append(f"[holiday: {s.hol_name}, block {s.block}]")
    elif s.hol == "PERI":
        bits.append("[pre-scheduled peri-holiday]")
    if s.is_ml:
        bits.append("[ML]")
    if s.ml_pay:
        bits.append("[has ML pay - may not be tradeable]")
    if s.buddy and buddy_tag:
        bits.append("[BUDDY SHIFT - discuss with admins before trading]")
    for n in s.notes:
        if "buddy" not in n.lower() and "ml pay" not in n.lower():
            bits.append(f"(note: {n})")
    if extra:
        bits.append(extra)
    return " ".join(bits)


def print_feedback():
    print("VERSION: %s  BUILD: %s  ROSTER: %s" % (VERSION, BUILD_DATE, ROSTER_DATE))
    for f in FEEDBACK:
        print("FEEDBACK: " + f)


def audit_person(p):
    """Suggest roster changes when someone works shifts above their listed role."""
    if p.role in ("Clinical", "APP"):
        want = "C*" if p.role == "Clinical" else "SrAPP"
        n = sum(1 for s in p.shifts if s.level == want and not s.is_ml)
        if n:
            fb(f"Roster check: {p.name} is listed as {p.role} but has {n} {want} shift(s) in the schedule.")


def fy_flags(dates):
    fys = sorted(set(fy_of(d) for d in dates))
    missing = [f for f in fys if f not in HOL_FYS]
    for f in missing:
        print(f"HOLIDAYS_MISSING: no holiday list loaded for {f}; ask the primary user for it. Holiday "
              f"shifts in {f} are not marked yet.")
    if any(d >= date(2000 + ROSTER_FY, 7, 1) for d in dates):
        print(f"FELLOW_PROMOTIONS: dates reach past 7/1/{2000 + ROSTER_FY}. Fellows are promoted by shift date "
              "(Y1->Y2, Y2->Y3, Y3/Y4->faculty). Confirm this with the primary user once.")


# ---------------------------------------------------------------- unlock
def data_versions():
    """Check the data files against data/manifest.csv; return a one-line summary."""
    mp = os.path.join(DATA, "manifest.csv")
    if not os.path.exists(mp):
        fb("Data manifest (manifest.csv) is missing.")
        return "no manifest"
    out = []
    for r in csv.DictReader(open(mp, encoding="utf-8")):
        path = os.path.join(DATA, r["file"])
        ok = os.path.exists(path) and hashlib.sha256(open(path, "rb").read()).hexdigest()[:16] == r["sha256"]
        if not ok:
            fb(f"Data file {r['file']} doesn't match its manifest (expected version {r['version']}).")
        if r["version"] != VERSION:
            fb(f"Data manifest is stamped {r['version']} but the script is {VERSION}.")
        out.append(f"{r['file']} (changed in {r['changed_in']})")
    return f"version {VERSION}: " + ", ".join(out)


def auto_feedback_line():
    ok = bool(sensitive("feedback_token") and sensitive("feedback_repo"))
    return ("AUTO_FEEDBACK: available. At wrap-up, always offer \"Send it automatically\" first."
            if ok else "AUTO_FEEDBACK: not set up in this version. Offer download or save for later.")


def bundle_id():
    return hashlib.sha256(open(BUNDLE, "rb").read()).hexdigest()[:16]


def require_unlocked():
    """Released copies must be unlocked (once per conversation) before any other command."""
    if not RELEASE:
        return
    if not os.path.exists(BUNDLE):
        print("ERROR: this copy of the skill has no data file (secure.bin is missing). Reinstall the skill.")
        sys.exit(2)
    try:
        ok = open(os.path.join(UNLOCKED, ".bundle"), encoding="utf-8").read().strip() == bundle_id()
    except OSError:
        ok = False
    if not ok:
        print("LOCKED: run `unlock` with the skill passphrase first (see SKILL.md).")
        sys.exit(4)


def cmd_unlock(args):
    pw = args.passphrase or os.environ.get("SHIFTSWAP_PASSPHRASE", "")
    if args.stdin:
        pw = sys.stdin.readline().strip()
    ld_check_folder()
    if not RELEASE:
        print(f"UNLOCKED: development copy {VERSION} (plain data files; no passphrase needed).")
        if LD_ROOT and pw and not ld_unlock(pw):
            sys.exit(5)
        print(f"SENSITIVE: {SENSITIVE}")
        print(f"DATA: {data_versions()}")
        print(auto_feedback_line())
        print_feedback()
        return
    if not pw:
        print("ERROR: no passphrase given.")
        sys.exit(2)
    sys.path.insert(0, HERE)
    import securebundle as sb
    if LD_ROOT and ld_locked_out():
        sys.exit(5)
    if passphrase_locked(args):
        sys.exit(5)
    try:
        files = sb.unpack(open(BUNDLE, "rb").read(), pw)
    except sb.BadPassphrase:
        if LD_ROOT:   # 9.8 with Local Data: tries and the old-passphrase flag live in lockout.json
            _, ldp = _ld_plain()
            rec = ldp.read_lockout()
            args.tries_used, args.old_tried = len(rec.get("passphrase") or []), bool(rec.get("old_tried"))
            if OLD_PASSPHRASES.get(passphrase_fp(sb.normalize(pw))) and not args.old_tried:
                rec["old_tried"] = True   # the first old passphrase is free
                ldp.write_lockout(rec)
            else:
                ld_wrong_try()
        if passphrase_refused(args, pw, sb.normalize(pw)):   # 9.8: an old passphrase, tries left, lockout
            sys.exit(5)
        print("BAD_PASSPHRASE: that passphrase doesn't unlock this version. Ask the user to check it "
              "(capitals, spaces and punctuation don't matter).")
        sys.exit(5)
    except (sb.BadBundle, OSError) as e:
        print(f"ERROR: the skill's data file is damaged ({e}). Reinstall the skill.")
        sys.exit(2)
    shutil.rmtree(UNLOCKED, ignore_errors=True)
    os.makedirs(UNLOCKED, mode=0o700)
    for name, data in files.items():
        path = os.path.join(UNLOCKED, *name.split("/"))
        os.makedirs(os.path.dirname(path), exist_ok=True)
        open(path, "wb").write(data)
    open(os.path.join(UNLOCKED, ".bundle"), "w", encoding="utf-8").write(bundle_id())
    print(f"UNLOCKED: version {VERSION}.")
    if LD_ROOT and not ld_unlock(pw):
        sys.exit(5)
    if getattr(args, "tries_used", 0) and not LD_ROOT:
        print("SAVE: passphrase tries: 0; old passphrase tried: no")   # 9.8: a right passphrase resets the count
    print(f"SENSITIVE: {SENSITIVE}")
    print(f"DATA: {data_versions()}")
    print(auto_feedback_line())
    print_feedback()


# ---------------------------------------------------------------- commands
def cmd_refresh(args):
    shifts, src = load_feed(args.ics, links=args.links)
    people, by_sched = load_roster()
    attach(shifts, people, by_sched)
    if src == "attached file":
        fb("The primary user attached the schedule file (workaround for a blocked or rejected link).")
    print_feedback()


def link_id(last, first):
    part = lambda s: (re.sub(r"[^A-Za-z]", "", s)[:3].upper() + "XXX")[:3]
    return now().strftime("%Y%m%d%H%M") + part(last) + part(first)


def cmd_newlink(args):
    """Try a link the user made; if it gives a valid schedule, give it an ID and use it."""
    stamp = now().strftime("%Y-%m-%d %H:%M")
    try:
        req = urllib.request.Request(args.url, headers={"User-Agent": "cincipem-shiftmate"})
        txt = urllib.request.urlopen(req, timeout=90).read().decode("utf-8", "replace")
    except Exception as e:
        why = net_problem(e)
        print(f"LINK_ATTEMPT: new link {'blocked' if why == 'blocked' else 'rejected (' + why + ')'} {stamp}")
        print("NEW_LINK_FAILED: " + ("the schedule site isn't in allowed domains." if why == "blocked"
                                    else "ShiftAdmin didn't accept this link. Check it was copied whole."))
        print_feedback()
        sys.exit(3)
    if "BEGIN:VCALENDAR" not in txt:
        print(f"LINK_ATTEMPT: new link rejected (not a calendar) {stamp}")
        print("NEW_LINK_FAILED: that link didn't return a calendar. Check it was copied whole.")
        print_feedback()
        sys.exit(3)
    load_holidays()
    shifts = parse_ics(txt)
    lid = link_id(args.last, args.first)
    probs = report_schedule(shifts, txt, f"new link {lid}", quiet=False)
    if probs and args.keep:
        os.makedirs(WORK, exist_ok=True)
        open(os.path.join(WORK, "feed.ics"), "w", encoding="utf-8").write(txt)
        print(f"USING_FOR_THIS_SESSION: {lid} (schedule has problems; results may not be accurate; don't save it).")
    elif probs:
        print(f"NEW_LINK_INVALID: {lid} works but the schedule has problems (above). If the primary user chooses to "
              "continue anyway, run newlink again with --keep (this session only; don't save the link).")
    else:
        os.makedirs(WORK, exist_ok=True)
        open(os.path.join(WORK, "feed.ics"), "w", encoding="utf-8").write(txt)
        print(f"LINK_ATTEMPT: {lid} worked {stamp}")
        print(f"NEW_LINK: {lid}. Save it in Local Data (id and link) and include it in feedback.")
        fb(f"New working ShiftAdmin link {lid} (made {stamp}): {args.url}")
    print_feedback()


SCRUB = [  # (what, pattern, why). Only the matched words are removed; each removal is listed.
    ("possible patient information (medical record number)",
     re.compile(r"\b(mrn|medical record( number| no\.?)?|med ?rec|fin)\b\W{0,3}(is|was|#|:)?\s*\d{5,}", re.I),
     "patient information (PHI) must never be in feedback"),
    ("possible patient information (date of birth)",
     re.compile(r"\b(dob|d\.o\.b\.|date of birth|birth ?date|born( on)?)\b\W{0,3}(is|was|:)?\s*\d{1,2}[/-]\d{1,2}[/-]\d{2,4}", re.I),
     "patient information (PHI) must never be in feedback"),
    ("possible identification number", re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "ID numbers must never be in feedback"),
    # a password: after "is", "was", ":" or "=", or right after the word when it looks like one (has a digit or symbol)
    ("a password", re.compile(r"\b(password|passwd|pwd|pw|passcode|pin)\b(\W{0,3}(is|was)\b\W{0,3}|\s*[:=]\s*)\S+"
                              r"|\b(password|passwd|pwd|pw|passcode|pin)\s+(?=\S*[\d!@#$%^&*])\S+", re.I),
     "usernames and passwords must never be in feedback"),
    # a username: after "is", "was", ":" or "=", or right after "username", "user id" or "creds" (never "credentials",
    # which the Roster updates use for MD, NP and so on)
    ("a username", re.compile(r"\b(user ?name|user ?id|login|log-in|creds?)\b(\W{0,3}(is|was)\b\W{0,3}|\s*[:=]\s*)\S+(\s*/\s*\S+)?"
                              r"|\b(user ?name|user ?id|creds?)\s+(?!(?:or|and|nor|to|for|of|in|on|at|by|with|without|"
                              r"is|was|are|the|a|an|field|fields|box|change|changes|first|here|there)\b)\S+(\s*/\s*\S+)?", re.I),
     "usernames and passwords must never be in feedback"),
    ("an access key or token", re.compile(r"github_[p]at_\w+|\bghp_\w{20,}|\bsk-[A-Za-z0-9]{20,}|\b[A-Za-z0-9+/_-]{40,}={0,2}"),
     "keys and tokens must never be in feedback"),
]
LINK_RX = re.compile(r"https://www\.shiftadmin\.com/\S+")


def scrub_text(text):
    """Remove words that look like PHI, usernames, passwords or keys; list each removal (never the removed words).
    New ShiftAdmin links the user made belong in feedback, so they're set aside while checking."""
    out, removed, section = [], [], "top"
    for n, line in enumerate(text.split("\n"), 1):
        if line.startswith("#"):
            section = line.lstrip("# ").strip()
        if section == "Removed for privacy":
            out.append(line)
            continue
        links = LINK_RX.findall(line)
        marks = re.findall(r"\[removed:[^\]]*\]", line)
        work = re.sub(r"\[removed:[^\]]*\]", "\x01", LINK_RX.sub("\x00", line))   # set aside links and earlier removals
        kinds = []
        for i, (what, rx, why) in enumerate(SCRUB):
            if rx.search(work):
                work = rx.sub(f"\x02{i}\x02", work)
                kinds.append((what, why))
        work = re.sub("\x02(\\d+)\x02", lambda m: f"[removed: {SCRUB[int(m.group(1))][0]}]", work)
        for mk in marks:
            work = work.replace("\x01", mk, 1)
        for lk in links:
            work = work.replace("\x00", lk, 1)
        out.append(work)
        for what, why in kinds:
            removed.append(f"- {what[0].upper() + what[1:]} removed from \"{section}\" (line {n}): {why}.")
    text = "\n".join(out)
    if removed:
        if "## Removed for privacy" not in text:
            text = text.rstrip() + "\n\n## Removed for privacy\n"
        text = text.rstrip() + "\n" + "\n".join(removed) + "\n"
    return text, removed


# Wrap-up 5 (diagram answer 2): a send too big for one GitHub issue goes in numbered parts. GitHub allows 65,536
# characters in an issue body. The body is armored base64 of MAGIC + key block (3072-bit RSA: 384 bytes) + nonce + the
# zlib-compressed text + tag, i.e. about 4/3 x 77/76 of (440 + compressed bytes) + 68 characters of armor. Compression
# can't be counted on (random-looking text barely shrinks), so the most plain ASCII text that always fits is about
# 48,000 characters; 100,000 does not fit. FEEDBACK_PART_CHARS keeps a margin below that; a part that still encrypts
# over GITHUB_BODY_MAX (e.g. many non-ASCII characters) is split again.
GITHUB_BODY_MAX = 65536
FEEDBACK_PART_CHARS = 45000


def split_text(text, limit):
    """Split at line ends (a single line longer than limit is cut) into pieces of at most limit characters."""
    out, cur = [], ""
    for line in text.splitlines(keepends=True):
        while len(line) > limit:
            if cur:
                out.append(cur)
                cur = ""
            out.append(line[:limit])
            line = line[limit:]
        if len(cur) + len(line) > limit:
            out.append(cur)
            cur = ""
        cur += line
    if cur or not out:
        out.append(cur)
    return out


def feedback_parts(text, encrypt, limit=FEEDBACK_PART_CHARS):
    """-> [(plain part, encrypted body)], each body within GITHUB_BODY_MAX; parts after the first say which they are."""
    pieces = split_text(text, limit) if len(text) <= limit else split_text(text, limit - 60)   # room for the part line
    while True:
        n = len(pieces)
        heads = [""] + [f"**Part {i} of {n}** (continued from part {i - 1})\n\n" for i in range(2, n + 1)] if n > 1 else [""]
        if n > 1:
            heads[0] = f"**Part 1 of {n}**\n\n"
        plain = [h + p for h, p in zip(heads, pieces)]
        enc = [encrypt(p) for p in plain]
        big = [i for i, b in enumerate(enc) if len(b) > GITHUB_BODY_MAX]
        if not big:
            return list(zip(plain, enc))
        new = []
        for i, p in enumerate(pieces):
            new += split_text(p, max(1000, len(p) // 2)) if i in big else [p]
        pieces = new


def feedback_has_critical(txt):
    """True when a feedback file really holds a critical item: its "Critical items:" line names IDs, or an item is
    marked **Critical** after its ID. The template's own wording ("Critical items: none", comments) doesn't count."""
    txt = re.sub(r"<!--.*?-->", "", str(txt or ""), flags=re.S)
    m = re.search(r"Critical items:\**\s*(.*)", txt, re.I)
    if m:
        v = m.group(1).strip().strip("*").strip()
        if v and not re.match(r"(none|n/?a|-|–|<.*>)\.?$", v, re.I):
            return True
    return bool(re.search(r"\b[A-Z]{1,3}\d+\b[^\n]{0,20}\*\*Critical\*\*", txt))


def cmd_feedback_due(args):
    """Wrap-up (answer 20, Patrick 9/27): with Auto-send off, remind the user to send (or download and email) when the
    number of runs (chats) whose feedback is unsent is a multiple of 3, or when any unsent item is critical. With
    Auto-send on, feedback is sent at the end of every run and this isn't used. Fix 3 #2: the unit is one chat's
    feedback, counted from the Local Data outbox (a kept file remembers every earlier chat folded into it), plus this
    chat, whose feedback is being wrapped up now; noted items are never counted one by one."""
    if not LD_ROOT:
        print("ERROR: feedback --due reads the Local Data outbox; no Local Data folder is set. " + LD_MISSING)
        sys.exit(3)
    ld = ld_open()
    chats, crit = outbox_chats(ld)
    chats.add(outbox_rel().rsplit("/", 1)[-1])
    n = len(chats)
    if n % 3 == 0 or crit:
        why = ("critical feedback is waiting" if crit else f"{n} is a multiple of 3")
        print(f"FEEDBACK_SEND_DUE: yes ({n} run(s) with unsent feedback, this one included; {why}). Remind them to send "
              "it, or download it and email it (Send, Wrap-up 5)"
              + (", and recommend sending now: critical feedback is waiting." if crit else "."))
    else:
        print(f"FEEDBACK_SEND_DUE: no ({n} run(s) with unsent feedback, this one included; none critical). Don't remind "
              "them this time; run `feedback --keep <file>` so it waits in the outbox (the reminder comes at 3, 6, 9... "
              "runs, or when one has critical feedback). Sending when they ask is always fine.")
    print_feedback()


def outbox_to_sent(why):
    """After a send or a download: every file in the Local Data outbox moves to feedback/sent (kept a year, 6.7), and
    the FEEDBACK: lines and usage rows that `feedback --collect` put in the file leave logs/ (fix 3 #5)."""
    if not LD_ROOT:
        return 0
    ld = ld_open()
    moved = 0
    for rel in ld.list("feedback/outbox"):
        try:
            d = ld.read(rel, "")
            ld.write("feedback/sent/" + rel.split("/", 2)[-1], d)
            ld.delete(rel)
            moved += 1
        except Exception:
            continue
    logs = consume_collected(ld)
    ld.prune_sent()
    print(f"OUTBOX_CLEARED: {moved} unsent feedback file(s) moved to feedback/sent ({why})"
          + (f"; {logs} kept log file(s) (FEEDBACK: lines, usage rows) that went with it cleared" if logs else "") + ".")
    return moved


def send_failed(path):
    """A failed send (C1:222): the file stays in the outbox, and 'failed sends' (in a row) goes up by one."""
    if not LD_ROOT:
        return
    outbox_keep(path, " (the send failed)")
    try:
        n = int(str(ld_state().get("failed_sends") or 0).split()[0]) + 1
    except ValueError:
        n = 1
    print(f"SAVE: failed sends: {n}")


def cmd_feedback(args):
    if args.due:
        return cmd_feedback_due(args)
    if args.keep or args.collect:
        return cmd_feedback_outbox(args)
    if args.clear:   # after a download: the file they downloaded had everything in the outbox
        outbox_to_sent("downloaded")
        if LD_ROOT:
            print("SAVE: feedback warnings: 0")
        print_feedback()
        return
    """Scrub, then encrypt a feedback file for the maintainer and file it in the feedback inbox."""
    sys.path.insert(0, HERE)
    import feedbackcrypt
    path = args.submit or args.prepare
    raw = re.sub(r"(?m)^\*\*Version:\*\* [^\n]*\(template\)[ \t]*\n\n?", "", open(path, encoding="utf-8").read())
    text, removed = scrub_text(raw)
    open(path, "w", encoding="utf-8").write(text)
    if removed:
        print(f"SCRUBBED: {len(removed)} item(s) removed for privacy (only the matching words; the rest of each line is "
              "kept) and listed under \"Removed for privacy\". Tell the user in one line what kind of thing was removed "
              "and why (never repeat it).")
    else:
        print("SCRUB_OK: nothing that looks like patient information, a username, a password or a key.")
    if args.prepare:
        print_feedback()
        return
    title = f"Feedback {now():%Y-%m-%d} {hashlib.sha256(text.encode()).hexdigest()[:8]}"
    parts = feedback_parts(text, feedbackcrypt.encrypt)
    titles = [title] if len(parts) == 1 else [f"{title} (part {i} of {len(parts)})" for i in range(1, len(parts) + 1)]
    token, repo = sensitive("feedback_token"), sensitive("feedback_repo")
    if args.dry_run:
        print(f"DRY_RUN: would file '{title}' in the feedback inbox ({len(text)} characters, encrypted"
              + (f"; too big for one inbox item, so in {len(parts)} numbered parts: "
                 + ", ".join(f"part {i} {len(p)} characters, {len(b)} encrypted" for i, (p, b) in enumerate(parts, 1))
                 if len(parts) > 1 else "") + ").")
        print_feedback()
        return
    if not token or not repo:
        print("FEEDBACK_UNAVAILABLE: automatic sending isn't set up in this version. Offer download and email.")
        outbox_keep(path, " (not sent)")
        sys.exit(7)
    try:
        nums = []
        for t, (_, body) in zip(titles, parts):
            data = json.dumps({"title": t, "body": body}).encode()
            req = urllib.request.Request(f"https://api.github.com/repos/{repo}/issues", data=data, method="POST", headers={
                "Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "cincipem-shiftmate"})
            nums.append(json.loads(urllib.request.urlopen(req, timeout=20).read()).get("number"))
        print(f"FEEDBACK_SENT: '{title}' (inbox item {nums[0]})." if len(nums) == 1 else
              f"FEEDBACK_SENT: '{title}' in {len(nums)} numbered parts (inbox items {', '.join(map(str, nums))}).")
        outbox_to_sent("sent")   # the sent file had everything in the outbox (Collect, Wrap-up 4)
        if LD_ROOT:
            print("SAVE: failed sends: 0; feedback warnings: 0")
    except Exception as e:
        send_failed(path)
        if len(parts) > 1 and nums:
            print(f"FEEDBACK_PARTIAL: {len(nums)} of {len(parts)} parts were sent (inbox items "
                  f"{', '.join(map(str, nums))}); the rest failed. Keep the whole file in the outbox; sending it again "
                  "later sends every part again).")
            sys.exit(7)
        why = net_problem(e)
        if why in ("http 401", "http 403", "http 404"):
            print(f"TOKEN_REFUSED: the feedback inbox refused this version's key ({why}). Note it in Local Data (logs/health), offer "
                  "the latest stable version, then offer download and email.")
        elif why == "blocked":
            print("FEEDBACK_FAILED: BLOCKED. api.github.com isn't in allowed domains. Offer download and email, "
                  "and the allow-domain steps.")
        else:
            print(f"FEEDBACK_FAILED: {why}. Offer download and email, or saving it for later.")
        sys.exit(7)
    print_feedback()


STAFF_LEVEL = {"Faculty": "F", "Senior Clinical": "CL*", "Clinical": "CL", "Senior APP": "APP*", "APP": "APP",
               "Fellow": "Fellow", "Moonlighter": "ML"}


def cmd_whoami(args):
    if args.setup:
        people, _ = load_roster()
        cmd_whoami_setup(args, people, load_admins())
        return
    shifts, src = load_feed(getattr(args, "ics", None), quiet=True)
    people, by_sched = load_roster()
    attach(shifts, people, by_sched)
    hits = find_person(people, args.name)
    if len(hits) == 1 and not whole_word_match(hits[0], args.name):   # C3#6: never a silent partial match
        print(f"DID_YOU_MEAN: {hits[0].name} ({role_label(hits[0])})? '{args.name}' isn't an exact match. Ask (Yes / No); "
              "after a yes, run whoami again with that exact name.")
        print_feedback()
        return
    if not hits:
        close = [p for p in people if name_close(p, args.name)]
        if close:
            print("DID_YOU_MEAN: " + "; ".join(f"{p.name} ({role_label(p)})" for p in close[:3]) + f"? '{args.name}' isn't "
                  "on the roster. Ask with one button per name plus 'None of these'; after a yes, run whoami again with "
                  "that exact name.")
            print_feedback()
            return
        print(f"NO_MATCH: '{args.name}' is not on the roster.")
    if len(hits) == 1 and LD_ROOT and not demo_active():
        admin_first_time(hits[0])
    for p in hits[:6]:
        key, sites, jeop, fy = p.status_on(now().date())
        fut = [s for s in p.shifts if s.start > now()]
        lvl = STAFF_LEVEL.get(p.role, p.role) + (" " + p.fellow_year if p.fellow_year else "")
        print(f"{p.name}{', ' + p.credentials if p.credentials else ''} | role {role_label(p)}"
              f" | permissions {key if p.role == 'Fellow' else p.role}"   # fix 3 #6: the fellow year role shows
              f"{' with exceptions (' + p.permission_exceptions + ')' if p.exceptions else ''}"
              f"{'' if p.role == 'Fellow' else f' (level {lvl})'}"
              f" | schedule name '{p.schedule_name}'"
              f" | sites {', '.join(sorted(sites)) or '-'} | jeopardy pools {', '.join('Jeop ' + j for j in sorted(jeop)) or 'none'}"
              f" | {len(fut)} upcoming shifts | email {p.email or 'none'} | cell {p.cell or 'none'}"
              f" | prefers {p.contact_pref or 'not stated'} | goes by {getattr(p, 'preferred_name', '') or '-'}"
              f"{' | NOT A TRADE PARTNER (moonlighter)' if p.role == 'Moonlighter' else ''}")
        eligible_sites = [x for x in site_order(None, p) if FACILITY_LOC(x) in sites]
        print("  Eligible sites: " + ", ".join(eligible_sites))
        lv = LEVELS.get(key, {})
        if lv:
            print("  Shift levels allowed: " + "; ".join(f"{loc} {', '.join(level_label(x) for x in sorted(lv[loc]))}"
                                                          for loc in ("ED", "HBUC", "NUC", "VUC") if loc in lv and loc in sites))
        if key in FELLOW_JUNIOR:
            print("  Trades: regular shifts only with other Y1/Y2 fellows; ML shifts with anyone eligible.")
        else:   # 9.7 B4: always say who they can trade with and about moonlighting (roles.csv trade_partner)
            print("  Trades: " + ("with any colleague in the trade pool who's eligible for the shift (not moonlighters)."
                                  if p.trade_partner == "Y" else "not in the trade pool (no shift trades)."))
        if p.role != "Moonlighter":
            print("  Moonlighting (ML): ML shifts at the sites and levels above; an ML shift trades only for another ML shift, or can be given away.")
        if key in FELLOW_SENIOR:
            print("  From July 1 of the next academic year: presumed faculty (see FELLOW_PROMOTIONS).")
        if len(hits) == 1:
            audit_person(p)
    print_feedback()


def whole_word_match(p, name):
    """Every word typed is a whole word of the person's name, schedule name or an alias (or a nickname of the first
    name, or an initial), so 'Example' or 'Al Example' match 'Alex Example'; 'Exampl' does not (C3#6)."""
    forms = [p.name, p.schedule_name] + [a for a in (p.aliases or "").split(";") if a.strip()]
    if nkey(name) in [nkey(f) for f in forms]:
        return True
    words = {nkey(w) for f in forms for w in re.split(r"[\s,.]+", f) if nkey(w)}
    for t in split_name(name):
        k = nkey(t)
        if not k or k in words or (len(k) == 1 and any(w.startswith(k) for w in words)):
            continue
        if any(nkey(f) in words for f in NICKNAMES.get(k, [])) or any(k in NICKNAMES.get(w, []) for w in words):
            continue
        return False
    return True


def name_close(p, name):
    """A near miss (first and last name both close), as the setup name check judges it."""
    toks = split_name(name)
    if len(toks) < 2:
        return False
    for f in [p.name] + [a for a in (p.aliases or "").split(";") if a.strip()]:
        ft = split_name(f)
        if len(ft) >= 2 and (similar(toks[0], ft[0]) or nkey(ft[0]) in NICKNAMES.get(nkey(toks[0]), [])
                             or nkey(toks[0]) in NICKNAMES.get(nkey(ft[0]), [])) and similar(toks[-1], ft[-1]):
            return True
    return False


def admin_first_time(p):
    """C3#5 (administrator/main.md, Which clinician): in administrator mode, say whether this is the first time the
    administrator runs the skill for this clinician (no saved settings of theirs yet)."""
    try:
        ld = ld_open(need_key=False)
        if ld is None or not ld.has_key():
            return
        st = ld_state()
    except SystemExit:
        return
    prof = st.get("profile") if isinstance(st.get("profile"), dict) else {}
    me = str(prof.get("roster_name") or prof.get("name") or "")
    admin = str(st.get("last_role") or "").lower() == "administrator" or any(
        nkey(a.name) == nkey(me) and not getattr(a, "staff_row", "") for a in load_admins())
    if not admin or nkey(me) == nkey(p.name):
        return
    d = ld_clinician_dir(p.name)
    if any(ld.exists(d + "/" + r) for r in ("preferences/sites", "preferences/shift-times", "blocked-dates/my-blocks",
                                             "preferences/trade-shifts", "preferences/swap-locations")):
        print(f"ADMIN_CLINICIAN_KNOWN: {p.name} has saved settings from an earlier run; use them.")
    else:
        print(f"ADMIN_FIRST_TIME (read workflows/administrator/main.md): the first time you're running it for {p.name}: "
              "confirm their role, then set up their preferences (Setup 6 to 8) before the search.")


def compress_dates(ds):
    out, run = [], []
    for d in sorted(ds):
        if run and (d - run[-1]).days == 1:
            run.append(d)
        else:
            if run:
                out.append(run)
            run = [d]
    if run:
        out.append(run)
    return ", ".join(f"{r[0]:%m/%d}" if len(r) == 1 else f"{r[0]:%m/%d}-{r[-1]:%m/%d}" for r in out)


def FACILITY_LOC(site):
    return {"B ED": "ED", "Lib ED": "ED", "BUC": "HBUC", "LT UC": "HBUC", "VUC": "VUC"}.get(site, "NUC")


def cmd_shifts(args):
    shifts, people, clin, req, src = setup(args)
    n = now()
    days = parse_dates(req.get("dates"), n.date(), max(s.sdate for s in shifts))
    mine = [s for s in clin.shifts if s.sdate in days and s.start > n]
    print(f"{clin.name}: {len(mine)} upcoming shift(s) on the requested dates.")
    for s in mine:
        print(f"  #{s.id} " + shift_line(s))
    singles = set(date.fromisoformat(x) for x in (req.get("dates") or []) if isinstance(x, str) and x != "all")
    missing = sorted(d for d in singles if not any(s.sdate == d for s in mine))
    for d in missing[:10]:
        near = sorted([s for s in clin.shifts if s.start > n], key=lambda s: abs((s.sdate - d).days))[:3]
        print(f"  NOT WORKING {d:%m/%d %a}. Nearest: " + "; ".join(f"#{s.id} {s.label()}" for s in near))
    audit_person(clin)
    print_feedback()


def trade_into_dates(req, shifts):
    n = now()
    last = max(s.sdate for s in shifts)
    days = parse_dates(req.get("into"), n.date(), last)
    return {d for d in days if d >= n.date()}


def cmd_avail(args):
    """Days the clinician is available AND has real shifts they could trade into, by time category.
    Only shifts they're eligible for (sites, level, Jeopardy excluded) count. Not a picture of free time."""
    shifts, people, clin, req, src = setup(args)
    days = trade_into_dates(req, shifts)
    give = set(str(x) for x in req.get("give_ids", []))
    if not give:   # 9.6 (003): ask for a shift (and dates) rather than print every date's availability
        print(f"ASK_SHIFT: no shift named. Ask which shift {WHO} want{Y('', 's')} to trade away (run 'shifts' to list them)"
              + ("" if req.get("into") else ", and the dates to trade into ([All available dates] as the default button)")
              + ", then re-run avail with give_ids. Show no availability until then.")
        print_feedback()
        return
    n = now()
    fy_flags(days)
    removed = []
    okdays = []
    gl = [s for s in clin.shifts if s.id in give]
    gdays = {s.sdate for s in gl}   # 9.6 (C5): labelled "the day of the shift you're giving away"
    glabel = lambda d: f" (the day of the shift {YOURE()} giving away)" if d in gdays else ""
    # the kind of shift they could trade into follows the kind they're giving up (ML for ML, Jeopardy for Jeopardy)
    kind = "ml" if gl and all(s.is_ml for s in gl) else (
        "jeop" if gl and all(s.is_jeop for s in gl) and req.get("jeop_mode") != "any" else "regular")
    want = {"ml": lambda s: s.is_ml, "jeop": lambda s: s.is_jeop,
            "regular": lambda s: not s.is_ml and not s.is_jeop}[kind]
    if kind != "regular":
        print(f"KIND: counting only {'ML' if kind == 'ml' else 'Jeopardy'} shifts, since that's what the shift being "
              "traded can go for.")
    mine = {s.id for s in clin.shifts}
    only_sites = set(filter(None, (norm_site(x) for x in (req.get("sites") or ALL_SITES))))   # their chosen sites, if known
    struct = {}   # (weekday, time of day) -> [dates with no eligible shift of that kind]; see PATTERN
    seen_wd = {}
    per_day = []
    rest_lims = []   # times of day that fit only partly because of the 8 h rest rule (9.4)
    for d in sorted(days):
        todays = [s for s in shifts if s.sdate == d and s.start > n and want(s) and s.id not in mine]
        cats_ok, notes = [], []
        seen_wd[d.weekday()] = seen_wd.get(d.weekday(), 0) + 1
        for tc in ("day", "evening", "overnight"):
            cands = [s for s in todays if s.tc == tc and eligible(clin, s, clin, kind == "ml")
                     and (s.is_jeop or s.site in only_sites)]
            if not cands:
                struct.setdefault((d.weekday(), tc), []).append(d)
                notes.append((tc, f"{tc}: no {tc}{ {'ml': ' ML', 'jeop': ' Jeopardy'}.get(kind, '')} shifts {YOURE()} eligible for that day"))
                continue
            blk = [blocked(c, req.get("blocks"), all_vacations(req)) for c in cands]
            reason = (blk[0] if all(blk) else None) or \
                ("vacation (ShiftAdmin)" if all(on_vacation(clin, c) for c in cands) else None)
            if not reason:
                reasons = []
                for c in cands:
                    ok, r, w = check(clin.shifts, c, remove_ids=give, b2b=b2b_on(req))
                    if ok:
                        break
                    reasons.append(r)
                else:
                    soft = [r for r in reasons if not r.startswith("overlaps")]
                    reason = f"no shift fits around {YOUR()} schedule (" + (soft[0] if soft else reasons[0]) + ")"
            if reason:
                notes.append((None, f"{tc}: {reason}"))
            else:
                cats_ok.append(tc)
                lim = rest_limit(clin.shifts, cands, give, b2b_on(req))   # 9.4: say when the rest rule leaves only part of it
                if lim:
                    rest_lims.append(f"{d:%m/%d} {tc}: {lim}")
        per_day.append((d, notes))
        if cats_ok:
            okdays.append((d, cats_ok))
    # structural gaps (a weekday and time of day with no eligible shift on every such date) go on one PATTERN line
    always = {k for k, ds in struct.items() if len(ds) == seen_wd[k[0]] and seen_wd[k[0]] >= 2}
    WDN = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    pat = []
    for tc in ("day", "evening", "overnight"):
        wds = [w for w in range(7) if (w, tc) in always]
        if wds and len(wds) == len(seen_wd):
            pat.append(f"never {'a' if tc == 'day' else 'an'} {tc} shift")
        elif wds:
            pat.append(f"no {tc} shift on " + ", ".join(WDN[w] for w in wds))
    for d, notes in per_day:
        notes = [txt for tc, txt in notes if tc is None or (d.weekday(), tc) not in always]
        if notes:
            removed.append(f"{d:%m/%d %a}{glabel(d)}: " + "; ".join(notes))
    print(f"Availability for {clin.name}, {min(days):%m/%d}-{max(days):%m/%d} ({len(days)} days). This shows days {YOURE()} "
          f"available AND there are shifts {WHO} could trade into (only shifts {YOURE()} eligible for count).")
    vr = sorted(d for d in clin.vac if d in days)
    if vr:
        print("VACATION_IN_RANGE (ShiftAdmin): " + compress_dates(vr) + "  <- ask whether they're available to work "
              "any of these; if so, re-run with \"work_on_vacation\": [dates] (\"<date> day\", \"<date> evening\", \"<date> "
              "overnight\" or \"<date> HH:MM-HH:MM\" frees only that shift time; a plain date or \"<date> all\" frees the day)")
    runs, cur = [], []
    for d, c in okdays:
        full = len(c) == 3 and d not in gdays   # the give-away day stands alone, with its label
        if full and cur and (d - cur[-1]).days == 1:
            cur.append(d)
        else:
            if cur:
                runs.append(cur)
            cur = [d] if full else []
            if not full:
                runs.append([(d, c)])
    if cur:
        runs.append(cur)
    parts = []
    for r in runs:
        if isinstance(r[0], tuple):
            bits = ([f"{'/'.join(r[0][1])} only"] if len(r[0][1]) < 3 else []) + [glabel(r[0][0])[2:-1]] * (r[0][0] in gdays)
            parts.append(f"{r[0][0]:%m/%d}" + (f" ({'; '.join(bits)})" if bits else ""))
        elif len(r) == 1:
            parts.append(f"{r[0]:%m/%d}")
        else:
            parts.append(f"{r[0]:%m/%d}-{r[-1]:%m/%d}")
    print("AVAILABLE_TO_TRADE_INTO: " + (", ".join(parts) if parts else "none"))
    if rest_lims:
        print("REST_LIMITS (the 8 h rest rule leaves only part of these; give the time with the date, never offer the "
              "date as open all day): " + "; ".join(rest_lims))
    if pat:
        print(f"PATTERN (how {YOUR()} sites are staffed, not {Y('your', 'their')} schedule; say it once): " + "; ".join(pat) + ".")
    not_available(removed, per_day, always, req)
    print_feedback()


NOT_AVAILABLE_MAX = 10   # 9.6 (U7): more dates left out than this: counts by reason instead of every date


def not_available(removed, per_day, always, req):
    """NOT_AVAILABLE: every date left out, with the reason for each time of day; a long list (U7) becomes counts by
    reason (how many dates each reason leaves out), unless the request says "not_available": "list"."""
    if len(removed) <= NOT_AVAILABLE_MAX or req.get("not_available") == "list":
        print(f"NOT_AVAILABLE ({len(removed)} dates, with the reason for each time of day left out):")
        for r in removed[:60]:
            print("  " + r)
        if len(removed) > 60:
            print(f"  ...and {len(removed) - 60} more")
        return
    from collections import Counter
    c = Counter()
    for d, notes in per_day:
        kinds = set()
        for tc, txt in notes:
            if tc is not None and (d.weekday(), tc) in always:
                continue
            why = txt.split(": ", 1)[1]
            kinds.add(why.split(" (", 1)[0] if why.startswith("no shift fits") else why)
        c.update(kinds)
    print(f"NOT_AVAILABLE ({len(removed)} dates; how many dates each reason leaves out, for at least one time of day): "
          + "; ".join(f"{k}: {v}" for k, v in c.most_common())
          + ". Give these as counts; for one date's reasons, re-run with \"not_available\": \"list\".")


def NO_DATES():
    return Y("colleagues with no shift in your dates", "colleagues with no shift in {n}'s dates")


B2B_ON = ("true", "yes", "on", "if i ask", "let others ask")   # Back-to-back shifts (Setup 7): both Yes answers


def b2b_on(req):
    """4.1 / fix answer 12: back-to-back shifts in the clinician's OWN searches -> True (allowed, up to 12 h 15 min in a
    row) or None (off: check() names them as back-to-back). On with "back_to_back": true (asked for in this search, or
    the ladder's last step) or with either Yes answer to Back-to-back shifts (Setup 7), saved as "if I ask" or
    "let others ask" (Local Data fills it in). "no", false or nothing: off."""
    v = req.get("back_to_back")
    return True if v is True or str(v).strip().lower() in B2B_ON else None


B2B_OTHERS = None   # names on data/backtoback_prefs.csv with allow_others_ask yes (the "let others ask" answer)


def b2b_colleague(P):
    """fix answer 12: may a trade give colleague P a back-to-back? Only with their "let others ask" answer
    (data/backtoback_prefs.csv, allow_others_ask yes). "if I ask", "no" or no row: never -> False (check() then treats
    an hour or less between shifts as under 8 h rest)."""
    global B2B_OTHERS
    if B2B_OTHERS is None:
        try:
            rows = read_csv("backtoback_prefs.csv")
        except (OSError, SystemExit):
            rows = []
        B2B_OTHERS = {nkey(r.get("name") or "") for r in rows
                      if str(r.get("allow_others_ask") or "").strip().lower() in ("yes", "y", "true", "1")}
    return True if nkey(P.name) in B2B_OTHERS else False


EVERYTHING = {"sites": list(ALL_SITES), "times": list(CAT_LABEL), "categories": list("ABCDEF"), "len_up": 4.5,
              "len_colleague": 4.5}   # 4.1 "show me everything": every setting the request leaves out, at its widest


def prefs(req, clin):
    if req.get("everything"):   # 4.1: fields the request gives (their usual, which wins) are kept
        wide = {k: v for k, v in EVERYTHING.items() if not (k == "times" and req.get("types"))}   # "types": older name
        req = dict(wide, **{k: v for k, v in req.items() if v not in (None, "", [])})
    order = expand_hol(req.get("time_order") or req.get("pref_order")) or clin.order
    types = set(expand_hol(req.get("times") or req.get("types")) or [c for c in CAT_LABEL if c not in HOL_TIMES])
    sites = set(filter(None, (norm_site(x) for x in (req.get("sites") or ALL_SITES))))
    cats = set(req.get("categories") or ["A", "B", "C", "D"])
    return order, types, sites, cats, float(req.get("len_up", 0)), float(req.get("len_colleague", 0))


TIER = {("P", "P"): 1, ("N", "N"): 2, ("N", "P"): 3, ("X", "P"): 4, ("P", "N"): 5, ("X", "N"): 6,
        ("P", "X"): 7, ("N", "X"): 8, ("X", "X"): 9}
TIER_CAT = {1: "A", 2: "B", 3: "C", 4: "C", 5: "D", 6: "D", 7: "E", 8: "E", 9: "F"}
CAT_NAME = {"A": "Win-win", "B": "Even (1:1)", "C": "Colleague gains", "D": "Colleague even",
            "E": "Colleague loses", "F": "Lose-lose"}


def outcome(r_new, r_old):
    return "P" if r_new < r_old else ("N" if r_new == r_old else "X")


def fits_clinician_prefs(t, clin_types, sites, s_give, req):
    if t.loc != "JEOP" and t.site not in sites:
        return False
    tt = t.types()
    mode = req.get("holiday_mode")
    if s_give.hol and mode:
        want = {"hol": set(HOL_TIMES), "peri": {"PERI"}, "both": set(HOL_TIMES) | {"PERI"}}.get(mode)
        if want is not None and not (tt & want):
            return False
        clin_types = clin_types | (clin_types & set(HOL_TIMES) or set(HOL_TIMES)) | {"PERI"}   # holiday times they chose, else all (3.1)
    if t.loc == "JEOP":
        return not ((t.hol == "HOL" and HOL_OF_TC[t.tc] not in clin_types) or (t.hol == "PERI" and "PERI" not in clin_types))
    return tt <= clin_types


def find_trades(shifts, people, clin, req, give_list, same_day=False, accept_sites=None, stats=None):
    """stats (optional): {shift id: Counter} filled with why candidates were ruled out (by the first rule each failed;
    why_people lists every rule for the colleagues named in req["why"], 9.5)."""
    from collections import Counter
    n = now()
    order, types, sites, cats, len_up, len_col = prefs(req, clin)
    if accept_sites:
        sites = accept_sites
    days = trade_into_dates(req, shifts)
    give_ids = set(s.id for s in give_list)
    results = {}
    for S in give_list:
        rows = []
        st = Counter()
        if stats is not None:
            stats[S.id] = st
        ctx = dict(clin=clin, n=n, days=days, same_day=same_day, jeop_any=req.get("jeop_mode") == "any", types=types,
                   sites=sites, req=req, len_up=len_up, len_col=len_col, give_ids=give_ids, order=order, cats=cats)
        for P in people:
            def bump(k):
                st[k] += 1
            if P is not clin and P.role != "Moonlighter" and P.trade_partner == "Y":
                _trades_for(P, S, rows, bump, **ctx)
        so = site_order(req, clin)
        rows.sort(key=lambda r: (r[3] != [], r[1].buddy, r[0], r[1].start, so.index(r[1].site) if r[1].site in so else 99,
                                 r[1].code))
        results[S.id] = rows
    return results


def _trades_for(P, S, rows, bump, clin, n, days, same_day, jeop_any, types, sites, req, len_up, len_col, give_ids,
                order, cats):
    """Append the trades colleague P could make for shift S to rows; count every one ruled out with bump()."""
    if not eligible(P, S, clin, S.is_ml):
        bump(Y("colleagues not eligible for your shift", "colleagues not eligible for {n}'s shift"))
        return
    off = colleague_off(P, S)
    if off:
        bump(off)
        return
    in_dates = [T for T in P.shifts if T.start > n and T.sdate in days]
    if not in_dates:
        bump(NO_DATES())
        return
    bump("colleagues considered")
    for T in in_dates:
        if same_day and T.sdate != S.sdate:
            continue
        # which kinds may be exchanged
        if S.is_jeop:
            if T.is_ml or (not T.is_jeop and not jeop_any):
                bump("shift kind (ML trades only for ML, Jeopardy only for Jeopardy)")
                continue
        elif S.is_ml:
            if not T.is_ml:
                bump("shift kind (ML trades only for ML, Jeopardy only for Jeopardy)")
                continue
        else:
            if T.is_ml or T.is_jeop:
                bump("shift kind (ML trades only for ML, Jeopardy only for Jeopardy)")
                continue
        if same_day and (T.is_ml or T.is_jeop):
            continue
        if not eligible(clin, T, clin, S.is_ml):
            bump(Y("you're not eligible for their shift", "{n} is not eligible for their shift"))
            continue
        if not fits_clinician_prefs(T, types, sites, S, req):
            bump(Y("your sites or shift times", "{n}'s sites or shift times"))
            continue
        if blocked(T, req.get("blocks"), all_vacations(req)) or on_vacation(clin, T):
            bump(Y("your blocked dates or vacation", "{n}'s blocked dates or vacation"))
            continue
        if not (S.is_jeop or T.is_jeop):   # length limits don't apply to Jeopardy trades
            if T.hours - S.hours > len_up + 1e-6 or S.hours - T.hours > len_col + 1e-6:
                bump("shift length")
                continue
        okc, rc, wc = check(clin.shifts, T, remove_ids=give_ids, b2b=b2b_on(req))
        if not okc:
            bump(Y("your rest time or days in a row", "{n}'s rest time or days in a row"))
            continue
        okp, rp, wp = check(P.shifts, S, remove_ids={T.id}, b2b=b2b_colleague(P))
        if not okp:
            bump("their rest time or days in a row")
            continue
        cu = outcome(T.rank(order), S.rank(order))
        co = outcome(S.rank(P.order), T.rank(P.order))
        tier = TIER[(cu, co)]
        if TIER_CAT[tier] not in cats:
            bump("trade categories")
            continue
        rows.append((tier, T, P, wc))


MAX_BUTTONS = 4   # 9.2: the app shows at most 4 answer buttons


def choices_hint(n, multi=False):
    """9.2: a question line with more than 4 choices, or several to pick, adds the numbered-list fallback."""
    if n <= MAX_BUTTONS and not multi:
        return ""
    return (f" CHOICES: {'several can be picked' if multi else f'{n} choices'}, more than the {MAX_BUTTONS} buttons "
            "the app allows: show them as a numbered list in the chat and let them type the number(s) (9.2).")


LIST_MAX = 12   # more options than this: show the table only and offer "Display all"
FEW = 10        # fewer options than this: explain why and test loosened settings


def row_type(T):
    return HOL_OF_TC[T.tc] if T.hol == "HOL" else T.cat


def print_table(rows, clin, order, sorder, cols=None, types=None, narrowed=False):
    """Options by shift time (rows, in the clinician's shift-time order) and site (columns, in their location order).
    cols: the columns to show (default: every site they're eligible for); types: the shift times they checked
    (a row they didn't check shows '–' rather than 0)."""
    _, sites, _, _ = clin.status_on(now().date())
    cols = list(cols) if cols else [x for x in sorder if FACILITY_LOC(x) in sites]
    if any(r[1].is_jeop for r in rows) and "Jeopardy" not in cols:
        cols.append("Jeopardy")
    for c in {r[1].site for r in rows if not r[1].is_jeop} - set(cols):   # never hide an option shown in the list
        cols.append(c)
    kinds = [c for c in order if c in CAT_LABEL] + [c for c in DEFAULT_ORDER if c not in order]
    print("TABLE (paste as is):")
    print("| | " + " | ".join(cols) + " |")
    print("|---|" + "---|" * len(cols))
    for k in kinds:
        cells = []
        unchecked = types is not None and k not in types and not any(row_type(r[1]) == k for r in rows)
        for c in cols:
            rs = [r for r in rows if row_type(r[1]) == k and r[1].site == c]
            if not rs:
                cells.append("–" if unchecked else "0")
                continue
            g = lambda s: sum(1 for r in rs if TIER_CAT[r[0]] in s)
            cells.append(f"{len(rs)} ({g('AB')}, {g('CD')}, {g('EF')})")
        print(f"| {CAT_LABEL[k][0].upper() + CAT_LABEL[k][1:]} | " + " | ".join(cells) + " |")
    print("*Each box: total (A+B good for both or even, C+D colleague gains or breaks even, E+F colleague loses)."
          + (f" – means a shift time {WHO} didn't choose" + (" or narrowed out" if narrowed else "") + "."
             if types is not None else "") + "*")


def print_results(S, rows, clin, show, order, sorder, cols=None, types=None, tag_same_day=False, wide=False,
                  narrowed=False):
    print(f"\n=== Trading out of #{S.id} " + shift_line(S))
    if S.buddy:
        print("NOTE: this is a buddy shift - trading it needs special permission from the admins.")
    if not rows:
        print("NO OPTIONS found with the current settings.")
        fb(f"Search found no options for {S.label()} (clinician role {clin.role}"
           f"{' ' + clin.fellow_year if clin.fellow_year else ''}).")
        return
    print(f"{len(rows)} option(s), {len(set(r[2].name for r in rows))} colleague(s).")
    print_table(rows, clin, order, sorder, cols, types, narrowed)
    same = [r for r in rows if r[1].sdate == S.sdate] if tag_same_day else []
    if same:
        print(f"SAME_DAY: {len(same)} of these are on {S.sdate:%m/%d}, the day of the shift {YOURE()} giving away (a switch of site or time, "
              "not a day off); they're tagged (same day). Mention it in the summary.")
    if len(rows) > LIST_MAX and show != "list":
        if wide and not narrowed:   # C2:142: after Show me everything, ask only how to narrow (4 buttons)
            print(f"OVER_{LIST_MAX}: show the table, then ask how to narrow it: [By site] [By shift time] [By category] "
                  "[Something else (type it below)] (add a \"filter\"). Display all only if they ask for it (re-run "
                  "with \"show\":\"list\").")
        else:   # C1:226: 3 buttons; narrowing is one button, how is typed
            print(f"OVER_{LIST_MAX}: show the table, then offer [Display all] (default; re-run with \"show\":\"list\") "
                  "[Narrow it (by site, shift time or category)] [Something else (type it below)]. Narrow it: ask how "
                  "in one question, then add a \"filter\".")
        return
    groups = [("", [r for r in rows if not r[3] and not r[1].buddy]),
              (f"BACK-TO-BACK for {WHO} (listed separately, check before offering):", [r for r in rows if r[3]]),
              ("BUDDY SHIFTS (need admin permission):", [r for r in rows if r[1].buddy and not r[3]])]
    for title, g in groups:
        if not g:
            continue
        if title:
            print(title)
        cur = None
        for tier, T, P, w in g:
            c = TIER_CAT[tier]
            if (c, tier) != cur:
                print(f"-- {c} {CAT_NAME[c]} / tier {tier}")
                cur = (c, tier)
            ln = "" if abs(T.hours - S.hours) < 0.01 else f"({'+' if T.hours > S.hours else ''}{T.hours - S.hours:g} h for {WHO})"
            sd = "(same day)" if tag_same_day and T.sdate == S.sdate else ""
            extra = " ".join(x for x in (f"({P.schedule_name.rstrip('.')}.)", ln, sd, " ".join(w)) if x)
            print(f"  #{T.id} " + shift_line(T, extra, buddy_tag=not title.startswith("BUDDY")).rstrip())


TIER_ORDER = ["Faculty", "Senior Clinical", "Clinical", "Senior APP", "APP", "NP", "Fellow"]


def usage_line(flow, S, rows, req):
    """One compact line for usage data (no colleague names): settings, result count and how results spread.
    Always printed (8.3): Auto-send decides whether it is sent."""
    from collections import Counter
    cats = Counter(TIER_CAT[r[0]] for r in rows)
    grp = lambda s: sum(cats[c] for c in s)
    sites = Counter(r[1].site for r in rows)
    times = Counter(r[1].tc for r in rows)
    hol = Counter(row_type(r[1]) for r in rows if r[1].hol == "HOL")   # the three holiday shift times (3.1)
    keys = ("sites", "times", "types", "categories", "len_up", "len_colleague", "into", "filter", "jeop_mode",
            "holiday_mode", "ml_mode", "leave_sites", "accept_sites", "dates", "site_order", "time_order", "everything",
            "back_to_back")
    settings = "; ".join(f"{k}={json.dumps(req[k], separators=(',', ':'))}" for k in keys if req.get(k) not in (None, "", []))
    print(f"USAGE: {flow} {S.code} ({S.site}, {S.tc}) {len(rows)} result(s) [A+B {grp('AB')}, C+D {grp('CD')}, E+F {grp('EF')}]"
          f" sites {dict(sites)} times {dict(times)}{f' holiday {dict(hol)}' if hol else ''} | settings: {settings or 'defaults'}")


def loosen_steps(req, clin):
    """Settings to try, in the D4 order: first the steps that only cost the user (shift times in preference order,
    categories that don't cost the colleague, longer shifts for the user), then changes that give colleagues less
    preferred shifts (categories E and F, longer shifts for a colleague), and back-to-back shifts always last (4.2).
    Each step is (label, fn); fn(current settings) gives the change, or None when it no longer applies.
    Holiday day, evening and overnight are three shift times, so the ladder adds one holiday time at a time (3.1)."""
    order = prefs(req, clin)[0]
    steps = []
    for k in [k for k in order if k in CAT_LABEL]:
        steps.append((f"add {CAT_LABEL[k]} shifts",
                      lambda cur, k=k: None if k in prefs(cur, clin)[1] else {"times": sorted(prefs(cur, clin)[1] | {k})}))
    cat_step = lambda c: (f"add category {c} ({CAT_NAME[c]})", lambda cur, c=c: None if c in prefs(cur, clin)[3]
                          else {"categories": sorted(prefs(cur, clin)[3] | {c})})
    len_step = lambda key, v, who: (f"allow {who} a shift up to {v:g} h longer",
                                    lambda cur: None if float(prefs(cur, clin)[4 if key == "len_up" else 5]) >= v
                                    else {key: v})
    steps += [cat_step(c) for c in "ABCD"]                                            # only cost the user
    steps += [len_step("len_up", 2.5, Y("you to take", "{n} to take")), len_step("len_up", 4.5, Y("you to take", "{n} to take"))]
    steps += [cat_step(c) for c in "EF"]                                              # cost colleagues
    steps += [len_step("len_colleague", 2.5, "a colleague to take"), len_step("len_colleague", 4.5, "a colleague to take")]
    steps.append(("allow back-to-back shifts (12 h 15 min in a row at most)",         # always last (3.3)
                  lambda cur: None if b2b_on(cur) else {"back_to_back": True}))
    return steps


def explain_few(S, shown, rows_all, stats, finder, clin, req, base=None):
    """Fewer than FEW options: why, and a cumulative ladder of loosened settings (dates only hinted)."""
    st = stats.get(S.id, {})
    items = sorted(((k, v) for k, v in st.items() if v and k != "colleagues considered"), key=lambda kv: -kv[1])
    who = [(k[len("colleagues "):], v) for k, v in items if k.startswith("colleagues ")]
    trades = [(k, v) for k, v in items if not k.startswith("colleagues ")]
    if base is not None:   # location switch: the trade is always on the same day
        who = [(k.replace(NO_DATES().replace("colleagues ", "", 1), "not working that day"), v) for k, v in who]
    out = []
    if who:
        out.append("WHY_COLLEAGUES (colleagues ruled out): " + "; ".join(f"{k}: {v}" for k, v in who))
    if trades:
        out.append("WHY_TRADES (possible trades ruled out, by the first rule they failed): "
                   + "; ".join(f"{k}: {v}" for k, v in trades))
    considered = st.get("colleagues considered", 0)
    no_dates = st.get(NO_DATES(), 0)
    dates_limit = base is None and req.get("into") and no_dates >= 0.3 * max(1, considered + no_dates)
    if dates_limit:
        out.append(f"DATES_LIMITING: {no_dates} colleagues have no shift {WHO} could take in {YOUR()} dates. Suggest widening "
                   "them; re-run only if the user wants to.")
    flt = req.get("filter")
    ladder = [f"LADDER: with {YOUR()} settings: {len(shown)}"]
    cur = dict(req) if base is None else dict(req, **base)
    count = len(shown)
    shown_steps = 0
    steps = loosen_steps(req, clin)
    if S.is_jeop and req.get("jeop_mode") != "any":
        steps.insert(0, (f"also accept a scheduled shift for {YOUR()} Jeopardy",
                         lambda cur: None if cur.get("jeop_mode") == "any" else {"jeop_mode": "any"}))
    if base is None:   # swap: the sites they left out come first
        steps.insert(0, (f"all sites {YOURE()} eligible for",
                         lambda cur: None if set(cur.get("sites") or ALL_SITES) >= set(ALL_SITES) else {"sites": list(ALL_SITES)}))
    total = lambda t: len(apply_filter(finder(t), flt, S))
    remaining = list(steps)
    moved = True
    while count < FEW and moved:   # greedy: the first step (in preference order) that adds options, then look again
        moved = False
        for i, (label, fn) in enumerate(remaining):
            ch = fn(cur)
            if ch is None:
                continue
            trial = dict(cur, **ch)
            new = total(trial)
            if new > count:   # kept only when it adds options, so every total is exactly what applying it gives
                ladder.append(f"LADDER: + {label}: {new}")
                cur, count = trial, new
                shown_steps += 1
                remaining.pop(i)
                moved = True
                break
    if remaining and count < FEW:   # some changes only help together (e.g. another shift time AND a longer shift)
        def build(fns):
            t = dict(cur)
            for fn in fns:
                ch = fn(t)
                if ch:
                    t.update(ch)
            return t
        fns = [fn for _, fn in remaining]
        new = total(build(fns))
        if new > count:
            need = list(fns)
            for fn in reversed(fns):   # drop every change that isn't needed for that total
                rest = [x for x in need if x is not fn]
                if total(build(rest)) >= new:
                    need = rest
            t = build(need)
            what = []
            c_order, c_types, c_sites, c_cats, c_up, c_col = prefs(cur, clin)
            n_order, n_types, n_sites, n_cats, n_up, n_col = prefs(t, clin)
            if n_sites - c_sites:
                what.append(f"include all {YOUR()} eligible sites")
            if t.get("jeop_mode") != cur.get("jeop_mode"):
                what.append(f"accept a scheduled shift for {YOUR()} Jeopardy")
            added = [k for k in DEFAULT_ORDER if k in n_types - c_types]
            if added:
                what.append("add " + ", ".join(CAT_LABEL[k] for k in added) + " shifts")
            if n_cats - c_cats:
                what.append("add categor" + ("ies " if len(n_cats - c_cats) > 1 else "y ") + ", ".join(sorted(n_cats - c_cats)))
            if n_up > c_up:
                what.append(f"allow {WHO} to take a shift up to {n_up:g} h longer")
            if n_col > c_col:
                what.append(f"allow a colleague to take a shift up to {n_col:g} h longer")
            if b2b_on(t) and not b2b_on(cur):
                what.append("allow back-to-back shifts")
            ladder.append(f"LADDER: + {' and '.join(what)} (these only help together): {new}")
            count = new
            shown_steps += 1
    if shown_steps or dates_limit:
        print(f"FEW_RESULTS: fewer than {FEW} options.")
        for line in out + (ladder if shown_steps else []):
            print(line)
        print("LADDER_END: offer to apply any of these steps (each total includes the steps above it), or to loosen "
              "anything else the user prefers." + choices_hint(shown_steps + 1) if shown_steps else
              "LADDER_END: no setting adds options; offer wider dates if they'd like.")
    else:
        print(f"NOTHING_TO_LOOSEN: {len(shown)} option(s), and no setting would add more. "   # 4.6
              + ("Say exactly \"No one fits these dates and settings.\" (a one-line reason from below is fine), show no "
                 "empty list, and offer [Change something] [Try other dates] [I'm done]." if not shown else
                 "Say exactly \"No search setting I can loosen would add more options.\" (a short recommendation on how "
                 "to proceed is fine), then show them. The reasons below are for 'why' questions:"))
        for line in out:
            print(line)


def trade_ctx(shifts, clin, req, give_list, same_day=False, accept_sites=None):
    """The settings find_trades uses, as keyword arguments for _trades_for and trade_rules (9.5)."""
    order, types, sites, cats, len_up, len_col = prefs(req, clin)
    return dict(clin=clin, n=now(), days=trade_into_dates(req, shifts), same_day=same_day,
                jeop_any=req.get("jeop_mode") == "any", types=types, sites=accept_sites or sites, req=req, len_up=len_up,
                len_col=len_col, give_ids=set(s.id for s in give_list), order=order, cats=cats)


HARD = "hard"   # trade_rules: a rule no setting changes (the kind of shift, or eligibility for it)


def trade_rules(P, S, T, clin, n, days, same_day, jeop_any, types, sites, req, len_up, len_col, give_ids, order, cats):
    """9.5: EVERY rule that blocks trading S for colleague P's shift T, not only the first one _trades_for counts.
    -> None (not a candidate at all), (HARD, [rule]) when no setting could change it, or (None, [rules]) ([] = it works).
    Same rules, in the same order and with the same labels, as _trades_for (a unit test keeps them in step)."""
    if same_day and (T.sdate != S.sdate or T.is_ml or T.is_jeop):
        return None
    kind = "shift kind (ML trades only for ML, Jeopardy only for Jeopardy)"
    if S.is_jeop:
        if T.is_ml:
            return HARD, [kind]
    elif S.is_ml:
        if not T.is_ml:
            return HARD, [kind]
    elif T.is_ml or T.is_jeop:
        return HARD, [kind]
    if not eligible(clin, T, clin, S.is_ml):
        return HARD, [Y("you're not eligible for their shift", "{n} is not eligible for their shift")]
    out = []
    if S.is_jeop and not T.is_jeop and not jeop_any:
        out.append(kind)
    if not fits_clinician_prefs(T, types, set(ALL_SITES) | {T.site}, S, req):
        out.append(Y("your shift times", "{n}'s shift times"))
    if T.loc != "JEOP" and T.site not in sites:
        out.append(Y("your sites", "{n}'s sites"))
    if blocked(T, req.get("blocks"), all_vacations(req)) or on_vacation(clin, T):
        out.append(Y("your blocked dates or vacation", "{n}'s blocked dates or vacation"))
    if not (S.is_jeop or T.is_jeop):
        d = T.hours - S.hours
        if d > len_up + 1e-6:
            out.append(f"shift length ({d:g} h longer for {WHO}; allowed: {len_up:g})")
        elif -d > len_col + 1e-6:
            out.append(f"shift length ({-d:g} h longer for them; allowed: {len_col:g})")
    okc, rc, _ = check(clin.shifts, T, remove_ids=give_ids, b2b=b2b_on(req))
    if not okc:
        out.append(Y("your rest time or days in a row", "{n}'s rest time or days in a row") + f" ({why_rest(rc, clin.shifts, T, give_ids, True)})")
    okp, rp, _ = check(P.shifts, S, remove_ids={T.id}, b2b=b2b_colleague(P))
    if not okp:
        out.append(f"their rest time or days in a row ({why_rest(rp, P.shifts, S, {T.id}, False)})")
    c = TIER_CAT[TIER[(outcome(T.rank(order), S.rank(order)), outcome(S.rank(P.order), T.rank(P.order)))]]
    if c not in cats:
        out.append(f"trade categories (this one is {c}, {CAT_NAME[c]})")
    return None, out


def why_rest(r, sched, add, remove_ids, mine):
    """C2:177/180: a rest-rule reason in plain words for WHY lines. An overlap is "already working then"; "back-to-back
    shifts are off" is named only when turning them on would help (else the rule that still fails, e.g. the
    12 h 15 min limit)."""
    if r.startswith("overlaps "):
        return f"{Y('you are', '{n} is') if mine else 'they are'} already working then: {r[len('overlaps '):]}"
    if r.endswith("back-to-back shifts are off"):
        ok2, r2, _ = check(sched, add, remove_ids=remove_ids, b2b=True)
        if not ok2:
            head = r.split(";")[0]
            if r2.startswith("back-to-back would total"):
                return f"{head}, {r2[len('back-to-back would total '):]} in a row: over the 12 h 15 min limit even with back-to-back shifts on"
            return why_rest(r2, sched, add, remove_ids, mine)
    return r


def person_block(P, S, clin, ctx):
    """A rule about the colleague themself that stops every trade (as find_trades checks it) -> label or None."""
    if P is clin:
        return "that's the clinician"
    if P.role == "Moonlighter" or P.trade_partner != "Y":
        return "not a trade partner (moonlighter, or not in the trade pool)"
    if not eligible(P, S, clin, S.is_ml):
        return Y("not eligible for your shift", "not eligible for {n}'s shift")
    off = colleague_off(P, S)   # ShiftAdmin vacation (unless a roster exception frees it) or their roster blocks, 3.2
    if off:
        return {"colleagues on vacation that day": "on vacation that day",
                "colleagues' blocked dates (roster)": "their own blocked dates on the roster"}.get(off, off)
    return None


def why_people(S, people, clin, req, finder, ctx, base=None):
    """9.5 "Why wasn't Dr. X offered?": for each colleague in req["why"], every rule blocking each of their shifts
    (WHY_PERSON and indented lines), then a re-run of each single setting change (WHY_FIX).
    finder(settings, P) -> the options with P under those settings, exactly as the search shows them."""
    for x in req.get("why") or []:
        hit = find_person(people, x)
        if len(hit) != 1:
            continue
        P = hit[0]
        flt = req.get("filter")
        listed = finder(req if base is None else dict(req, **base), P)
        found, found_ids = len(listed), {r[1].id for r in listed}
        head = f"WHY_PERSON {P.name}: {found} option(s) for this shift with {YOUR()} settings" + (
            f" and {YOUR()} narrowing" if flt else "")
        if found:   # C2:176: they ARE offered; say so, so no line reads as if they weren't
            head += (f". ALREADY_LISTED: they're already on the list ({', '.join('#' + r[1].id for r in listed)}); "
                     "say so first")
        pb = person_block(P, S, clin, ctx)
        cands = [T for T in P.shifts if T.start > ctx["n"] and T.sdate in ctx["days"]]
        hard, lines = {}, []
        narrowing = Y("your narrowing", "the narrowing") + " (the filter chosen after the wide search)"
        for T in [] if pb else cands:
            if T.id in found_ids:
                continue
            res = trade_rules(P, S, T, **ctx)
            if res is not None and res[0] == HARD:
                hard[res[1][0]] = hard.get(res[1][0], 0) + 1
                continue
            if res is None and not flt:
                continue
            rules = list(res[1]) if res is not None else []   # fix 3 #11: no rule, but the narrowing left it out
            if flt:   # C2:175: an option the narrowing took out is named, never dropped
                tier = TIER[(outcome(T.rank(ctx["order"]), S.rank(ctx["order"])), outcome(S.rank(P.order), T.rank(P.order)))]
                if not apply_filter([(tier, T, P, [])], flt, S):
                    rules.append(narrowing + (" leaves it out" if not rules else " also leaves it out"))
            if rules:
                lines.append(f"  #{T.id} {T.label()}: " + "; ".join(rules))
        if pb:
            print(f"{head}. Blocked for every shift: {pb} (a rule about them, not a setting).")
        elif not cands:
            print(f"{head}. They have no shift in {YOUR()} dates.")
        elif not lines and not hard:
            print(f"{head}. No other shift of theirs in {YOUR()} dates is left out.")
        elif not lines:   # C2#11: only rules no setting changes; never a heading with nothing under it
            print(f"{head}. No setting leaves out any {'other ' if found else ''}shift of theirs in {YOUR()} dates; "
                  f"{'the rest' if found else 'these'} can never be traded for this shift:")
            for k, v in hard.items():
                print(f"  {v} can never be traded for this shift: {k} (no setting changes this)")
        else:
            print(f"{head}. Every rule blocking each of their shifts not offered, in {YOUR()} dates:")
            for ln in lines:
                print(ln)
            for k, v in hard.items():
                print(f"  {v} more can never be traded for this shift: {k} (no setting changes this)")
        if pb:
            print(f"WHY_FIX {P.name}: no setting change brings them in. Answer 'why' from the WHY_PERSON and WHY_FIX lines "
                  "only; name every rule.")
            continue
        cur = dict(req) if base is None else dict(req, **base)
        steps = loosen_steps(req, clin)
        if S.is_jeop and req.get("jeop_mode") != "any":
            steps.insert(0, (f"also accept a scheduled shift for {YOUR()} Jeopardy",
                             lambda c: None if c.get("jeop_mode") == "any" else {"jeop_mode": "any"}))
        if base is None:
            steps.insert(0, (f"all sites {YOURE()} eligible for",
                             lambda c: None if set(c.get("sites") or ALL_SITES) >= set(ALL_SITES) else {"sites": list(ALL_SITES)}))
            steps.append(("all dates in the schedule", lambda c: {"into": None} if c.get("into") else None))
        if flt:
            steps.append((f"without {Y('your', 'the')} narrowing", lambda c: {"filter": None} if c.get("filter") else None))
        helps, seen = [], {}
        for label, fn in steps:
            ch = fn(cur)
            if ch is None:
                continue
            k = len(finder(dict(cur, **ch), P))
            key = tuple(sorted(ch)) if set(ch) <= {"len_up", "len_colleague"} else label
            if k > max(found, seen.get(key, 0)):   # a longer length limit is named only if it adds more than a shorter one
                helps.append(f"+ {label}: {k} option(s) with them")
                seen[key] = k
        none = ("no single setting change adds more of their shifts" if found else
                "no single setting change brings them in (it needs several, or a rule that isn't a setting)")
        print(f"WHY_FIX {P.name} (each setting change on its own, re-run"
              + (f"; they're already on the list with {found}" if found else "") + "): "
              + ("; ".join(helps) if helps else none)
              + ". Answer 'why' from the WHY_PERSON and WHY_FIX lines only; name every rule, and suggest only a change "
                "listed here.")


def empty_rows(S, shown, rows_all, types, pref_sites, req, finder):
    """Checked shift times with no options (when there are enough options overall that no ladder is shown):
    what would add some, one change at a time."""
    empty = [k for k in types if k in CAT_LABEL and not any(row_type(r[1]) == k for r in shown)]
    if not empty or req.get("filter"):
        return
    keep = lambda rows: [r for r in rows if r[1].is_jeop or r[1].site in pref_sites]
    trials = []
    if float(req.get("len_up", 0)) < 2.5:
        trials.append((Y("if you'd take a shift up to 2.5 h longer", "if {n} would take a shift up to 2.5 h longer"), keep(finder(dict(req, sites=list(ALL_SITES), len_up=2.5)))))
    cats = set(req.get("categories") or ["A", "B", "C", "D"])
    for c in "ABCDEF":   # each category on its own, so the hint names the one that matters
        if c not in cats:
            trials.append((f"if {WHO} add{Y('', 's')} category {c} ({CAT_NAME[c]})",
                           keep(finder(dict(req, sites=list(ALL_SITES), categories=sorted(cats | {c}))))))
    parts, none = [], []
    for k in [c for c in DEFAULT_ORDER if c in empty]:
        bits = []
        other = sum(1 for r in rows_all if row_type(r[1]) == k and not r[1].is_jeop and r[1].site not in pref_sites)
        if other:
            bits.append(f"{other} at sites {WHO} left out")
        for label, rows in trials:
            n = sum(1 for r in rows if row_type(r[1]) == k)
            if n:
                bits.append(f"+{n} {label}")
        if bits:
            parts.append(f"{CAT_LABEL[k]}: " + "; ".join(bits))
        else:
            none.append(CAT_LABEL[k])
    if none:
        parts.append("none even with one setting loosened: " + ", ".join(none))
    if not parts:   # fix 3 #11: no empty row, no line
        return
    print(f"EMPTY_ROWS (shift times {WHO} chose that have no options, and what one change would add): " + " | ".join(parts))


def apply_filter(rows, flt, S=None):
    """Narrowing (show me everything, then narrow): sites, time, daytype, dates, and (4.1) trade "categories" and
    shift length ("len_up": at most this many hours longer for you, "len_colleague": for the colleague; needs S)."""
    if not flt:
        return rows
    out = []
    for r in rows:
        T = r[1]
        if flt.get("categories") and r[2] is not None and TIER_CAT[r[0]] not in flt["categories"]:
            continue
        if S is not None and not (S.is_jeop or T.is_jeop) and (
                ("len_up" in flt and T.hours - S.hours > float(flt["len_up"]) + 1e-6) or
                ("len_colleague" in flt and S.hours - T.hours > float(flt["len_colleague"]) + 1e-6)):
            continue
        if flt.get("sites") and T.site not in set(norm_site(x) for x in flt["sites"]):
            continue
        if flt.get("time") and T.tc not in flt["time"]:
            continue
        if flt.get("daytype"):
            dt = "holiday" if T.hol == "HOL" else ("weekend" if T.cat.startswith("WE") else ("friday" if T.cat.startswith("FRI") else "weekday"))
            if dt not in flt["daytype"]:
                continue
        if flt.get("times") and row_type(T) not in filter_times(flt):
            continue
        if flt.get("dates"):
            if T.sdate not in parse_dates(flt["dates"], T.sdate, T.sdate):
                continue
        out.append(r)
    return out


def filter_times(flt):
    """C2:149: a filter's "times": shift-time codes (WD_DAY, MT_EVE, FRI_EVE, WE_DAY, WE_EVE, MT_ON, FRI_ON, WE_ON,
    HOL_DAY, HOL_EVE, HOL_ON; "HOL" = all three holiday times) or their names ("weekend day", "Mon-Thu evening"), so
    combinations like "weekend days and weekday evenings" are one filter: ["WE_DAY", "MT_EVE", "FRI_EVE"]."""
    by_name = {v.lower(): k for k, v in CAT_LABEL.items()}
    out = set()
    for x in expand_hol(flt.get("times") or []):
        k = str(x).strip()
        out.add(k.upper() if k.upper() in CAT_LABEL else by_name.get(k.lower(), k))
    return out


def filter_keeps_time(k, flt):
    """Would the filter keep shift time k (a CAT_LABEL code) at all? (time, daytype and times; sites etc. aside)"""
    if not flt:
        return True
    tc = {"DAY": "day", "EVE": "evening", "ON": "overnight"}.get(k.rsplit("_", 1)[-1])
    dt = "holiday" if k.startswith("HOL") else ("weekend" if k.startswith("WE") else ("friday" if k.startswith("FRI") else "weekday"))
    if flt.get("time") and tc not in flt["time"]:
        return False
    if flt.get("daytype") and dt not in flt["daytype"]:
        return False
    if flt.get("times") and k not in filter_times(flt):
        return False
    return True


def table_types(types, flt):
    """C2:146: the shift times the table counts; a row the narrowing removed shows '–' (not chosen), never 0."""
    return {k for k in types if filter_keeps_time(k, flt)} if flt else types


def resolve_give(clin, req):
    n = now()
    ids = [str(x) for x in req.get("give_ids", [])]
    give = [s for s in clin.shifts if s.id in ids and s.start > n]
    if len(give) != len(ids):
        print("ERROR: some give_ids are not upcoming shifts of %s. Run 'shifts' first." % clin.name)
        sys.exit(2)
    return give


def unknown_why(req, people):
    for x in req.get("why") or []:
        if len(find_person(people, x)) != 1:
            print(f"WHY_PERSON {x}: not found on the roster (or more than one match); ask for the full name.")


def narrow_cols(cols, flt):
    """9.6 (C3): after narrowing to some sites (a "filter" with "sites"), the table shows only those columns."""
    keep = set(filter(None, (norm_site(x) for x in (flt or {}).get("sites") or [])))
    return [c for c in cols if c in keep] if keep else cols


def few_basis(shown, before, req):
    """9.6 (C3): "few results" ignores a narrowing the user chose: with a "filter", the check and the ladder use the
    options before it (and a NARROWED line says so) -> (options to judge, request to loosen)."""
    if not req.get("filter"):
        return shown, req
    if len(shown) < FEW:
        print(f"NARROWED: {len(shown)} of {len(before)} option(s) after {YOUR()} narrowing; the few-results check "
              "ignores the narrowing" + (" (no FEW_RESULTS: there are enough without it)." if len(before) >= FEW else "."))
    return before, dict(req, filter=None)


def cmd_swap(args):
    shifts, people, clin, req, src = setup(args)
    unknown_why(req, people)
    give = resolve_give(clin, req)
    days = trade_into_dates(req, shifts)
    fy_flags(days)
    if req.get("ml_mode") == "giveaway":
        for S in give:
            print(f"\n=== Giving away #{S.id} " + shift_line(S))
            ok = []
            for P in people:
                if P is clin or P.role == "Moonlighter" or not eligible(P, S, clin, True) or colleague_off(P, S):
                    continue
                if not P.shifts and P.status_on(S.sdate)[0] not in FELLOW_JUNIOR:
                    continue  # no scheduled shifts (research/admin) - only Y1/Y2 fellows are kept
                if check(P.shifts, S, b2b=b2b_colleague(P))[0]:
                    ok.append(P)
            prim = nkey(req.get("primary") or "")
            print(f"{len(ok)} colleague(s) could take it, by level:")
            groups = {}
            for P in ok:
                groups.setdefault(role_label(P), []).append(P)
            for lbl in sorted(groups, key=lambda x: (TIER_ORDER.index(groups[x][0].role) if groups[x][0].role in TIER_ORDER
                                                     else 99, x)):
                names = sorted(groups[lbl], key=lambda p: p.name)
                print(f"  {lbl} ({len(names)}): " + "; ".join(p.name + (Y(" (you)", "") if prim and nkey(p.name) == prim else "")
                                                               for p in names))
            if len(ok) > LIST_MAX:
                print(f"OVER_{LIST_MAX}: give the count and the levels; offer to send to everyone, or to one or more levels, "
                      "or to people they pick." + choices_hint(len(groups) + 2, multi=len(groups) > 1))
            print_vac_exceptions((S.id, P.name) for P in ok)
            usage_line("giveaway", S, [(1, S, P, []) for P in ok], req)
        print_feedback()
        return
    order, types, pref_sites, _, len_up, _ = prefs(req, clin)
    sorder = site_order(req, clin)
    stats = {}
    res = find_trades(shifts, people, clin, dict(req, sites=list(ALL_SITES)), give, stats=stats)
    for S in give:
        rows_all = res[S.id]
        before = [r for r in rows_all if r[1].is_jeop or r[1].site in pref_sites]
        shown = apply_filter(before, req.get("filter"), S)
        _, el_sites, _, _ = clin.status_on(S.sdate)
        cols = narrow_cols([x for x in sorder if x in pref_sites and FACILITY_LOC(x) in el_sites], req.get("filter"))
        print_results(S, shown, clin, req.get("show"), order, sorder, cols=cols, types=table_types(types, req.get("filter")),
                      tag_same_day=True, wide=bool(req.get("everything")), narrowed=bool(req.get("filter")))
        why_people(S, people, clin, req, lambda r, P, S=S: apply_filter(find_trades(shifts, [P], clin, r, give)[S.id],
                                                                        r.get("filter"), S),
                   trade_ctx(shifts, clin, req, give))
        if len(shown) >= FEW:
            empty_rows(S, shown, rows_all, types, pref_sites, req,
                       lambda r, S=S: find_trades(shifts, people, clin, r, [S])[S.id])
        if len(shown) < 20:
            other = __import__("collections").Counter(
                r[1].site for r in apply_filter(rows_all, req.get("filter"), S) if not r[1].is_jeop and r[1].site not in pref_sites)
            if other:
                print(f"OTHER_SITES: {sum(other.values())} more at sites {WHO} left out: "
                      + ", ".join(f"{k} {other[k]}" for k in sort_sites(other, sorder)))
        few, few_req = few_basis(shown, before, req)
        if len(few) < FEW:
            explain_few(S, few, rows_all, stats, lambda r: find_trades(shifts, people, clin, r, [S])[S.id], clin, few_req)
        usage_line("swap", S, shown, req)
    multi = {}
    for sid, rows in res.items():
        for r in rows:
            multi.setdefault(r[2].name, set()).add(sid)
    both = [n for n, v in multi.items() if len(v) > 1]
    if both:
        print(f"\nNOTE: these colleagues appear for more than one of {YOUR()} shifts; each trade was checked on its own, "
              "so confirm the combination before offering both: " + "; ".join(both))
    print_vac_exceptions((sid, r[2].name) for sid, rows in res.items() for r in rows)
    audit_person(clin)
    print_feedback()


def parse_site_ratings(v):
    """Saved location ratings from the request: {"OPE": 9, ...}, [["OPE", 9], ...], ["OPE 9", ...] or the memory
    line "OPE 9.00, B ED 8.00" -> {site: rating}. "no preference", "ask again" or anything unreadable gives {}."""
    items = v.items() if isinstance(v, dict) else None
    if items is None:
        parts = re.split(r"[;,]", v) if isinstance(v, str) else list(v or [])
        items = []
        for x in parts:
            if isinstance(x, (list, tuple)) and len(x) == 2:
                items.append(tuple(x))
            elif isinstance(x, str) and re.match(r"^\s*(.+?)[\s:=]+(\d+(?:\.\d+)?)\s*$", x):
                items.append(re.match(r"^\s*(.+?)[\s:=]+(\d+(?:\.\d+)?)\s*$", x).groups())
    out = {}
    for k, r in items:
        site = norm_site(str(k))
        try:
            if site:
                out[site] = float(r)
        except (TypeError, ValueError):
            pass
    return out


def sites_to_move_to(clin, req, leave):
    """Swap Locations 2 (plan 2.3, 0.01.08 only): every eligible site rated higher than ALL the sites being left, with
    its rating, for Claude to confirm with [Use these] [Change them]."""
    ratings = parse_site_ratings(req.get("site_ratings"))
    order = site_order(req, clin)
    fmt = lambda x: f"{x} {ratings[x]:g}"
    ask = " Say so in one line and ask which sites they'd accept (these become \"accept_sites\")."
    rated_leave = [x for x in sort_sites(leave, order) if x in ratings]
    if not ratings or not rated_leave:
        why = "no location ratings saved" if not ratings else "no rating for " + ", ".join(sort_sites(leave, order))
        print(f"SITES_TO_MOVE_TO: none ({why})." + ask)
        return
    top = max(ratings[x] for x in rated_leave)
    mine = clin.status_on(now().date())[1]
    higher = sorted((x for x in ratings if x not in leave and ratings[x] > top), key=lambda x: (-ratings[x], order.index(x)))
    ok = [x for x in higher if FACILITY_LOC(x) in mine]
    notes = []
    if len(rated_leave) < len(leave):
        notes.append("not rated, so not compared: " + ", ".join(x for x in sort_sites(leave, order) if x not in ratings))
    if len(ok) < len(higher):
        notes.append("rated higher but not eligible, left out: " + ", ".join(fmt(x) for x in higher if x not in ok))
    head = f"SITES_TO_MOVE_TO (rated higher than {'every site' if len(rated_leave) > 1 else 'the site'} being left: " \
           + ", ".join(fmt(x) for x in rated_leave) + ("; " + "; ".join(notes) if notes else "") + ")"
    if not ok:
        print(f"{head}: none." + ask)
        return
    print(f"{head}: " + ", ".join(fmt(x) for x in ok) + ". Show each with its rating and ask \"Are these still right?\" "
          "[Use these] [Change them]. Use these: \"accept_sites\": " + json.dumps(ok) + ". Change them: ask which sites "
          "they'd accept, in their location order.")


def cmd_locswitch(args):
    shifts, people, clin, req, src = setup(args)
    unknown_why(req, people)
    n = now()
    leave = set(filter(None, (norm_site(x) for x in req.get("leave_sites", []))))
    accept = set(filter(None, (norm_site(x) for x in req.get("accept_sites", []))))
    if leave and not accept and not req.get("count_only"):   # Swap Locations 2: suggest the sites to move to (2.3)
        sites_to_move_to(clin, req, leave)   # C4#3: no saved ratings gives SITES_TO_MOVE_TO: none, never an error
        print_feedback()
        return
    if not leave or not (accept or req.get("count_only")):
        print("ERROR: leave_sites and accept_sites are required.")
        sys.exit(2)
    days = parse_dates(req.get("dates"), n.date(), max(s.sdate for s in shifts))
    sorder = site_order(req, clin)
    give = [s for s in clin.shifts if s.site in leave and s.sdate in days and s.start > n and not s.is_ml and not s.is_jeop]
    print(f"{clin.name}: {len(give)} shift(s) at {', '.join(sort_sites(leave, sorder))} in the requested dates"
          + (f"; switching to {', '.join(sort_sites(accept, sorder))}." if accept else "."))
    if req.get("count_only"):
        for S in give:
            print(f"  #{S.id} " + shift_line(S))
        if give:
            print("COUNT_ONLY: tell them how many shifts there are (each gets its own table), then ask the rest.")
        else:   # C3#15 (Swap Locations 3: None: say so and stop)
            print(f"COUNT_ONLY: none. {Y('You have', '{n} has')} no shifts at those sites in those dates: say so and stop "
                  "(they can pick other sites or dates).")
        print_feedback()
        return
    fy_flags(days)
    req = dict(req, into=[[str(min(days)), str(max(days))]] if days else None)
    stats = {}
    res = find_trades(shifts, people, clin, req, give, same_day=True, accept_sites=accept, stats=stats)
    order = prefs(req, clin)[0]
    for S in give:
        shown = apply_filter(res[S.id], req.get("filter"), S)
        print_results(S, shown, clin, req.get("show"), order, sorder, cols=narrow_cols(sort_sites(accept, sorder),
                                                                                       req.get("filter")),
                      types=table_types(prefs(req, clin)[1], req.get("filter")), narrowed=bool(req.get("filter")))
        why_people(S, people, clin, req,
                   lambda r, P, S=S: apply_filter(find_trades(shifts, [P], clin, r, give, same_day=True,
                                                              accept_sites=accept)[S.id], r.get("filter"), S),
                   trade_ctx(shifts, clin, req, give, same_day=True, accept_sites=accept), base={})
        few, few_req = few_basis(shown, res[S.id], req)
        if len(few) < FEW:
            explain_few(S, few, res[S.id], stats,
                        lambda r, S=S: find_trades(shifts, people, clin, r, [S], same_day=True, accept_sites=accept)[S.id],
                        clin, few_req, base={})
        usage_line("locswitch", S, shown, req)
    print_vac_exceptions((sid, r[2].name) for sid, rows in res.items() for r in rows)
    print_feedback()


def read_xls(path):
    sys.path.insert(0, os.path.join(HERE, "vendor"))
    import xlrd  # bundled
    try:
        book = xlrd.open_workbook(path, ignore_workbook_corruption=True, logfile=open(os.devnull, "w"))
    except Exception as e:
        print(f"ERROR: could not read the Available Shifts file ({e}). Ask for the 'Excel version' download.")
        sys.exit(2)
    sh = book.sheet_by_index(0)
    rows = [[str(sh.cell_value(r, c)).strip() for c in range(sh.ncols)] for r in range(sh.nrows)]
    hdr = next((i for i, r in enumerate(rows) if r and r[0] == "Facility"), None)
    if hdr is None:
        print("ERROR: this does not look like the ShiftAdmin Available Shifts file.")
        sys.exit(2)
    cols = rows[hdr]
    return [dict(zip(cols, r)) for r in rows[hdr + 1:] if any(r)]


def xls_shift(r, i):
    fac = r.get("Facility", "")
    if fac not in FACILITY:
        fb(f"Unknown facility in Available Shifts file: '{fac}'.")
        return None
    site, loc, prefix = FACILITY[fac]
    m = re.match(r"\s*(\d{1,2}:\d{2}\s*[ap]m)\s*-\s*(\d{1,2}:\d{2}\s*[ap]m)", r.get("Time", ""), re.I)
    if not m:
        fb(f"Could not read the time '{r.get('Time')}' in the Available Shifts file.")
        return None
    d = datetime.strptime(r["Date"], "%m-%d-%Y").date()
    st = datetime.combine(d, datetime.strptime(m.group(1).replace(" ", "").upper(), "%I:%M%p").time()).replace(tzinfo=ET)
    en = datetime.combine(d, datetime.strptime(m.group(2).replace(" ", "").upper(), "%I:%M%p").time()).replace(tzinfo=ET)
    if en <= st:
        en += timedelta(days=1)
    s = Shift()
    s.id = f"X{i}"
    s.facility, s.site, s.loc, s.prefix = fac, site, loc, prefix
    s.full = s.code = r.get("Name", "")
    s.stype = r.get("Type", "")
    s.level = classify_level(fac, s.stype, s.full, s.code, loc)
    known_code(fac, s.code)
    s.start, s.end = st, en
    s.notes = []
    s.buddy = s.ml_pay = False
    s.is_ml = "ML" in s.code.upper() or s.stype == "Moonlighting"
    s.who = None
    s.posted_by = r.get("Posted By", "").strip("- ")
    s.status = r.get("Status", "").upper()
    s.src = "xls"
    if r.get("Comments"):
        s.notes.append(r["Comments"])
    return finish_shift(s)


def xls_file_date(path):
    """The Available Shifts file's date -> (date, how): from its title row ("Available Shifts - 09-21-2026 - ...",
    the first day it lists), else the file's modified time."""
    try:
        sys.path.insert(0, os.path.join(HERE, "vendor"))
        import xlrd  # bundled
        sh = xlrd.open_workbook(path, ignore_workbook_corruption=True, logfile=open(os.devnull, "w")).sheet_by_index(0)
        for r in range(min(sh.nrows, 5)):
            m = re.match(r"\s*Available Shifts\s*-\s*(\d{2}-\d{2}-\d{4})", str(sh.cell_value(r, 0)))
            if m:
                return datetime.strptime(m.group(1), "%m-%d-%Y").date(), "from the file's title row"
    except Exception:
        pass
    return datetime.fromtimestamp(os.path.getmtime(path), ET), "from the file's modified time"


def xls_unreadable(path):
    """C4#9: can the Available Shifts file be read at all? -> the reason it can't, or None."""
    if not os.path.isfile(path):
        return "the file isn't there"
    try:
        sys.path.insert(0, os.path.join(HERE, "vendor"))
        import xlrd  # bundled
        sh = xlrd.open_workbook(path, ignore_workbook_corruption=True, logfile=open(os.devnull, "w")).sheet_by_index(0)
        if not any(str(sh.cell_value(r, 0)).strip() == "Facility" for r in range(min(sh.nrows, 15))):
            return "it doesn't look like the ShiftAdmin Available Shifts file"
    except Exception:
        return "the file is damaged or isn't an Excel file"
    return None


def xls_date_lines(path, req, full=False):
    """Pickup Moonlighting 1 (plan 2.3): say the file's date; more than a day old -> ask before using it.
    full: the search itself (the date was already said at --file-date, so it isn't repeated, C4#8)."""
    d, how = xls_file_date(path)
    n = now()
    if isinstance(d, datetime):
        old, days = n - d > timedelta(days=1), (n.date() - d.date()).days
    else:
        old, days = (n.date() - d).days > 1, (n.date() - d).days
    fell_back = isinstance(d, datetime)   # answer 17: no date in the title row, so the file's modified time
    note = " (the file's title row has no date, so this is when the file was last saved)" if fell_back else ""
    ask_old = old and not req.get("old_file_ok")
    future = days < 0   # C4#9: dated after today
    if full and not ask_old:
        print(f"AVAILABLE_SHIFTS_FILE: dated {d:%m/%d/%Y} ({how}); already said at Pickup Moonlighting 1: don't repeat it.")
        return
    print(f"AVAILABLE_SHIFTS_FILE: dated {d:%m/%d/%Y} ({how}). "
          + (f"Don't say it separately: the AVAILABLE_SHIFTS_OLD question below names the date{' and says it is the saved date' if fell_back else ''}."
             if ask_old else "Don't say it separately: the AVAILABLE_SHIFTS_FUTURE question below names the date."
             if future and not req.get("old_file_ok") else
             f"Say it: \"Using {Y('your', 'the')} Available Shifts file from {d:%m/%d}{note}.\""))
    if future and not req.get("old_file_ok"):
        print(f"AVAILABLE_SHIFTS_FUTURE: the file is dated {d:%m/%d}, later than today ({n:%m/%d}){note}, so the date "
              "(or the computer's clock) may be wrong. Say so and ask [Use it anyway] [I'll download a new one]. Use it "
              "anyway: go on, with \"old_file_ok\": true in the mlpickup request.")
    if ask_old:
        print(f"AVAILABLE_SHIFTS_OLD: it's {days} day{'s' if days != 1 else ''} old{note}, and open shifts change daily. "
              f"Say the file is from {d:%m/%d} and ask "
              "[Use it anyway] [I'll download a new one]. Use it anyway: go on, with \"old_file_ok\": true in the "
              "mlpickup request. I'll download a new one: wait for the new file, then check its date again.")


def cmd_mlpickup(args):
    if args.file_date:   # Pickup Moonlighting 1: only the file's date check
        bad = xls_unreadable(args.xls)
        if bad:   # C4#9: found now, before any question
            print(f"AVAILABLE_SHIFTS_UNREADABLE: can't read the Available Shifts file ({bad}). Say so now, before any "
                  "question, and ask them to download it again from ShiftAdmin (the 'Excel version') and attach it.")
            print_feedback()
            return
        xls_date_lines(args.xls, load_req(args.req) if args.req else {})
        print_feedback()
        return
    if not args.req:
        print("ERROR: mlpickup needs --req (or --file-date for the file's date only).")
        sys.exit(2)
    shifts, people, clin, req, src = setup(args)
    n = now()
    xls_date_lines(args.xls, req, full=True)
    rows = read_xls(args.xls)
    xs = [x for x in (xls_shift(r, i) for i, r in enumerate(rows)) if x]
    days = parse_dates(req.get("dates"), n.date(), max([s.sdate for s in xs] + [n.date()]))
    fy_flags(days)
    _, types, sites, _, _, _ = prefs(req, clin)
    sorder = site_order(req, clin)
    vac = sorted(set(str(x.sdate) for x in xs if x.status == "VACATION" and x.sdate in days))
    if vac:
        print("VACATION_DATES (already in ShiftAdmin; for the reminder only; don't save): " + ", ".join(vac))
    groups = {"ok": [], "b2b": [], "m3": []}
    skipped = 0
    b2b_left = 0
    narrowed = 0
    from collections import Counter
    other = Counter()   # open shifts they could pick up at sites or shift times they left out
    for x in xs:
        if x.status in ("NA", "PAST") or x.start <= n or x.sdate not in days:
            continue
        if x.site not in sites or not (x.types() <= types or (x.loc == "JEOP" and x.hol != "HOL")):
            if eligible(clin, x, clin, True) and not blocked(x, req.get("blocks"), []) and \
                    check(clin.shifts, x, b2b=b2b_on(req), m3=True)[0]:
                other["site " + x.site if x.site not in sites else CAT_LABEL.get(x.cat, x.cat)] += 1
            continue
        if not eligible(clin, x, clin, True):
            skipped += 1
            continue
        if blocked(x, req.get("blocks"), []):
            continue
        ok, why, warns = check(clin.shifts, x, b2b=b2b_on(req), m3=True)
        if req.get("filter") and not apply_filter([(0, x, None, [])], req["filter"]):
            narrowed += 1 if ok else 0   # 9.6: counted for the few-results check, which ignores a narrowing the user chose
            continue
        if not ok:
            if why.endswith("back-to-back shifts are off") and check(clin.shifts, x, b2b=True, m3=True)[0]:
                b2b_left += 1   # 4.1: would fit if back-to-back shifts were on
            continue
        tags = []
        if not x.is_ml:
            tags.append("[open Jeopardy]" if x.is_jeop else "[open regular shift]")
        if x.posted_by:
            tags.append(f"[posted by {x.posted_by} - giving it away]")
        if x.status == "VACATION" or on_vacation(clin, x) or blocked(x, [], req.get("vacations")):
            tags.append(f"[reminder: {WHO} {Y('are', 'is')} on vacation this day]")
        if x.status == "CONFLICT":
            tags.append("[ShiftAdmin reports a conflict but the reason isn't clear]")
            fb(f"ShiftAdmin reported a conflict the rules could not explain: {x.label()}.")
        g = "m3" if any(w.startswith("M3") for w in warns) else ("b2b" if warns else "ok")
        groups[g].append((x, tags + warns))
    total = sum(len(v) for v in groups.values())
    print(f"Open shifts {Y('you', '{n}')} can pick up: {total}")   # fix 3 #10: "you" for the primary user
    if skipped:
        print(f"NOT_ELIGIBLE: {skipped} open shift(s) at {YOUR()} sites and shift times need a level {WHO} can't work.")
    if b2b_left:
        print(f"BACK_TO_BACK_LEFT_OUT: {b2b_left} open shift(s) left out because they're back-to-back with one of {YOUR()} "
              "shifts (back-to-back shifts are off). Say how many; offer to include them (re-run with "
              "\"back_to_back\": true; 12 h 15 min in a row at most).")
    if total + narrowed < FEW and other:
        print(f"OTHER_OPEN: {sum(other.values())} more {Y('you could pick up if you widened your choices', '{n} could pick up if they widened their choices')}: "
              + ", ".join(f"{k} {v}" for k, v in other.most_common()) + ". Offer to include any of them.")
    allx = [x for g in groups.values() for x, _ in g]
    print(f"USAGE: mlpickup {total} result(s) sites {dict(Counter(x.site for x in allx))} times "
          f"{dict(Counter(x.tc for x in allx))} | settings: dates={json.dumps(req.get('dates'))}; "
          f"sites={json.dumps(req.get('sites'))}; times={json.dumps(req.get('times') or req.get('types'))}")
    if total > LIST_MAX and req.get("show") != "list":
        allx = [x for g in groups.values() for x, _ in g]
        C = __import__("collections").Counter
        dt = lambda x: "holiday" if x.hol == "HOL" else ("weekend" if x.cat.startswith("WE") else (
            "Friday eve/ON" if x.cat.startswith("FRI") else "weekday"))
        for lbl, f, ordr in (("site", lambda x: x.site, sorder + ["Jeopardy"]),
                             ("time", lambda x: x.tc, ["day", "evening", "overnight"]),
                             ("day type", dt, ["weekday", "Friday eve/ON", "weekend", "holiday"]),
                             ("month", lambda x: x.start.strftime("%Y-%m"), None)):
            c = C(f(x) for x in allx)
            ks = sorted(c, key=lambda k: ordr.index(k) if k in ordr else 99) if ordr else sorted(c)
            print(f"COUNTS by {lbl}: " + ", ".join(f"{k} {c[k]}" for k in ks))
        print(f"(back-to-back: {len(groups['b2b'])}, M3 short rest: {len(groups['m3'])})")
        print(f"OVER_{LIST_MAX}: offer \"Display all\" (re-run with \"show\":\"list\") or narrowing (add a 'filter').")
        print_feedback()
        return
    for g, title in (("ok", ""), ("b2b", f"BACK-TO-BACK with one of {YOUR()} shifts (12 h 15 min or less total):"),
                     ("m3", f"M3 - SHORT REST (ends less than 8 h before {YOUR()} next shift):")):
        if not groups[g]:
            continue
        if title:
            print(title)
        for x, t in sorted(groups[g], key=lambda z: (z[0].start, sorder.index(z[0].site) if z[0].site in sorder else 99)):
            print("  " + shift_line(x, " ".join(t)))
    if total == 0:
        fb("Moonlighting search found no shifts.")
    print_feedback()


def preferred_way(p):
    """'text' or 'email' for a non-urgent trade request, from the free-text contact preference."""
    pref = (p.contact_pref or "").lower()
    if p.cell and re.search(r"text|cell|call", pref):
        return "text"
    return "email" if p.email else ("text" if p.cell else "none on file")


CONTACTS_EACH_MAX = 5   # diagram answer 8: list each recipient's contact preference up to this many; beyond, one line


def cmd_contacts(args):
    people, _ = load_roster()
    from collections import Counter
    ways, no_cell, no_email, unstated, each = Counter(), [], [], 0, []
    for nm in [x.strip() for x in args.names.split(";") if x.strip()]:
        hits = find_person(people, nm)
        if len(hits) != 1:
            print(f"{nm}: {'no match' if not hits else 'ambiguous: ' + ', '.join(h.name for h in hits[:5])}")
            continue
        p = hits[0]
        way = preferred_way(p)
        ways[way] += 1
        each.append(f"{p.name}: {way}" + ("" if p.contact_pref else " (no preference stated)"))
        unstated += not p.contact_pref
        if not p.cell:
            no_cell.append(p.name)
        if not p.email:
            no_email.append(p.name)
        print(f"{p.name} | email {p.email or 'none on file'} | cell {p.cell or 'no cell on file'} | "
              f"prefers: {p.contact_pref or 'not stated'} | preferred way for a trade request: {way}")
        if not p.email or not p.cell:
            fb(f"Contact details missing for {p.name} ({'email' if not p.email else 'cell'}).")
    if 0 < len(each) <= CONTACTS_EACH_MAX:   # diagram answer 8: up to 5 recipients, each one's preference
        print(f"PREFERS_EACH (Delivery, Trade Shifts 8; {len(each)} recipient(s)): " + "; ".join(each)
              + (f". No cell on file: {', '.join(no_cell)}" if no_cell else "")
              + (f". No email on file: {', '.join(no_email)}" if no_email else "")
              + ". Tell them each recipient's preferred way (one short line each, or one line for one recipient), then "
                "ask how to send.")
    elif len(each) > CONTACTS_EACH_MAX:
        print("PREFERS (preferred way for a trade request): " + "; ".join(f"{k} {v}" for k, v in ways.most_common())
              + (f". {unstated} didn't state a preference (email is used for them when there is one)" if unstated else "")
              + (f". No cell on file: {', '.join(no_cell)}" if no_cell else "")
              + (f". No email on file: {', '.join(no_email)}" if no_email else "")
              + f". More than {CONTACTS_EACH_MAX} recipients: give this one-line summary instead of listing everyone; warn "
              "only about people the chosen method goes against (texts can't reach someone with no cell).")
    print_feedback()


BLOCK_COLS = (("blocked_dates", "Blocked dates"), ("recurring_blocked_dates", "Recurring blocks"),
              ("exceptions_to_recurring_blocked_dates_or_vacations", "Can work despite a recurring block or vacation"))


def cmd_myblocks(args):
    """What the roster has for someone's blocked dates (all three columns) plus their upcoming ShiftAdmin vacation days
    (plan 3.2), for comparing with what they've saved and for blocked-date sharing at the wrap-up."""
    shifts, src = load_feed(getattr(args, "ics", None), quiet=True)
    people, by_sched = load_roster()
    hits = find_person(people, args.name)
    if len(hits) != 1:
        print("ERROR: '%s' matched %d roster entries: %s" % (args.name, len(hits), "; ".join(h.name for h in hits[:6])))
        sys.exit(2)
    p, today = hits[0], now().date()
    print(f"MYBLOCKS: {p.name}, as the roster of {ROSTER_DATE} has them. Only dates and shift times, never reasons.")
    for col, label in BLOCK_COLS:
        items = [x.strip() for x in (getattr(p, col, "") or "").split(";") if x.strip()]
        if col != "recurring_blocked_dates":   # past one-time items don't matter any more
            items = [x for x in items if date.fromisoformat(x.split(" ")[0].split("..")[-1]) >= today]
        print(f"  {label}: {'; '.join(items) or 'none'}")
    for q in people:
        q.vac = set()
    attach_vacations(people, {nkey(q.schedule_name): q for q in people}, today, max(s.sdate for s in shifts))
    vac = sorted(d for d in p.vac if d >= today)
    print(f"  ShiftAdmin vacation days (upcoming): {compress_dates(vac) if vac else 'none'}. Only the schedulers can "
          "change these; they can say they're free on one (it goes in the third line).")
    print_feedback()


# ---------------------------------------------------------------- launch, links, changelog, updates
LOGO = [  # "Cinci PEM" in a small slanted letter style; plain characters so it lines up everywhere
    r"  ______          _   ___  ______  ___",
    r" / ___(_)__  ____(_) / _ \/ __/  |/  /",
    r"/ /__/ / _ \/ __/ / / ___/ _// /|_/ /",
    r"\___/_/_//_/\__/_/ /_/  /___/_/  /_/",
]


def short_date(s):
    """'2026-09-23' -> '9/23/26'."""
    try:
        d = date.fromisoformat(str(s)[:10])
        return f"{d.month}/{d.day}/{d:%y}"
    except (TypeError, ValueError):
        return s or "not recorded"


ROLE_DISPLAY = {"Clinical": "Clinical Staff", "Senior Clinical": "Senior Clinical Staff"}   # plan 2.1


def role_label(p, on=None):
    """How a person's role is shown: Faculty, Senior Clinical, Clinical, Senior APP, APP, Fellow Y2, PGY-5, ..."""
    if getattr(p, "is_admin", False):
        return (getattr(p, "title", "") or "Administrator")
    if p.role != "Fellow":
        return ROLE_DISPLAY.get(p.role, p.role)
    key, _, _, fy = p.status_on(on or now().date())
    if fy.startswith("Y"):
        return f"Fellow {fy}, PGY-{3 + int(fy[1])}"   # fix 3 #6: the same year as the permissions line
    return "Faculty"   # graduated fellow


def banner_text(installed):
    """Plan 2.1: the banner comes before the passphrase, so it shows only the skill name, version and channel (and the
    install date), nothing personal; the name and role are in the welcome line (INTRO) after unlocking."""
    w = max(len(x) for x in LOGO)
    ch = "" if CHANNEL == "stable" else " " + CHANNEL
    lines = ["S H I F T M A T E", f"v{VERSION}{ch} ({short_date(BUILD_DATE)})", f"Installed {short_date(installed)}"]
    out = list(LOGO) + [" " * max(0, (w - len(t)) // 2) + t for t in lines]
    return "```\n" + "\n".join(x.rstrip() for x in out) + "\n```"


def ld_format_plain():
    """live/system/format.json of the Local Data folder (plain, nothing personal), read without the key; {} if none."""
    if not LD_ROOT:
        return {}
    try:
        with open(os.path.join(LD_ROOT, "live", "system", "format.json"), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def banner_installed():
    """The install date for the banner: Local Data's format.json when this version was installed there, else today
    (a first launch, or the first launch of a new version)."""
    f = ld_format_plain()
    if f.get("installed_version") == VERSION and f.get("installed_on"):
        return f["installed_on"]
    return now().strftime("%Y-%m-%d")


def known_issues_line(folder=None, quiet=False):
    """Answer 5: the Known issues, in one line with the banner, before the passphrase (BETA.md/CHANGELOG.md are plain)."""
    ki = known_issues(folder)
    if ki is None:
        if not quiet:
            fb("This build has no Known issues section.")
        return "KNOWN_ISSUES: (list missing in this build; say nothing)"
    if not ki or (len(ki) == 1 and ki[0].lower().startswith("none")):
        return "KNOWN_ISSUES: none"
    more = f" · and {len(ki) - 4} more" if len(ki) > 4 else ""
    return "KNOWN_ISSUES (one short line; offer details or get started): " + " · ".join(ki[:4]) + more


def cmd_banner(args):
    """Banner and disclaimer (Startup 3), before the passphrase: the banner, then the Known issues line."""
    print(banner_text(args.installed or banner_installed()))
    print(known_issues_line(args.docs))
    for f in FEEDBACK:
        print("FEEDBACK: " + f)


SKILL_NAME = "CinciPEM ShiftMate"                 # {name} in the notes (plan 1.1)
SKILL_LINK = "github.com/patricksd91/CinciPEMHub"  # {link}: the skill's GitHub address (public, not sensitive)
NOTES = [   # plan 5.1: the 23 versions of the skill note Patrick kept (9/26); one is picked for each email
    "Drafted with {name}, a free Claude skill that finds shift trades for you and more. Get started: {link}",
    "Found with {name}, a free Claude skill for finding shift trades and more. Try it: {link}",
    "This trade request was put together by {name}, a free Claude skill. Learn more: {link}",
    "Sent via {name}, a free Claude skill that finds shifts you can trade into and more. Get it: {link}",
    "This request came from {name}, a free Claude skill for CinciPEM shift trades and more: {link}",
    "Made with {name}, a free Claude skill for the CCHMC Division of Emergency Medicine. {link}",
    "Looking for a trade yourself? {name} can help: {link}",
    "This trade was found in a few seconds with {name}. It's free: {link}",
    "This trade was matched by {name}, a free Claude skill that checks availability and finds trades, plus more. {link}",
    "Drafted by {name}. Want help with your own trades? {link}",
    "Need to trade a shift? {name}, a free Claude skill, finds options that work for you: {link}",
    "Trade options found with {name}, free for CinciPEM staff: {link}",
    "{name} helped write this. It's a free Claude skill for finding shift trades and more: {link}",
    "Sent with help from {name}. It's free for division staff: {link}",
    "Searching for trades by hand? {name} does it for you, free: {link}",
    "Trade suggestion from {name}, a free Claude skill built for CinciPEM. {link}",
    "Trade request prepared with {name}, a free Claude skill. Getting started takes about 5 minutes: {link}",
    "This trade was found by {name}, a free Claude skill that checks every colleague's schedule for you. {link}",
    "Written with {name}. Try it the next time you need to trade a shift: {link}",
    "Matched with {name}, a free Claude skill that only suggests trades that work for you. {link}",
    "{name} put this request together. It's free for the division and runs in Claude: {link}",
    "Found with {name}. Next time you need a trade, it can search for you: {link}",
    "Trade found and drafted with {name}, a free Claude skill. More at {link}",
]
LINK_LIMIT = 2000


def pick_note(m):
    """5.1: one of the NOTES for this email, as it goes after the signature: a truly random pick (SystemRandom). Tests
    set SHIFTSWAP_NOTE_SEED so the pick is repeatable there (seeded by the seed and the email)."""
    import random
    seed = os.environ.get("SHIFTSWAP_NOTE_SEED")
    if seed is not None:
        key = json.dumps([seed, m.get("to"), m.get("cc"), m.get("subject"), m.get("body")], sort_keys=True)
        note = random.Random(hashlib.sha256(key.encode()).hexdigest()).choice(NOTES)
    else:
        note = random.SystemRandom().choice(NOTES)
    return "\n\n\u2014\u2014\n" + note.format(name=SKILL_NAME, link=SKILL_LINK)


def cmd_outlook(args):
    """Open-in-Outlook links. The skill note (one of NOTES, 5.1) goes at the very end of every Outlook draft (after the
    signature) unless the user asked to leave it off ("ad": false). The copy-paste versions Claude shows never carry
    it, except when a link would be too long: then there's no link at all (no split links, 5.1), and the copy-paste
    text (with the note) is printed instead. When only the note makes it too long, the note is dropped."""
    req = load_req(args.req)
    msgs = req.get("messages", [])
    if not msgs:
        print("ERROR: the request needs \"messages\": [{\"to\": [...], \"subject\": ..., \"body\": ...}]")
        sys.exit(2)
    q = lambda s: urllib.parse.quote(s, safe="")
    for i, m in enumerate(msgs, 1):
        ad = pick_note(m) if req.get("ad", True) else ""
        to = m.get("to", [])
        to = [to] if isinstance(to, str) else to
        text = m.get("body", "").rstrip()
        cc = m.get("cc", [])
        cc = [cc] if isinstance(cc, str) else cc
        url = lambda rcpt, note: ("https://outlook.office.com/mail/deeplink/compose?to="
                                  + urllib.parse.quote(",".join(rcpt), safe="@,")
                                  + ("&cc=" + urllib.parse.quote(",".join(cc), safe="@,") if cc else "")
                                  + "&subject=" + q(m.get("subject", "")) + "&body=" + q(text + note))
        label = m.get("label") or ", ".join(to)
        if len(url(to, ad)) <= LINK_LIMIT:
            print(f"LINK {i} ({label}): {url(to, ad)}")
            continue
        if ad and len(url(to, "")) <= LINK_LIMIT:
            print(f"NOTE_DROPPED_FOR_LENGTH {i}: the skill note was left off so the link fits; say nothing about it.")
            print(f"LINK {i} ({label}): {url(to, '')}")
            continue
        body = text + ad
        print(f"TOO_LONG {i} ({label}): the link would be {len(url(to, ad))} characters, over Outlook's {LINK_LIMIT}. "
              "Tell the user a direct link won't work for this one; give only the text below (don't repeat the draft):")
        print(f"COPY_TEXT {i} START\nTo: {'; '.join(to)}" + (f"\nCc: {'; '.join(cc)}" if cc else "")
              + f"\nSubject: {m.get('subject', '')}\n\n{body}\nCOPY_TEXT {i} END")
    print_feedback()


def parse_changelog(path):
    """{version: (heading, text)} from '## <version> — <date>' sections."""
    out = {}
    if not os.path.exists(path):
        return out
    parts = re.split(r"(?m)^## ", open(path, encoding="utf-8").read())
    for part in parts[1:]:
        head, _, body = part.partition("\n")
        m = re.match(r"(\d+\.\d+\.\d+)", head.strip())
        if m:
            out[m.group(1)] = (head.strip(), body.strip())
    return out


def whatsnew_lines(frm, to, channel, folder=None):
    folder = folder or SKILL_DIR
    stable = parse_changelog(os.path.join(folder, "CHANGELOG.md"))
    beta = parse_changelog(os.path.join(folder, "BETA.md"))
    entries = dict(stable)
    if channel in ("beta", "alpha"):   # alphas' notes live in BETA.md too (plan 7.3)
        entries.update(beta)
    lo, hi = vkey(frm), vkey(to)
    out = []
    if hi >= lo:
        pick = sorted((v for v in entries if lo < vkey(v) <= hi), key=vkey, reverse=True)
        out.append(f"WHATSNEW: {len(pick)} version(s) between {frm} and {to} ({channel})")
        for v in pick:
            out.append(f"\n### {entries[v][0]}\n{entries[v][1]}")
    else:  # going back, e.g. from a beta to the latest stable
        gone = sorted((v for v in beta if hi < vkey(v) <= lo), key=vkey, reverse=True)
        out.append(f"DOWNGRADE: from {frm} back to {to}. Beta changes no longer included: {len(gone)} version(s)")
        for v in gone:
            out.append(f"\n### {beta[v][0]}\n{beta[v][1]}")
    return out


def cmd_whatsnew(args):
    print("\n".join(whatsnew_lines(args.frm, args.to or VERSION, args.channel, args.folder)))
    print_feedback()


def known_issues(folder=None):
    """Bullets of the '## Known issues' section of BETA.md (beta builds) or CHANGELOG.md (stable releases)."""
    path = os.path.join(folder or SKILL_DIR, "CHANGELOG.md" if CHANNEL == "stable" else "BETA.md")
    if not os.path.exists(path):
        return None
    m = re.search(r"(?ms)^## Known issues[^\n]*\n(.*?)(?=^## |\Z)", open(path, encoding="utf-8").read())
    if not m:
        return None
    return [l[2:].strip() for l in m.group(1).splitlines() if l.startswith("- ")]


def fetch(src, timeout):
    """Bytes from an https URL or, for tests, a local path."""
    if re.match(r"https?://", src):
        req = urllib.request.Request(src, headers={"User-Agent": "cincipem-shiftmate"})
        return urllib.request.urlopen(req, timeout=timeout).read()
    return open(src, "rb").read()


def read_manifest_published(src, timeout=5):
    """(manifest dict, None) or (None, 'not published' | reason)."""
    try:
        return json.loads(fetch(src, timeout)), None
    except urllib.error.HTTPError as e:
        return None, ("not published" if e.code == 404 else f"http {e.code}")
    except FileNotFoundError:
        return None, "not published"
    except Exception as e:
        return None, net_problem(e)


def remote_notes(src, frm, to, channel):
    """Release notes for an offered update, from the CHANGELOG.md and BETA.md published beside versions.json."""
    base = src.rsplit("/", 1)[0] + "/"
    folder = os.path.join(WORK, "remote_notes")
    os.makedirs(folder, exist_ok=True)
    got = 0
    for fn in ("CHANGELOG.md", "BETA.md"):
        try:
            open(os.path.join(folder, fn), "wb").write(fetch(base + fn, 5))
            got += 1
        except Exception:
            if os.path.exists(os.path.join(folder, fn)):
                os.remove(os.path.join(folder, fn))
    lines = whatsnew_lines(frm, to, channel, folder) if got else []
    if len(lines) < 2:
        return ["NOTES_UNAVAILABLE: the release notes for this version couldn't be loaded. Say so in one line and give the download "
                "page link (README) so they can read them there."]
    return lines


def update_decision(man, installed, program, last_asked="", never_ask=False, alpha_ok=False):
    """What to offer, from the published versions. Returns (marker, version or '', channel or '').
    Beta-program members get the newest version of either kind; everyone else only newer stables; people who left the
    beta are asked once about a newer beta they haven't been asked about. Alphas (plan 7.3) are offered only to
    alpha-enrolled users, the maintainer, and anyone who asks to check for one (alpha_ok)."""
    inst = vkey(installed)
    stable = (man.get("stable") or {}).get("version")
    beta = (man.get("beta") or {}).get("version")
    alpha = (man.get("alpha") or {}).get("version")
    newer = lambda v: v and vkey(v) > inst
    if program == "alpha" or alpha_ok:
        best = max((v for v in (stable, beta, alpha) if newer(v)), key=vkey, default=None)
        if best:
            return "UPDATE_OFFER", best, ("alpha" if best == alpha else channel_of(best))
        return "UPDATE_NONE", "", ""
    if program == "in":
        best = max((v for v in (stable, beta) if newer(v)), key=vkey, default=None)
        if best:
            return "UPDATE_OFFER", best, channel_of(best)
        return "UPDATE_NONE", "", ""
    if newer(stable):
        return "UPDATE_OFFER", stable, "stable"
    if program == "opted out" and newer(beta) and not never_ask and (not last_asked or vkey(beta) > vkey(last_asked)):
        return "BETA_ASK_ONCE", beta, "beta"
    return "UPDATE_NONE", "", ""


def cmd_update(args):
    src = args.manifest or PUBLIC_REPO + "versions.json"
    base = src.rsplit("/", 1)[0] + "/"
    man, why = read_manifest_published(src)
    if man is None:
        if why == "not published":
            print("UPDATE_NOT_PUBLISHED: nothing has been published yet, so there's nothing to update to. Not a problem; "
                  "log it quietly in system health.")
            sys.exit(0)
        print(f"CHECK_FAILED: couldn't read the published versions ({why}). "
              "Give the manual download steps (see SKILL.md, Updates).")
        sys.exit(6)
    if args.check:
        program = args.beta_program or {"beta": "in", "alpha": "alpha"}.get(channel_of(args.installed), "never joined")
        print(f"UPDATE_CHECK: installed {args.installed} ({channel_of(args.installed)}); beta program: {program}")
        for ch in ("stable", "beta") + (("alpha",) if man.get("alpha") else ()):
            info = man.get(ch)
            if not info:
                print(f"{ch.upper()}: none published")
                continue
            rel = "newer" if vkey(info["version"]) > vkey(args.installed) else (
                "same" if vkey(info["version"]) == vkey(args.installed) else "older")
            print(f"{ch.upper()}: {info['version']} ({info.get('date', '?')}) {rel}")
        mk, v, ch = update_decision(man, args.installed, program, args.last_beta_asked or "", args.never_ask_beta,
                                    args.alpha or is_maintainer(args.name))
        print(f"{mk}{reads('workflows/updates/main.md')}: {v} ({ch})" if v else f"{mk}: you're on the newest version you'd be offered.")
        if v:
            print("\n".join(remote_notes(src, args.installed, v, ch)))
        print_feedback()
        return
    ch = args.download
    info = man.get(ch)
    if not info:
        print(f"ERROR: no {ch} version is published.")
        sys.exit(2)
    try:
        blob = fetch(base + info["zip"], 60)
    except Exception as e:
        print(f"DOWNLOAD_FAILED: {type(e).__name__}. Give the manual download steps (see SKILL.md, Updates).")
        sys.exit(6)
    if info.get("sha256") and hashlib.sha256(blob).hexdigest() != info["sha256"]:
        print("DOWNLOAD_FAILED: the file didn't match its checksum. Give the manual download steps.")
        sys.exit(6)
    try:
        z = zipfile.ZipFile(io.BytesIO(blob))
        names = set(z.namelist())
        skill = z.read("cincipem-shiftmate/SKILL.md").decode("utf-8")
        ok = "cincipem-shiftmate/secure.bin" in names and f'version: "{info["version"]}"' in skill
    except Exception:
        ok = False
    if not ok:
        print("DOWNLOAD_FAILED: the downloaded file isn't a complete copy of the skill. Give the manual download steps.")
        sys.exit(6)
    out = args.out or WORK
    os.makedirs(out, exist_ok=True)
    path = os.path.join(out, f"cincipem-shiftmate-{info['version']}.skill")
    open(path, "wb").write(blob)
    print(f"DOWNLOADED: {info['version']} ({ch}) -> {path}")
    if ch == "alpha":
        print("ALPHA_ENROLLED" + reads(NEW_VERSION) + ": installing an alpha makes them alpha-enrolled: the same "
              "workflows and testing program as the beta, called alpha. Save 'beta program: alpha'.")
    elif ch == "beta" and args.join != "no":
        print("BETA_JOINED: installing a beta opts the user into the beta program; save 'beta program: in'.")
    elif ch == "beta":
        print("BETA_NOT_JOINED: installing this beta once; keep 'beta program' as it is.")
    print("INSTALL: share this .skill file with the user so they can click Save skill; "
          "if no button appears, give the manual upload steps.")
    print_feedback()


# ---------------------------------------------------------------- startup checklist
PROFILE_FIELDS = ("name", "credentials", "role", "cell", "email", "contact_pref")


def roster_profile(p):
    return {"name": getattr(p, "preferred_name", "") or p.name, "credentials": getattr(p, "credentials", ""), "role": role_label(p),
            "cell": getattr(p, "cell", ""), "email": getattr(p, "email", ""), "contact_pref": getattr(p, "contact_pref", "")}


def same(a, b, field):
    if field == "cell":
        return re.sub(r"\D", "", a or "")[-10:] == re.sub(r"\D", "", b or "")[-10:]
    return nkey(a or "") == nkey(b or "")


def thank_you(folder, roster_name):
    """(group sections, personal note) from thankyou.md, shipped encrypted with each stable release."""
    for base in (folder, os.path.dirname(DATA) if RELEASE else None, SKILL_DIR):
        path = os.path.join(base, "thankyou.md") if base else None
        if path and os.path.exists(path):
            txt = open(path, encoding="utf-8").read()
            break
    else:
        return [], ""
    groups, personal = [], ""
    for part in re.split(r"(?m)^## ", txt)[1:]:
        head, _, body = part.partition("\n")
        if head.strip().lower().startswith("personal notes"):
            for sub in re.split(r"(?m)^### ", body)[1:]:
                who, _, note = sub.partition("\n")
                if nkey(who) == nkey(roster_name or ""):
                    personal = note.strip()
        elif body.strip():
            groups.append((head.strip(), body.strip()))
    return groups, personal


def load_state(spec):
    if not spec:
        return ld_state() if LD_ROOT else {}
    try:
        return json.loads(open(spec, encoding="utf-8").read() if os.path.exists(spec) else spec)
    except (ValueError, OSError) as e:
        print(f"ERROR: --state must be JSON: {e}")
        sys.exit(2)


# Which workflows each user is offered (plan 2.3, 2.4). state: "everyone" or "beta"; everyone_since: the version a
# feature left the beta (users not in the beta are told once, at the first launch of that version or later).
WORKFLOW_STATES = [   # (key, name, state, everyone_since); keep in step with the Features table in SKILL.md
    ("swap", "Trade Shifts", "everyone", ""),
    ("locswitch", "Swap Locations", "beta", ""),
    ("mlpickup", "Pickup Moonlighting", "beta", ""),
]
COMING_SOON = {   # key -> (name, what it will do, who sees it: "admin" or "beta and admin")
    "schedule-inquiry": ("Schedule Inquiry and Planning", "answer questions about the schedule, list shifts that meet "
                         "your criteria, show what a change would do, and propose and check swaps or changes with you",
                         "admin"),
    "call-off-helper": ("Call Off Helper", "find someone to take a shift at the last minute (for administrators: find a "
                        "way to readjust the schedule when someone calls off)", "beta and admin"),
}


def enrolled(program):
    """Beta- and alpha-enrolled users get the same workflows and testing program (plan 2.3, 7.3)."""
    return program in ("in", "alpha")


def offered_workflows(help_level, program, mode="clinician", maint=False):
    """(offered, offer to join the beta, listed as coming with no offer, coming soon keys), per plan 2.3. A maintainer
    in the clinician role is offered every workflow that exists (answer 19); coming-soon ones stay coming soon."""
    names = {k: n for k, n, _, _ in WORKFLOW_STATES}
    if maint and mode != "administrator":
        return ([n for _, n, _, _ in WORKFLOW_STATES], [], [], [k for k, v in COMING_SOON.items() if "beta" in v[2]])
    open_ = [k for k, _, s, _ in WORKFLOW_STATES if s == "everyone"]
    beta = [k for k, _, s, _ in WORKFLOW_STATES if s == "beta"]
    if mode == "administrator":   # TS and SL for a clinician; never Pickup Moonlighting (needs their own download)
        return ([names[k] + " (for a clinician)" for k in ("swap", "locswitch")], [], [],
                [k for k, v in COMING_SOON.items() if "admin" in v[2]])
    if help_level.startswith("walk"):
        return [names[k] for k in open_], [], [names[k] for k in beta], []
    if not enrolled(program):
        return [names[k] for k in open_], [names[k] for k in beta], [], []
    return ([names[k] for k in open_ + beta], [], [], [k for k, v in COMING_SOON.items() if "beta" in v[2]])


def workflows_line(help_level, program, mode="clinician", maint=False):
    offer, join, coming, soon = offered_workflows(help_level, program, mode, maint)
    bits = ["offer: " + ", ".join(offer)]
    if join:
        bits.append("shown as \"in the beta, want to join?\": " + ", ".join(join))
    if coming:
        bits.append("listed as coming (no beta offer): " + ", ".join(coming))
    if soon:
        bits.append("coming soon (if picked, run `comingsoon --workflow <key>`): "
                    + ", ".join(f"{COMING_SOON[k][0]} [{k}]" for k in soon))
    return ("WORKFLOWS (Which workflow" + (", Administrator 3" if mode == "administrator" else "") + "): "
            + " | ".join(bits) + ". A workflow not offered here isn't run, even when asked for by name: say it's in "
            "the beta (standard and advanced users: offer to join) or coming." + choices_hint(len(offer) + len(join) + len(soon)))


def coming_what(key, admin=False):
    """C3:98: what a coming-soon workflow will do, for this reader: an administrator hears the administrator wording
    only, a clinician never hears the "(for administrators: ...)" aside."""
    what = COMING_SOON[key][1]
    m = re.search(r"\s*\(for administrators: (.*)\)$", what)
    return (m.group(1) if admin else what[:m.start()]) if m else what


def cmd_comingsoon(args):
    """A coming-soon workflow was picked (plan 2.4): the placeholder text, and a usage line so demand is counted.
    --ask (C3:97): they only asked what it is; the same answer, not counted as demand."""
    name, _, _ = COMING_SOON[args.workflow]
    what = coming_what(args.workflow, args.admin)
    if args.ask:
        print(f"COMING_SOON_INFO{reads('workflows/coming-soon/' + args.workflow + '.md')}: say \"{name} is coming soon. "
              f"It will {what}.\" (a question, not a pick: not counted as demand). Then go back to the question you "
              "were on.")
        print_feedback()
        return
    print(f"COMING_SOON{reads('workflows/coming-soon/' + args.workflow + '.md')}: say \"{name} is coming soon. It will "
          f"{what}.\" In the same message, ask the workflow menu question again (one question: the menu is it).")
    print(f"USAGE: coming-soon {args.workflow} picked")   # always collected (8.3); only sending can be turned off
    print_feedback()


def now_available(installed, program):
    """Features that left the beta since the installed version, for users who weren't in it (plan 2.3)."""
    if not installed or enrolled(program):
        return []
    return [n for _, n, s, v in WORKFLOW_STATES if s == "everyone" and v and vkey(installed) < vkey(v) <= vkey(VERSION)]


def intro_text(name, role, help_level, program, mode, maint=False, role_unknown=False, after_setup=False):
    """The intro, from the script only (plan 2.5, 9.3), so it can't be guessed or shortened. role_unknown: a
    clinician-administrator before the role question (C3:21), so both roles are described. after_setup: the line after
    first-run setup (the detailed intro was at the name match, so no "Welcome back" and no second closing line)."""
    offer = offered_workflows(help_level, program, "clinician" if role_unknown else mode, maint)[0]
    what = {"Trade Shifts": "find colleagues who can take your shift and shifts they could give back",
            "Swap Locations": "move a shift to a site you prefer",
            "Pickup Moonlighting": "find open moonlighting shifts you can actually pick up"}
    can = [what[n] for n in offer if n in what]
    admin = "find trades and same-day site swaps for the clinicians you help"
    if mode == "administrator" and not role_unknown:
        can = [admin]
    both = lambda xs: ", ".join(xs[:-1]) + " and " + xs[-1] if len(xs) > 1 else xs[0]
    if after_setup:
        hello = f"You're all set, {name}." if name else "You're all set."
    else:
        hello = f"Welcome back, {name}" + (f" ({role})" if role else "") + "." if name else "Welcome back."
    body = (f" As a clinician I can {both(can)}; as an administrator I can {admin}." if role_unknown
            else " I can " + both(can) + ".")
    if after_setup:
        return hello + body
    return (hello + body + " Please tell me whenever something doesn't look right, and I'll try to fix it and submit "
            "a bug report or correction request.")


def clinician_admin(me):
    """A roster clinician who is also an administrator (admins.csv staff_row, plan 2.2)."""
    return bool(me) and not getattr(me, "is_admin", False) and \
        nkey(me.name) in {nkey(a.staff_row) for a in load_admins() if getattr(a, "staff_row", "")}


# 2.11 demo mode: default settings, nothing saved, every usage line marked demo. The shipped sample calendar (the newest
# real ShiftAdmin calendar at packaging) is demo/calendar.bin, readable only with the demo key (passphrase + DEMO_LABEL);
# it's decrypted only into the script's temp work area (demo-temp/) and deleted by `demo --end`.
DEMO_DIR = os.path.join(WORK, "demo-temp")
DEMO_ACTIVE = os.path.join(DEMO_DIR, "active")
DEMO_FEED = os.path.join(DEMO_DIR, "feed.ics")
DEMO_BIN = os.path.join(SKILL_DIR, "demo", "calendar.bin")
DEMO_LABEL, DEMO_MAGIC, DEMO_STALE_H = " demo calendar", b"CPDEMO2\n", 12
DEMO_DROP = ("time_order", "pref_order", "site_order", "blocks", "vacations", "work_on_vacation", "role_override",
             "back_to_back")
DEMO_SAY = ("This is a demo. I'll use default settings and skip the setup questions, then take you straight to finding "
            "a shift trade. Nothing you do here is saved.")


def demo_active():
    try:
        return (datetime.now().timestamp() - os.path.getmtime(DEMO_ACTIVE)) < DEMO_STALE_H * 3600
    except OSError:
        return False


def demo_begin():
    os.makedirs(DEMO_DIR, mode=0o700, exist_ok=True)
    open(DEMO_ACTIVE, "w", encoding="utf-8").write(now().isoformat())


def demo_lines(help_note=True):
    """The DEMO marker and the defaults (Demo 2 and 3)."""
    return [f"DEMO{reads('workflows/startup/demo.md')} (Demo or test mode, Startup 9): say, word for word: \"{DEMO_SAY}\" "
            "Save nothing while the demo runs (no SAVE lines are printed; don't change Local Data or memory yourself either).",
            "DEMO_DEFAULTS: Standard help (switch to advanced only if they ask; never offer it); About you and role as the "
            "roster has them; the default shift-time order and no location preference; no blocked dates; back-to-back "
            "off; no allowed-websites offer. Search commands apply these themselves.",
            "NEXT: `demo --schedule` (the live schedule, else the archived copy), then The shift (Trade Shifts 2) for "
            "themselves. At the end of the wrap-up (or on close), run `demo --end`."]


class _DemoOut:
    """While a demo runs: drop SAVE lines (nothing is saved) and mark every USAGE line 'demo'. The name-check and
    passphrase try counts are still saved, so a demo can't get round their lockouts."""
    def __init__(self, out):
        self.out, self.buf = out, ""

    def write(self, x):
        self.buf += x
        *lines, self.buf = self.buf.split("\n")
        for ln in lines:
            if not ln.startswith("SAVE:") or ln.startswith(("SAVE: name tries", "SAVE: passphrase")):
                self.out.write(re.sub(r"^(USAGE\w*): ", r"\1: demo | ", ln) + "\n")
        return len(x)

    def flush(self):
        if self.buf:
            self.write("\n")
        self.out.flush()


def published(txt):
    """When ShiftAdmin made a calendar: its newest DTSTAMP, as an Eastern date."""
    st = re.findall(r"^DTSTAMP:(\d{8}T\d{6})Z", txt, re.M)
    return datetime.strptime(max(st), "%Y%m%dT%H%M%S").replace(tzinfo=timezone.utc).astimezone(ET).date() if st else None


def demo_sample(args):
    """The shipped sample calendar, decrypted (or --sample, a plain calendar, for tests). -> text or None (said why)."""
    if args.sample:
        return open(args.sample, encoding="utf-8", errors="replace").read()
    if not os.path.exists(DEMO_BIN):
        print("DEMO_NO_SAMPLE: this copy has no archived schedule (development copies don't). Say the demo needs the "
              "schedule site this time, and offer to end the demo.")
        return None
    pw = args.passphrase or os.environ.get("SHIFTSWAP_PASSPHRASE", "")
    if args.stdin:
        pw = sys.stdin.readline().strip()
    if not pw:
        print("DEMO_NEEDS_PASSPHRASE: the archived schedule opens only with the skill passphrase: run `demo --schedule "
              "--stdin` again with it on standard input (never echo it).")
        return None
    sys.path.insert(0, HERE)
    import hmac, zlib, securebundle as sb
    blob = open(DEMO_BIN, "rb").read()
    i = len(DEMO_MAGIC)
    head, body, tag = blob[:i + 33], blob[i + 33:-32], blob[-32:]
    if blob.startswith(DEMO_MAGIC):
        ek, mk = sb._keys(pw + DEMO_LABEL, blob[i + 1:i + 17], blob[i])
        if hmac.compare_digest(tag, hmac.new(mk, head + body, hashlib.sha256).digest()):
            return zlib.decompress(sb._ctr(ek, blob[i + 17:i + 33], body)).decode("utf-8", "replace")
    print("DEMO_NO_SAMPLE: the archived schedule didn't open with that passphrase. Say the demo needs the schedule site "
          "this time, and offer to end the demo.")
    return None


def cmd_demo(args):
    """Demo 4 (schedule) and the end of a demo."""
    if args.end:
        shutil.rmtree(DEMO_DIR, ignore_errors=True)
        print("DEMO_ENDED: the demo's temporary files are deleted; nothing was saved.")
        return
    demo_begin()
    if getattr(args, "ics", None):   # C4#4: the calendar file they attached is the demo's schedule
        shifts, src = load_feed(ics=args.ics, quiet=True)
        fd = os.open(DEMO_FEED, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(open(args.ics, encoding="utf-8", errors="replace").read())
        print("DEMO_SCHEDULE: the calendar file they attached.")
        print(f"Feed: {src}; {len(shifts)} shifts, {min(s.start for s in shifts):%m/%d/%y}-"
              f"{max(s.start for s in shifts):%m/%d/%y}.")
        print_feedback()
        return
    shifts, src = (None, "rejected") if args.live == "none" else load_feed(links=args.links, quiet=True, fail_ok=True)
    txt = None
    if shifts is not None and src.startswith("older cached"):
        txt = open(os.path.join(WORK, "feed.ics"), encoding="utf-8").read()
    elif shifts is None:
        txt = demo_sample(args)
        if txt is None:
            print_feedback()
            sys.exit(3)
        fd = os.open(DEMO_FEED, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(txt)
        load_holidays()
        shifts, src = parse_ics(txt), "archived copy (demo)"
    if txt is None:
        print("DEMO_SCHEDULE: the live ShiftAdmin schedule.")
    else:
        pub = published(txt)
        print("DEMO_ARCHIVED: say, word for word: \"Because this is a demo, I'm using an archived copy of the schedule, "
              f"published {short_date(pub.isoformat()) if pub else 'on an unknown date'}. It may be out of date.\" Don't "
              "walk them through allowed websites.")
    print(f"Feed: {src}; {len(shifts)} shifts, {min(s.start for s in shifts):%m/%d/%y}-"
          f"{max(s.start for s in shifts):%m/%d/%y}.")
    print_feedback()


TEST_MODE_DAYS = 7   # 2.9: a build's testing program is offered for 7 days after it was built


def test_mode_lines(program, rn, newer, asked):
    """2.9/9.12, Demo or test mode (Startup 9): offer this build's testing program to beta- and alpha-enrolled users on
    a beta or alpha build under 7 days old with no newer version available (the maintainer always); otherwise, only if
    they asked, say testing has closed. newer: True when a newer version is available (offered or snoozed)."""
    age = (now().date() - date.fromisoformat(BUILD_DATE)).days
    why = [w for w, bad in ((f"this is a {CHANNEL} build", CHANNEL == "stable"),
                            ("they aren't in the beta or alpha", not enrolled(program)),
                            (f"the build is {age} days old", age >= TEST_MODE_DAYS),
                            ("a newer version is available", newer)) if bad]
    if why and not is_maintainer(rn):
        return ([f"TEST_MODE_CLOSED{reads('workflows/startup/test-mode.md')}: say in one line: \"Testing for this version "
                 f"has closed.\" (why, for the log only: {'; '.join(why)})"] if asked else [])
    if asked:
        return [f"TEST_MODE{reads('workflows/startup/test-mode.md')} (Demo or test mode, Startup 9): they asked for it: "
                f"start this build's testing program ({VERSION} {CHANNEL}) now, at Start (Test mode 1)."]
    return [f"TEST_MODE{reads('workflows/startup/test-mode.md')} (Demo or test mode, Startup 9): ask \"Would you like to "
            f"run this build's testing program?\" [Start test mode] [Not now]. Not now: go on with startup."]


def cmd_testmode(args):
    """'start test mode' typed after startup: the same check as at Startup 9 (with its own update check)."""
    if args.start or args.clean_set is not None or args.cont or args.end or args.status:
        return cmd_testmode_ops(args)
    st = load_state(args.state)
    prof = st.get("profile") or {}
    program = (st.get("beta_program") or "never joined").lower()
    man, _ = read_manifest_published(args.manifest or PUBLIC_REPO + "versions.json")
    newer = bool(man) and update_decision(man, VERSION, program)[0] != "UPDATE_NONE"
    for x in test_mode_lines(program, prof.get("roster_name") or prof.get("name"), newer, True):
        print(x)
    print_feedback()


STARTUP_DONE = os.path.join(UNLOCKED, ".startup")
MODEL_SELF = ("MODEL_SELF_REPORT: note the model you believe you are for this chat's usage rows, marked self-reported "
              "(`usage --model \"<it>\" --model-source self-reported`).")
NEEDS_STARTUP = {"refresh", "whoami", "shifts", "avail", "swap", "locswitch", "mlpickup", "contacts", "myblocks",
                 "comingsoon", "demo"}


def require_startup(cmd):
    """Plan 9.3: search commands refuse until startup has run in this conversation (released copies; unlock clears it)."""
    if RELEASE and cmd in NEEDS_STARTUP and not os.path.exists(STARTUP_DONE):
        print("STARTUP_FIRST: run `startup` and finish its checklist first (SKILL.md, Startup), then repeat this command. "
              "Whatever the first message asked for is kept for afterwards.")
        sys.exit(4)


HOL_NAMES = ("Holiday day", "Holiday evening", "Holiday overnight")


def split_holiday(ratings):
    """0.01.07 kept one "Holiday" shift-time rating; 0.01.08 has Holiday day, evening and overnight (C2:53). All three
    get the old rating, moved by the smallest step (0.01) only where needed so no two ratings tie (overnight lowest,
    then evening, then day). Takes and returns the saved shape: a dict, or text 'Weekday day 7.00, ..., Holiday 1.00'.
    None when there's no single Holiday rating to split."""
    text = isinstance(ratings, str)
    if text:
        d = {}
        for item in re.split(r"[,;]\s*", ratings):
            m = re.match(r"^\s*(.*?)[\s=:]+(\d+(?:\.\d+)?)\s*$", item)
            if m:
                d[m.group(1).strip()] = m.group(2)
    elif isinstance(ratings, dict):
        d = dict(ratings)
    else:
        return None
    old = next((k for k in d if str(k).strip().lower() in ("holiday", "hol")), None)
    if old is None or any(h in d for h in HOL_NAMES):
        return None
    try:
        v = round(float(d.pop(old)), 2)
    except (TypeError, ValueError):
        return None
    taken = set()
    for x in d.values():
        try:
            taken.add(round(float(x), 2))
        except (TypeError, ValueError):
            pass
    free = [r for r in (round(v + i / 100, 2) for i in range(0, 801)) if r <= 9 and r not in taken][:3]
    if len(free) < 3:   # no room above (near 9.00): go down instead
        free = [r for r in (round(v - i / 100, 2) for i in range(0, 801)) if r >= 1 and r not in taken][:3]
    for name, r in zip(HOL_NAMES[::-1], sorted(free)):   # overnight lowest, day highest
        d[name] = f"{r:.2f}" if text else r
    return ", ".join(f"{k} {x}" for k, x in d.items()) if text else d


NEW_SETTINGS = {   # version -> settings new in it: (Local Data key, the question). Asked on the rerun when not saved.
    "0.01.08": [("back_to_back", "Back-to-back shifts (Setup 7)")],
}


def missing_new_settings(st, installed):
    """Settings a new version added that the saved settings don't have yet (C2:54)."""
    out = []
    for v, items in NEW_SETTINGS.items():
        if vkey(installed) < vkey(v) <= vkey(VERSION):
            out += [q for k, q in items if st.get(k) in (None, "", [], {})]
    return out


def _block_key(b):
    if isinstance(b, dict):
        return json.dumps({k: v for k, v in b.items() if k not in ("label", "except")}, sort_keys=True)
    return re.sub(r"\s+", " ", str(b).strip().lower())


def _block_future(b, today):
    if not isinstance(b, dict):
        return True
    last = b.get("date") or (b.get("range") or [None, None])[-1]
    try:
        return not last or date.fromisoformat(str(last)[:10]) >= today
    except ValueError:
        return True


def blocks_roster_diff(p, saved, today):
    """Answer 4 (Startup 11): (roster items not in the saved blocked dates, saved items not on the roster), future only.
    Reads the roster with roster_blocks(); search-time block handling is unchanged."""
    saved = as_list(saved, keep_str=True)
    if isinstance(saved, str):
        saved = [x for x in re.split(r"[;\n]", saved) if x.strip() and x.strip().lower() not in NONE_WORDS]
    roster = {_block_key(b): b for b in roster_blocks(p)[0] if _block_future(b, today)}
    mine = {_block_key(b): b for b in (saved if isinstance(saved, list) else []) if _block_future(b, today)}
    return [k for k in roster if k not in mine], [k for k in mine if k not in roster]


def block_shared(key, shared):
    """True when a saved block (its _block_key) was already sent in 'blocked dates shared' (the roster may not have
    caught up yet: blocked-date-sharing.md says not to raise it again)."""
    shared = as_list(shared, keep_str=True)
    if shared in (None, "", [], {}):
        return False
    if isinstance(shared, str):
        try:
            shared = json.loads(shared)
        except ValueError:
            pass
    if isinstance(shared, (list, dict)):
        items = shared if isinstance(shared, list) else [shared]
        if key in {_block_key(b) for b in items}:
            return True
        shared = json.dumps(shared)
    try:
        b = json.loads(key)
    except ValueError:
        return key in str(shared).lower()
    d = b.get("date") or (b.get("range") or [""])[0] if isinstance(b, dict) else ""
    return bool(d) and str(d) in str(shared)


def intro_name(prof, me):
    n = str(prof.get("name") or "").strip()
    full = getattr(me, "name", "") or prof.get("roster_name") or ""
    if n and n.lower() != "none" and nkey(n) != nkey(full):
        return n
    pn = getattr(me, "preferred_name", "") if me else ""
    if pn:
        return pn
    full = full or n
    return full.split()[0] if full and full.lower() != "none" else ""


def cmd_startup(args):
    """Everything Claude does at startup, decided here, as an ordered checklist (plan 2.5, 9.3), in the diagrams'
    order: (the banner and Known issues come from `banner`, before the passphrase) the intro (5), version check and
    What's new (7), updates (8), demo or test mode (9), the role question (10), profile, roster and role checks (11),
    then Confirm your settings (Updates 5) on a new version, questions that are due (12), WORKFLOWS and NEXT.
    Clinician-administrators stop at the role question; `startup --role <answer> --rest` prints the rest.
    --after-setup: the end of first-run setup (the intro line, test mode, WORKFLOWS, NEXT). --workflows-only: the
    WORKFLOWS line again (after joining or leaving the beta mid-chat)."""
    st = load_state(args.state)
    t = now()
    rest = bool(getattr(args, "rest", False))
    after = bool(getattr(args, "after_setup", False)) and not rest
    demo = bool(getattr(args, "demo", False)) and not rest and not after   # 2.11: nothing that saves runs first
    wf_only = bool(getattr(args, "workflows_only", False))
    save, save2 = [], []
    out = (lambda *a: None) if rest else print   # the first part is printed once, before the role question
    installed = str(st.get("installed") or "").strip()
    inst_date = st.get("installed_date") or st.get("installed_on") or ""
    installed, d = split_installed(installed)   # '<version> on <date>' or '<version> (<date>)' (fix 3 #3)
    inst_date = d or inst_date
    first = not installed
    fmt = int(st.get("memory_format") or 0)
    help_level = (st.get("help_level") or "").lower()
    program = (st.get("beta_program") or "never joined").lower()
    prof = st.get("profile") or {}
    rn = prof.get("roster_name") or prof.get("name")
    user_model = (st.get("model_source") or "") == "user"
    maint = is_maintainer(rn)
    people = []
    try:
        people, _ = load_roster()
    except OSError:
        pass
    me = None
    if rn:
        hits = find_person(people, rn)
        me = hits[0] if len(hits) == 1 else next((a for a in load_admins() if nkey(a.name) == nkey(rn)), None)
    rp = roster_profile(me) if me else {}
    hello = intro_name(prof, me)   # C1:124: the name people call them, else the first name, never the full roster name
    both = clinician_admin(me)
    last_role = (st.get("last_role") or "clinician").lower()
    mode = (args.role if both else None) or ("administrator" if getattr(me, "is_admin", False) else "clinician")
    if both and not args.role and (after or wf_only):   # the role was asked at setup (ALSO_ADMIN) or earlier this chat
        mode = last_role if last_role in ("clinician", "administrator") else "clinician"
    if wf_only:   # C4:19: refresh WORKFLOWS after joining or leaving the beta or alpha mid-chat; nothing saved
        print(workflows_line(help_level, program, mode, maint))
        print_feedback()
        return
    out("STARTUP: do these in order, one per message, before the task the first message asked for (keep that for "
        "afterwards). Save every SAVE line to memory before the first question.")
    locked = (st.get("locked_until") or "").strip()
    if locked and locked.lower() != "none":
        try:
            until = datetime.fromisoformat(locked).replace(tzinfo=ET)
        except ValueError:
            until = None
        if until and until > t:
            print(f"LOCKED_OUT{reads('workflows/startup/lockout.md')}: setup is locked until {locked} after three names that aren't on the roster. Explain "
                  "kindly and say when they can try again (in their local time, e.g. 'tomorrow at 8:00 pm'). "
                  + ASK_MAINTAINER + " Stop.")
            return
        save.append("locked until: none; name tries: 0")   # a real lock has expired: three fresh tries
    # Memory upgrade: never deferred, even when the first message names a task (plan 9.3)
    if not first and fmt < 4 and not demo:
        steps = ["rewrite every block with the format-4 heading, keeping every value"]
        if "comfortable" in help_level:
            steps.append("help level 'comfortable' becomes 'advanced' (\"I'm an advanced user\")")
            help_level = "advanced"
        steps += ["add 'usage data: on' (it's on by default; tell them once, in one line, and that they can say "
                  "'stop sending usage data' any time)",
                  "add the About-you fields (name people call you, credentials, cell, email, contact preference, role) "
                  "and run the About-you check at this launch",
                  "add 'role confirmed: none', 'profile mismatches: none', 'thank-you seen: none', 'name tries: 0', "
                  "'locked until: none', 'ad: on'",
                  "shift-time order = the old preference order (ratings: 'ask again'); location and shift-time "
                  "ratings: at this launch, on the ratings page (Location and Shift Time Preferences, Setup 6: rate each "
                  "1 to 9, no ranking step), or save 'ask again' if they're busy"]
        out("MEMORY_UPGRADE" + reads("workflows/startup/memory-upgrade.md") + ": do it now, before anything else, "
            "never later: from format %d to 4: %s." % (fmt, "; ".join(steps)))
        save.append("memory format: 4")
    if first and not demo:
        out("FIRST_LAUNCH" + reads("workflows/setup/main.md") + ": no saved settings yet. The banner, disclaimer and "
            "passphrase are done; next the name check and the rest of First run. When setup is done (SETUP_COMPLETE), "
            "run `startup --after-setup` for the rest of startup.")
        if CHANNEL == "beta":
            out("BETA_BUILD" + reads("workflows/setup/main.md") + ": this is a beta. In setup, unless they choose 'walk me through', they're in the beta program "
                "(tell them in one line; don't ask the join question) and save 'beta program: in'. Walk-me-through "
                "users stay 'never joined'.")
        if CHANNEL == "alpha":
            out("ALPHA_BUILD" + reads("workflows/setup/main.md") + ": this is an alpha (an early preview, not an "
                "official beta). In setup, unless they choose 'walk me through', they're alpha-enrolled: the same "
                "workflows and testing program as the beta, called alpha (tell them in one line; don't ask the beta "
                "question) and save 'beta program: alpha'. Walk-me-through users stay 'never joined'.")
    elif not rn and not demo and not after:
        out("SETUP_INCOMPLETE" + reads("workflows/setup/main.md") + ": setup wasn't finished last time. Pick up First "
            "run at the first step with no saved answer (answers already saved are the defaults). When setup is done "
            "(SETUP_COMPLETE), run `startup --after-setup`.")
    just_installed = not first and installed != VERSION and not demo   # a demo leaves the new-version steps for later
    enroll = []   # enrollment notices (Version check, Startup 7): decided before the intro, said after it
    # Other chats and unsent feedback (Startup 6): the `session` command, run by Claude right after the intro.
    # Version check (Startup 7): beta/alpha enrollment, counters, the old Holiday rating, What's new
    walk = help_level.startswith("walk")
    if just_installed and CHANNEL == "beta" and program == "never joined" and not walk:
        enroll.append("BETA_ENROLLED" + reads(NEW_VERSION) + ": they installed a beta, so they're now in the beta program. Tell them in one line, and that "
            "they can say 'leave the beta' any time.")
        save.append("beta program: in")
        program = "in"
    elif just_installed and CHANNEL == "beta" and program == "alpha":   # once on the beta channel, no more alphas
        enroll.append("BETA_ENROLLED" + reads(NEW_VERSION) + ": they installed a beta, so they're now in the beta program "
            "(no longer alpha): alphas aren't offered again unless they ask to check for one. Tell them in one line.")
        save.append("beta program: in")
        program = "in"
    # installing an alpha makes them alpha-enrolled, as on a first launch (C4:13): also a returning user who never
    # joined (but not one who chose to leave: 'opted out' stays, unless they install a new alpha)
    if (CHANNEL == "alpha" and not first and not demo and not walk and program != "alpha"
            and (just_installed or (program == "never joined" and rn))):
        enroll.append("ALPHA_ENROLLED" + reads(NEW_VERSION) + ": they installed an alpha, so they're now alpha-enrolled: the "
            "same workflows and testing program as the beta, called alpha. Tell them in one line, and that they can "
            "say 'leave the alpha' any time.")
        save.append("beta program: alpha")
        program = "alpha"
    # Intro (Startup 5), from the script only. After first-run setup: the short line (the full intro was at the name
    # match). A clinician-administrator hears both roles, since the role question comes later (C3:21).
    if after:
        out("INTRO (Intro, Startup 5, after first-run setup): say this, word for word:\n"
            + intro_text(hello, "", help_level, program, mode, maint,
                         after_setup=True))
    elif not first:
        last = st.get("last_launch")
        try:
            away = (t - datetime.fromisoformat(last).replace(tzinfo=ET)).total_seconds() / 3600 if last else 999
        except ValueError:
            away = 999
        out("INTRO (Intro, Startup 5): say this, word for word"
            + ("; then highlight one feature they haven't used (or used least recently) and offer to tell more or start"
               if away > 24 else "") + ":\n" + intro_text(hello,
                                                          prof.get("role") or rp.get("role", ""), help_level, program,
                                                          mode, maint, role_unknown=both and not args.role))
    for x in enroll:
        out(x)
    if (first and not demo) or just_installed:
        save.append(f"installed: {VERSION} on {t:%Y-%m-%d}; channel: {CHANNEL}")
    if LD_ROOT and not args.state and not demo and not rest:   # answer 5: the banner reads the date before unlocking
        try:
            f = ld_open().read_format()
            want = t.strftime("%Y-%m-%d") if (first or just_installed) else (inst_date or "")
            if want and (f.get("installed_version"), f.get("installed_on")) != (VERSION, want):
                ld_open().write_format(installed_version=VERSION, installed_on=want)
        except (OSError, ValueError):
            pass
    if just_installed:   # 4.8: counters tied to what this version changed restart from zero
        c_lines, c_saves = counter_restarts(st, installed)
        for x in c_lines:
            out(x)
        save += c_saves
    if just_installed:   # C2:53: the old single Holiday rating becomes the three holiday shift times, with no ties
        for k in ("shift_time_ratings", "shift_time_preferences"):
            new = split_holiday(st.get(k))
            if new is not None:
                st[k] = new
                pp = prefs_pairs(times=parse_ratings(new))[0]   # best first, the page's names, and time_order (C2:20)
                save.append("; ".join(f"{a}: {b if isinstance(b, str) else json.dumps(b)}" for a, b in pp))
                out("HOLIDAY_SPLIT" + reads(NEW_VERSION) + ": their one Holiday rating from before now applies to "
                    "Holiday day, evening and overnight (moved by 0.01 where needed so nothing ties). Say so in one "
                    "line with What's new; the ratings page shows these saved ratings to confirm.")
                break
    # Updates and news (Startup 8)
    if not first and installed != VERSION and not demo:
        ch = CHANNEL if CHANNEL != "stable" else ("beta" if enrolled(program) else "stable")   # answer 25: "(alpha)"
        lines = whatsnew_lines(installed, VERSION, ch, args.docs)
        if len(lines) > 1:
            out(f"WHATS_NEW{reads(NEW_VERSION)}: show all of it as \"What's new since {installed}\", in plain words:")
            for line in lines:
                out(line)
        else:
            out(f"WHATS_NEW{reads(NEW_VERSION)}: no release notes between {installed} and {VERSION}; just say they're now on {VERSION}.")
        if CHANNEL == "stable" and program == "alpha":   # plan 7.3 (answer 9/27): a stable install keeps them alpha-enrolled
            out(f"ALPHA_STILL_ENROLLED{reads('workflows/updates/main.md')}: add this one line to What's new, word for word: \"You're "
                "still in the alpha; say 'leave the alpha' to get stable versions only.\"")
        for n in now_available(installed, program):
            out(f"NOW_AVAILABLE{reads(NEW_VERSION)}: one line in What's new, \"Now available to everyone: {n}.\", and "
                "make it the intro highlight.")
        if CHANNEL == "stable" and st.get("thank_you_seen") != VERSION:
            groups, personal = thank_you(args.docs, rn)
            if groups or personal:
                if personal:
                    out("THANK_YOU_PERSONAL" + reads(NEW_VERSION) + " (show first, warmly):\n" + personal)
                for head, body in groups:
                    out(f"THANK_YOU{reads(NEW_VERSION)} ({head}):\n{body}")
                save.append(f"thank-you seen: {VERSION}")
                if (st.get("usage_data") or "on").lower() == "off":
                    out("USAGE_OPT_IN_ASK" + reads(NEW_VERSION) + ": after the thank-yous, politely ask once whether they'd like to share usage "
                        "data (encrypted, only the maintainer can read it, used to fix bugs and improve features; "
                        "with it on, their feedback is sent automatically at the end of each session).")
    snooze = st.get("update_snooze_until")
    src = args.manifest or PUBLIC_REPO + "versions.json"
    newer = False   # a newer version is available (for test mode, Startup 9)
    if rest or after:
        pass   # checked in the first part (after setup: at the first launch's startup)
    elif just_installed or (demo and installed and installed != VERSION):
        out("UPDATE_SKIPPED: they just updated; don't check again this launch.")
    elif snooze and snooze not in ("none", "") and datetime.fromisoformat(snooze).replace(tzinfo=ET) > t:
        out(f"UPDATE_SNOOZED: until {snooze}; don't mention updates.")
        newer = True
    else:
        man, why = read_manifest_published(src)
        if man is None:
            out("UPDATE_NOT_PUBLISHED: nothing published yet; say nothing." if why == "not published" else
                f"UPDATE_CHECK_FAILED ({why}): say nothing now; log it in system health.")
        else:
            # a first launch of a beta build: setup will put them in the beta program (BETA_BUILD), so decide as a member
            prog = {"beta": "in", "alpha": "alpha"}.get(CHANNEL, program) if first else program
            mk, v, ch = update_decision(man, VERSION, prog, st.get("last_beta_asked", ""), bool(st.get("never_ask_beta")),
                                        maint)
            newer = mk != "UPDATE_NONE"
            if mk == "UPDATE_OFFER":
                out(f"UPDATE_OFFER{reads('workflows/updates/main.md')}: {v} ({ch}). Show what's changed (below) and ask whether to update"
                    + (" before setup" if first else "") + ". On no: save 'update snooze until' = 24 hours from now.")
                out("\n".join(remote_notes(src, VERSION, v, ch)))
            elif mk == "BETA_ASK_ONCE":
                out("\n".join(remote_notes(src, VERSION, v, ch)))
                out(f"BETA_ASK_ONCE{reads('workflows/updates/main.md')}: {v}. Show what's changed (above) and ask once (Yes, update this time / Yes, and opt back into the beta program / "
                    "Never ask me again).")
                save.append(f"last beta asked about: {v}")
            else:
                out("UPDATE_NONE: they're up to date; say nothing.")
    # Demo or test mode (Startup 9): the demo takes them out of startup here, with nothing saved (plan 2.11)
    if demo:
        demo_begin()
        if not rn:   # never set up: the name check only
            print(f"DEMO_NAME_CHECK{reads('workflows/startup/demo.md')}: they've never set up, so ask only the name check "
                  "(Name check, Setup 1), then run `whoami --setup --name \"<their name> Demo\"`. No other setup question.")
        else:
            for x in demo_lines():
                print(x)
        if not user_model:
            print(MODEL_SELF)
        if not rn:   # C4:48
            print("NEXT: the name check, then follow the DEMO lines that `whoami --setup` prints.")
        if RELEASE:
            open(STARTUP_DONE, "w", encoding="utf-8").write(t.isoformat())
        print_feedback()
        return
    if (not first or after) and not rest:
        for x in test_mode_lines(program, rn, newer, bool(getattr(args, "test_mode", False))):
            out(x)
    # Role question (Startup 10): clinician-administrators only (plan 2.2); answer 10: last time's role is (default)
    if both and not args.role and not after:   # asked every startup (plan 2.2); after setup, ALSO_ADMIN asked it
        for x in save:
            print("SAVE: " + x)
        print(f"ROLE_QUESTION{reads('workflows/startup/role-question.md')} (Role question, Startup 10): ask \"Which "
              f"role are you working in today?\" [Clinician] [Administrator]; mark [{last_role.capitalize()}] "
              "**(default)** (last time's role). Skip the question only when the first message makes the role very "
              "clear.")
        print("NEXT: after the answer, run `startup --role clinician|administrator --rest`; it "
              "prints the rest of startup. Search commands wait until then.")
        print_feedback()
        return
    if both:
        save2.append(f"last role: {mode}")
    checks = []   # Startup 11 and 12 lines, printed after the rerun count (they're asked after it)
    asks = 0      # questions they bring
    # Profile, roster and role checks (Startup 11); administrator mode skips their own clinical self
    if just_installed:
        whos = ([] if mode == "administrator" and both else [dict(prof, _self=True)]) + list(st.get("clinicians") or [])
        for who in whos:
            p = me if who.get("_self") else None
            if not who.get("_self"):
                hits = find_person(people, who.get("roster_name", ""))
                p = hits[0] if len(hits) == 1 else None
            if p is None:
                continue
            r = roster_profile(p)
            label = "your" if who.get("_self") else f"{p.name}'s"
            counts = dict(who.get("mismatches") or {})
            for f in PROFILE_FIELDS:
                mine = who.get(f)
                if not mine or str(mine).strip().lower() == "none":   # only a value they gave; never a guess (9.7, 002)
                    continue
                if f == "name" and not getattr(p, "preferred_name", ""):
                    # C2:85: no preferred name on the roster: the name people call them is theirs to say (a nickname
                    # isn't a mismatch with the full name)
                    counts.pop(f, None)
                    continue
                if same(mine, r.get(f), f):
                    if counts.pop(f, None):
                        checks.append(f"PROFILE_CAUGHT_UP{reads(NEW_VERSION)}: {label} {f} in the roster now matches what you told me. Thank them; "
                                      "clear the saved override for it (Local Data).")
                    continue
                if not r.get(f):   # a blank roster field isn't a conflict: memory fills it until the roster catches up
                    counts.pop(f, None)
                    continue
                counts[f] = int(counts.get(f, 0)) + 1
                asks += 1
                checks.append(f"PROFILE_DIFF{reads(NEW_VERSION)}: {label} {f}: saved \"{mine}\" vs roster \"{r.get(f)}\". Ask which to keep "
                              "(Keep mine (default) / Use the roster's / Something else). Put the choice in Roster updates.")
                if counts[f] >= 2:
                    fb(f"Roster update for {p.name}'s {f} not applied after {counts[f]} updates (feedback pipeline check).")
                    checks.append(f"PROFILE_STUCK{reads(NEW_VERSION)}: {label} {f} has differed after {counts[f]} updates in a row; this goes in feedback "
                                  "automatically. Tell them: if I keep asking after every update, please mention it in feedback.")
            if counts != {k: int(v) for k, v in (who.get("mismatches") or {}).items()}:
                save2.append(f"profile mismatches ({'you' if who.get('_self') else p.name}): "
                             + (", ".join(f"{k} {v}" for k, v in counts.items()) or "none"))
    # answer 4: blocked dates against the roster, once per chat (search-time block handling is unchanged)
    mark = os.path.join(WORK, ".blocks-roster-checked")
    if (me is not None and not getattr(me, "is_admin", False) and not first and not after and mode == "clinician"
            and (args.state or not os.path.exists(mark))):
        saved_blocks = st.get("blocks") or st.get("my_blocks") or st.get("blocked_dates") or []
        r_only, m_only = blocks_roster_diff(me, saved_blocks, t.date())
        m_only = [k for k in m_only if not block_shared(k, st.get("blocked_dates_shared"))]   # C1:237: shared already
        if m_only and not r_only and st.get("blocks_roster_reported") == VERSION:
            m_only = []   # saved-only items go in Roster updates once per version, not every chat
        elif m_only:
            save2.append(f"blocks roster reported: {VERSION}")
        if r_only or m_only:
            asks += 1 if r_only else 0
            checks.append(f"BLOCKS_ROSTER_DIFF (Profile, roster and role checks, Startup 11): {len(r_only)} blocked-date "
                          f"item(s) on the roster aren't in their saved blocked dates; {len(m_only)} saved item(s) aren't "
                          f"on the roster. Run `myblocks --name \"{me.name}\"` to list them."
                          + (" Ask once whether the roster's items are still right (searches use them either way)."
                             if r_only else "") + " Put any change in Roster updates (their own dates only, never "
                          "what they're for).")
        if not args.state:
            try:
                os.makedirs(WORK, exist_ok=True)
                open(mark, "w", encoding="utf-8").write(t.isoformat())
            except OSError:
                pass
    if not first and not after and not (both and mode == "administrator"):
        rc = st.get("role_confirmed")
        try:
            due = not rc or rc == "none" or date.fromisoformat(rc) < role_check_anchor(t.date())
        except ValueError:
            due = True
        if due:
            asks += 1
            checks.append("ROLE_CHECK_DUE" + reads("workflows/setup/role-check.md") + ": show their role and what it allows and doesn't allow, and ask if it's right. "
                          "Save 'role confirmed' with today's date.")
    # Confirm your settings (Updates 5), after the profile checks so the summary can leave those fields out
    rerun, rerun_base = None, 0
    rerun_text = ("RERUN_SETUP" + reads("workflows/setup/rerun.md", "workflows/setup/main.md") + " (Confirm your "
                  f"settings, Updates 5): new version ({installed} to {VERSION}). \"You're running a new version "
                  f"({VERSION}). Here's what you have saved.\" [Looks right] [Change something] [Start fresh]. Skip the "
                  "name check and anything already done; the intro was already said (INTRO above), so don't repeat it. "
                  "The site and shift-time ratings are always shown to confirm or change, at every help level. Leave "
                  "out of the summary any About-you field a PROFILE_DIFF line asks about. The plan is asked once, at "
                  "PLAN_ASK below (if printed), not inside Looks right.")
    if both and mode == "administrator" and just_installed:
        rerun = rerun_text + (" Administrator mode: confirm only the administrator part; their clinician settings are "
                              "confirmed the next time they start as a clinician.")
        rerun_base = SETUP_QUESTIONS["rerun"] - 1   # no ratings page in administrator mode
    elif both and mode == "clinician" and not after:
        if str(st.get("clinician_setup") or "").lower() == "not done":
            checks.append("CLINICIAN_SETUP_DUE" + reads("workflows/setup/main.md") + ": their first start as a clinician: run "
                          "the clinician part of setup (About You and Role Check (Setup 3), then Location and Shift Time "
                          "Preferences (Setup 6) to Save and check (Setup 9)). Then save 'clinician setup: done'.")
        elif not first and (st.get("clinician_confirmed") or installed) != VERSION:
            rerun = rerun_text + (f" Clinician mode: confirm their clinician settings; then save 'clinician settings "
                                  f"confirmed: {VERSION}'.")
            rerun_base = SETUP_QUESTIONS["rerun-walk" if walk else "rerun"]
    elif just_installed and not both:
        rerun = rerun_text
        rerun_base = SETUP_QUESTIONS["rerun-walk" if walk and mode != "administrator" else "rerun"]
    new_q = missing_new_settings(st, installed) if rerun and mode == "clinician" else []
    if rerun:
        checks.append(rerun)
        asks += rerun_base
    if new_q:
        asks += len(new_q)
        checks.append(f"SETUP_NEW_QUESTIONS{reads('workflows/setup/main.md')} (Confirm your settings, Updates 5): new "
                      f"in {VERSION} and not saved yet: {'; '.join(new_q)}. Ask each right after the confirm question, "
                      "whatever they chose (Looks right included), as in setup.")
    # Questions that are due (Startup 12)
    if not first and not after and not (both and mode == "administrator"):
        ask = st.get("prefs_ask_again") or {}
        for k, lbl in (("sites", "location"), ("times", "shift-time")):
            if ask.get(k):
                checks.append(f"PREFS_ASK_AGAIN{reads('workflows/setup/main.md')}: {lbl} ratings (they asked to be asked "
                              "again). Offer [Rate them now] first, then [Ask me again next startup]; rating is on Location and "
                              "Shift Time Preferences (Setup 6).")
                if not rerun:   # the rerun's ratings page covers it
                    asks += 1
    if not first and not after and not help_level:
        asks += 1
        checks.append("HELP_LEVEL_ASK: ask the help-level question at this launch.")
    # Plan and model (plan 8.3): asked again after each new version, once (C2:20); a named model isn't asked again
    if not first and not after and (not st.get("plan") or (st.get("plan_asked") or st.get("plan_version")) != VERSION):
        asks += 1
        checks.append("PLAN_ASK" + reads("workflows/setup/main.md") + " (Questions that are due, Startup 12): ask \"Which "
                      "Claude plan" + ("" if user_model else " and model") + " are you using?\" as a numbered list: Free, Pro, "
                      "Max, Team, Enterprise, Not sure" + ("" if user_model else "; the model is optional") + f". Save 'plan: "
                      f"<answer>; plan asked: {VERSION}'" + ("" if user_model else " and, if they name one, 'model: <it>; "
                                                             "model source: user'") + ".")
    if rerun:   # C2:32: the count is what this launch really asks, said before the first of these questions
        print(setup_count_text(asks, "rerun", when="before the next question (the first of the ones below)"))
    for x in checks:
        print(x)
    if not user_model and not after:
        print(MODEL_SELF)
    if maint and (not first or after):   # C3:106: the maintainer isn't asked to pass feedback on to himself
        print("MAINTAINER: the primary user is a maintainer (SKILL_SENSITIVE.md): at the wrap-up, don't ask whether to "
              "pass their feedback on to the maintainer; record it as theirs. As a clinician they're offered every "
              "workflow (WORKFLOWS).")
    if not first or after:
        print(workflows_line(help_level, program, mode, maint))
    save2.append(f"last launch: {t:%Y-%m-%d %H:%M}")
    for x in (save2 if rest else save + save2):
        print("SAVE: " + x)
    if first and not after:
        print("NEXT: the name check (`whoami --setup`, Name check (Setup 1)).")
    else:
        print("NEXT: startup is done. Do the task the first message asked for, if any; otherwise ask which workflow "
              "(WORKFLOWS above)" + (" and then Which clinician (Administrator 4) for Trade Shifts or Swap Locations"
                                     if mode == "administrator" else "") + ".")
    if RELEASE:
        open(STARTUP_DONE, "w", encoding="utf-8").write(t.isoformat())
    print_feedback()


def add_more_parsers(sub):
    """Commands added in 0.01.08 (kept apart from the older list in main)."""
    mb = sub.add_parser("myblocks")
    mb.add_argument("--name", required=True, help="roster name (the primary user's own, from whoami)")
    mb.add_argument("--ics", help="attached ShiftAdmin calendar file")
    sv = sub.add_parser("save")   # the user's answers to Local Data (after 4.14 there is no memory to save them in)
    sv.add_argument("text", nargs="?", help="'<key>: <value>; <key>: <value>'")
    sv.add_argument("--key", help="one key, saved with --value exactly as given (a list with '; ' inside stays whole)")
    sv.add_argument("--value", help="the value for --key")
    sv.add_argument("--live", action="store_true", help="test mode only: save to the real (live) settings (double-confirmed override)")
    sv.add_argument("--clinician", help="administrator mode: save to this clinician's own settings, not yours")
    sub.add_parser("settings")    # show my saved settings
    cs = sub.add_parser("comingsoon")
    cs.add_argument("--workflow", required=True, choices=sorted(COMING_SOON))
    uu = sub.add_parser("usual")
    uu.add_argument("--workflow", required=True, choices=sorted(USUAL_WORKFLOWS))
    uu.add_argument("--req", required=True, help="the request of the search just run (with its filter, if narrowed)")
    uu.add_argument("--make-usual", action="store_true", help="they said to make it their usual")
    cs.add_argument("--ask", action="store_true", help="they asked what it is (not a pick): not counted as demand")
    cs.add_argument("--admin", action="store_true", help="administrator mode: the administrator wording")
    su = sub.choices["startup"]
    su.add_argument("--role", choices=["clinician", "administrator"],
                    help="clinician-administrators: the answer to the role question (plan 2.2)")
    su.add_argument("--rest", action="store_true", help="with --role: print only the part after the role question")
    us = sub.add_parser("usage")
    us.add_argument("--workflow", required=True, help="workflow name, e.g. Trade Shifts")
    us.add_argument("--turns", type=int, default=0)
    us.add_argument("--read-chars", type=int, default=0, help="characters Claude read in this workflow (files and output)")
    us.add_argument("--written-chars", type=int, default=0, help="characters Claude wrote in this workflow")
    us.add_argument("--script-ms", type=int, default=0, help="sum of this workflow's USAGE_STEP run times")
    us.add_argument("--model", default="", help="the model: what the user said, or what Claude believes it is")
    us.add_argument("--model-source", choices=["user", "self-reported"], default="self-reported")
    us.add_argument("--plan", default="", help="Free, Pro, Max, Team, Enterprise or Not sure")
    us.add_argument("--limit-hit", default="", help="the step where a usage limit was hit or mentioned")
    us.add_argument("--decrypt-lib", default="", help="cryptography or the bundled fallback")
    us.add_argument("--decrypt-ms", type=int, default=0)
    add_d_parsers(sub)
    dm = sub.add_parser("demo")
    dg = dm.add_mutually_exclusive_group(required=True)
    dg.add_argument("--schedule", action="store_true", help="the demo's schedule: live, else the archived copy (2.11)")
    dg.add_argument("--end", action="store_true", help="end the demo: delete its temporary files")
    dm.add_argument("--links", help="the user's links from memory (as for refresh)")
    dm.add_argument("--ics", help="attached ShiftAdmin calendar file (C4#4: any command takes it)")
    dm.add_argument("--passphrase", help="the skill passphrase, to open the archived copy (or SHIFTSWAP_PASSPHRASE)")
    dm.add_argument("--stdin", action="store_true", help="read the passphrase from standard input")
    dm.add_argument("--live", choices=["try", "none"], default="try", help=argparse.SUPPRESS)   # tests: no download
    dm.add_argument("--sample", help=argparse.SUPPRESS)   # tests: a plain calendar in place of the archived copy
    su.add_argument("--demo", action="store_true", help="they asked for a demo (2.11)")
    su.add_argument("--test-mode", action="store_true", help="they typed 'start test mode' (2.9)")
    su.add_argument("--after-setup", action="store_true",
                    help="first-run setup just finished (SETUP_COMPLETE): the rest of startup (intro line, WORKFLOWS)")
    su.add_argument("--workflows-only", action="store_true",
                    help="print only the WORKFLOWS line again (after joining or leaving the beta or alpha mid-chat)")
    tm = sub.add_parser("testmode")
    tm.add_argument("--state", help=argparse.SUPPRESS)   # tests only: settings JSON instead of Local Data
    tm.add_argument("--manifest", help=argparse.SUPPRESS)   # tests: a local versions.json
    tm.add_argument("--start", action="store_true", help="Test mode 3: back up live/ and switch this chat to testing/")
    tm.add_argument("--clean-set", type=int, help="Test mode 5: empty testing/'s settings for clean set N")
    tm.add_argument("--continue", dest="cont", action="store_true", help="'continue test mode, set N': this chat uses testing/")
    tm.add_argument("--set", type=int, help="with --continue: the set number")
    tm.add_argument("--end", action="store_true", help="Test mode 7: restore live/ from the backup and leave test mode")
    tm.add_argument("--no-restore", action="store_true", help="with --end: don't copy the backup back")
    tm.add_argument("--status", action="store_true", help="is this chat in test mode?")
    pf = sub.add_parser("prefs")   # Location and Shift Time Preferences (Setup 6)
    pg = pf.add_mutually_exclusive_group(required=True)
    pg.add_argument("--line", help="the pasted SHIFTMATE_PREFERENCES line, whole")
    pg.add_argument("--page-data", action="store_true", help="ELIGIBLE and SAVED for the page (roster only)")
    pf.add_argument("--name", help="with --page-data (or --line): the clinician's roster name")
    pf.add_argument("--for-other", action="store_true", help="with --page-data: not the primary user (no SAVED)")
    pf.add_argument("--clinician", help="with --line in administrator mode: save to this clinician's own settings")
    ay = sub.add_parser("aboutyou")   # About You and Role Check (Setup 3)
    ay.add_argument("--line", required=True, help="the pasted SHIFTMATE_ABOUT_ROLE line, whole")
    ay.add_argument("--name", required=True, help="the clinician's roster name (from whoami)")
    for sp in sub.choices.values():   # every command can time itself for the usage data (plan 8.3)
        sp.add_argument("--step", help="the workflow step this run belongs to, e.g. 'Availability (Trade Shifts 3)'")
    upd = sub.choices["update"]
    upd.add_argument("--alpha", action="store_true", help="the user asked to check for an alpha build (plan 7.3)")
    upd.add_argument("--name", help="the primary user's roster name (the maintainer is always offered the newest)")


def step_usage(cmd, step, t0, c0):
    """USAGE_STEP: the script's own share of a step's usage (plan 8.3): run time, processor time and peak memory."""
    import time
    try:
        import resource
        peak = f" | peak {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss} KB"
    except (ImportError, AttributeError):
        peak = ""
    print(f"USAGE_STEP: {step} | command {cmd} | run {round((time.perf_counter() - t0) * 1000)} ms | "
          f"cpu {round((time.process_time() - c0) * 1000)} ms{peak}")


def cmd_usage(args):
    """One Usage data row per workflow run for the feedback file (plan 8.3). Tokens are estimated as characters / 4.
    TODO(4.5): memory in 0.01.08; Local Data in 0.01.09 (rows then collect in its logs folder between sends)."""
    tok = lambda c: f"~{(c + 3) // 4} tokens ({c} chars)"
    model = (args.model or "unknown") + ("" if args.model_source == "user" else " (self-reported)")
    bits = [f"workflow {args.workflow}", f"turns {args.turns}", f"read {tok(args.read_chars)}",
            f"written {tok(args.written_chars)}", f"script {args.script_ms} ms", f"model {model}",
            f"plan {args.plan or 'not asked'}"]
    if args.limit_hit:
        bits.append(f"usage limit hit at {args.limit_hit}")
    if args.decrypt_lib:
        bits.append(f"decrypted with {args.decrypt_lib} in {args.decrypt_ms} ms")
    print("USAGE_ROW: " + " | ".join(bits) + ". Put it in the feedback file's Usage data section (always collected; "
          "sent only when Auto-send usage data and feedback is on).")


USUAL_WORKFLOWS = {"trade-shifts": "trade shifts", "swap-locations": "swap locations",
                   "pickup-moonlighting": "pickup moonlighting"}


def usual_settings(req, eligible_sites=None):
    """Your usual (Trade Shifts 11), fix C1:290 / C2:166: the settings a search actually used, as the usual's fields
    (sites, times, categories, len_up, len_colleague, show). A narrowed wide search ("everything" plus a "filter") gives
    what the narrowing kept. Never saved: dates, blocks, back-to-back, the Jeopardy and holiday answers, the holiday
    shift times that holiday mode turned on, PERI, and anything in "holiday_added" (e.g. category E added only because
    the shift is a holiday)."""
    flt = req.get("filter") or {}
    base = dict(EVERYTHING, **{k: v for k, v in req.items() if v not in (None, "", [])}) if req.get("everything") else req
    added = {str(x).upper() for x in req.get("holiday_added") or []}
    times = [k for k in DEFAULT_ORDER if k in set(expand_hol(base.get("times") or base.get("types")) or
                                                 [c for c in CAT_LABEL if c not in HOL_TIMES])]
    times = [k for k in times if filter_keeps_time(k, flt) and k != "PERI" and k not in added
             and not (req.get("holiday_mode") and k in HOL_TIMES)]
    sites = [x for x in ALL_SITES if x in set(filter(None, (norm_site(y) for y in (base.get("sites") or ALL_SITES))))]
    if flt.get("sites"):
        keep = set(filter(None, (norm_site(y) for y in flt["sites"])))
        sites = [x for x in sites if x in keep]
    if eligible_sites is not None:   # C2#2: only sites the clinician is eligible for
        sites = [x for x in sites if x in eligible_sites]
    cats = sorted(set(base.get("categories") or ["A", "B", "C", "D"]) & set(flt.get("categories") or "ABCDEF") - added)
    out = {"sites": sites, "times": times, "categories": cats}
    for k in ("len_up", "len_colleague"):
        v = float(base.get(k, 0) or 0)
        if k in flt:
            v = min(v, float(flt[k]))
        out[k] = v
    if req.get("show"):
        out["show"] = req["show"]
    return out


def cmd_usual(args):
    """Save a search's settings as the most recent (always) and, with --make-usual, as the usual too; say how they
    differ from the saved usual (Your usual, Trade Shifts 11)."""
    req = load_req(args.req)
    wf = USUAL_WORKFLOWS[args.workflow]
    other = None
    if LD_ROOT and not demo_active():   # C2#2: the settings the search itself used (it filled the same fields)
        other = ld_for_other(req)
        buf, keep = io.StringIO(), sys.stdout
        sys.stdout = buf
        try:
            ld_fill_req(req, USUAL_CMD[args.workflow])
        finally:
            sys.stdout = keep
    elig = None
    if req.get("clinician"):
        try:
            people, _ = load_roster()
            hits = find_person(people, req["clinician"])
        except (OSError, SystemExit):
            hits = []
        if len(hits) == 1:
            el = hits[0].status_on(now().date())[1]
            elig = {x for x in ALL_SITES if FACILITY_LOC(x) in el}
    new = usual_settings(req, elig)
    old = None
    rel = (other + "/" if other else "") + LD_WORKFLOW_FILE_BY_NAME[args.workflow]
    if LD_ROOT:
        cur = ld_open().read(rel, {}) or {}
        old = cur.get("usual") if isinstance(cur, dict) else None
    if isinstance(old, dict):
        try:   # fix 3 #11: a field the saved usual doesn't have (a 0.01.07 usual) is the default, never "null"
            dflt = usual_settings({}, elig)
        except Exception:
            dflt = {}
        was = lambda k: old[k] if old.get(k) is not None else dflt.get(k)
        shown = lambda k: json.dumps(old[k]) if old.get(k) is not None else "(default)"
        diff = [f"{k}: usual {shown(k)} vs this search {json.dumps(new.get(k))}" for k in new
                if was(k) != new.get(k)]
        print("USUAL_SAME: this search used the usual settings." if not diff else
              "USUAL_DIFFERS: " + "; ".join(diff) + ".")
    else:
        print("USUAL_NONE: no usual saved yet.")
    dropped = [x for x in ("holiday_mode", "holiday_added", "jeop_mode", "into", "dates", "blocks", "back_to_back")
               if req.get(x) not in (None, "", [], {})]
    if dropped:
        print("USUAL_LEFT_OUT: not part of a usual: " + ", ".join(dropped) + ".")
    if other:   # someone else's search: their own file, never the primary user's (C3#4)
        def upd(cur):
            cur = dict(cur or {})
            cur["most_recent"] = new
            if args.make_usual:
                cur["usual"] = new
            return cur
        ld_update(rel, upd, {})
        print(f"SAVED: {wf} most recent" + (f", {wf} usual" if args.make_usual else "") + " (this clinician's own Local Data)")
    else:
        print(f"SAVE: {wf} most recent: {json.dumps(new)}")
        if args.make_usual:
            print(f"SAVE: {wf} usual: {json.dumps(new)}")
    print_feedback()


USUAL_CMD = {"trade-shifts": "swap", "swap-locations": "locswitch", "pickup-moonlighting": "mlpickup"}


LD_WORKFLOW_FILE_BY_NAME = {"trade-shifts": "preferences/trade-shifts", "swap-locations": "preferences/swap-locations",
                            "pickup-moonlighting": "preferences/pickup-moonlighting"}


MORE_COMMANDS = {"myblocks": cmd_myblocks, "usual": cmd_usual, "comingsoon": cmd_comingsoon, "usage": cmd_usage, "demo": cmd_demo,
                 "testmode": cmd_testmode}


# ---- 0.01.08 script step D: feedback names and item IDs (6.1) and more ----
FB_CATEGORIES = ("bug", "request", "roster", "schedule", "term", "lesson", "health", "usage")


def name_letters(last, first):
    """6.1: the primary user's letters, first three of the last name then of the first name, punctuation skipped, first
    letter of each capital; names under three letters use the letters there are."""
    def three(x):
        t = "".join(c for c in str(x or "") if c.isalpha())[:3]
        return t[:1].upper() + t[1:]
    return three(last) + three(first)


def cmd_fbname(args):
    """6.1: the feedback file name (YYYYMMDDHHMM_<LLL><FFF>_feedback.md, _2, _3 in the same minute) or an item ID
    (YYYYMMDDHHMMSS_mmm_<LLL><FFF>_<category>), Eastern time, always the primary user's letters."""
    t = now()
    who = name_letters(args.last, args.first)
    if not who:
        print("ERROR: give the primary user's --last and --first names.")
        sys.exit(2)
    if args.item:
        ms = t.microsecond // 1000
        used_f = os.path.join(WORK, ".item-ids")   # fix 3 #16: IDs are unique within a chat, whatever the clock says
        try:
            used = set(open(used_f, encoding="utf-8").read().split())
        except OSError:
            used = set()
        iid = f"{t:%Y%m%d%H%M%S}_{ms:03d}_{who}_{args.item}"
        while iid in used:
            ms += 1
            iid = f"{t:%Y%m%d%H%M%S}_{ms:03d}_{who}_{args.item}"
        try:
            with open(used_f, "a", encoding="utf-8") as f:
                f.write(iid + "\n")
        except OSError:
            pass
        if args.text and LD_ROOT:   # C1:213: the item is kept now, not only in the chat (a demo's is marked demo)
            save_state([("feedback outbox", f"{iid} {'(demo) ' if demo_active() else ''}{args.text.strip()}")])
            print(f"ITEM_ID: {iid}. SAVED: the item, with its ID, in this chat's Local Data outbox; Collect (Wrap-up 4) "
                  "puts it in the feedback file (`feedback --collect`).")
        else:
            print(f"ITEM_ID: {iid}. Tag the item with it where it's first added to the feedback file; merged items keep "
                  "the earliest ID.")
        print_feedback()
        return
    base, n = f"{t:%Y%m%d%H%M}_{who}_feedback", 1
    taken = set(os.listdir(args.dir)) if args.dir and os.path.isdir(args.dir) else set()
    taken |= set(args.taken or [])
    name = base + ".md"
    while name in taken:
        n += 1
        name = f"{base}_{n}.md"
    print(f"FEEDBACK_FILE: {name}. Collect the feedback into this file (from templates/feedback.md).")
    print_feedback()


# 6.7 (kept in memory in 0.01.08; Local Data in 0.01.09): delay messages, loading lines and request history
WAIT_STEPS = {   # step -> (reason, starting estimate in ms until the timing log has real ones)
    "decrypt": ("Decrypting the skill's data", 1500),
    "download": ("Downloading the latest schedule from ShiftAdmin", 4000),
    "search": ("Checking every colleague's schedule for trades", 3000),
    "wide-search": ("Searching every site, shift time and trade category", 7000),
    "workflow": ("Loading the workflow", 2500),
    "feedback": ("Encrypting and sending your feedback", 3000),
    "mlpickup": ("Checking the open shifts against your schedule", 3000),   # same size of job as a search
}
WAIT_SAY_MS, WAIT_FUNNY_MS = 2000, 5000


def loading_lines():
    try:
        text = open(os.path.join(SKILL_DIR, "references", "loading-lines.md"), encoding="utf-8").read()
    except OSError:
        return []
    return [l[2:].strip() for l in text.splitlines() if l.startswith("- ")]


def cmd_wait(args):
    """WAIT before a slow step (6.7): the reason and an estimate (the median of past timings when memory has them),
    only when it's over 2 s; over 5 s also a LOADING_LINE, never the one shown last."""
    reason, est = WAIT_STEPS[args.kind]
    past = sorted(x for x in (args.past_ms or []) if x > 0)
    if past:
        est = past[len(past) // 2]
    if est <= WAIT_SAY_MS:
        print(f"WAIT_NONE: {args.kind} usually takes under 2 seconds; say nothing, just run it.")
        print_feedback()
        return
    secs = max(1, round(est / 1000))
    print(f"WAIT: say in one short line before running it: \"{reason}, about {secs} second{'s' if secs != 1 else ''}…\"")
    lines = loading_lines()
    if est > WAIT_FUNNY_MS and lines:
        seed = os.environ.get("SHIFTSWAP_SEED")
        rnd = __import__("random").Random(int(seed) if seed else None)
        pick = rnd.choice([i for i in range(len(lines)) if i != args.last_line] or [0])
        print(f"LOADING_LINE: then this, on its own line (never with an error or failure message): \"{lines[pick]}\"")
        print(f"SAVE: last loading line: {pick}")
    print_feedback()


REQ_PEOPLE = None   # the roster, loaded once for reqhist's name matching


def canon_colleague(name):
    """C1:248 / C2:199: one key for a colleague whichever form is used: the list's "Last, F.", contacts'
    "First Last", or "Dr. First Last, MD" (matched on the roster; titles and credentials dropped)."""
    global REQ_PEOPLE
    base = re.sub(r"^\s*(dr\.?|doctor)\s+", "", str(name or ""), flags=re.I).strip()
    if REQ_PEOPLE is None:
        try:
            REQ_PEOPLE = load_roster()[0]
        except (SystemExit, Exception):
            REQ_PEOPLE = []
    for x in (base, base.split(",")[0]):
        hits = find_person(REQ_PEOPLE, x) if REQ_PEOPLE and x.strip() else []
        if len(hits) == 1:
            return nkey(hits[0].name)
    return nkey(base.split(",")[0])


def request_key(r):
    """(colleague, shift) with titles and credentials dropped ("Dr. Alex Example, MD" = "Alex Example")."""
    return canon_colleague(r.get("colleague")), str(r.get("shift") or r.get("shift_id") or "")


def merge_request(hist, new):
    """C1:249 / C2:200: how one request-history entry joins the saved list (the script saves it itself): every "sent"
    entry is kept; a new draft replaces only a draft for the same colleague, shift and dates; a new "sent" entry also
    replaces drafts for the same colleague and shift whose dates it covers."""
    key, dates = request_key(new), set(new.get("dates") or [])
    keep = []
    for h in hist or []:
        if isinstance(h, dict) and h.get("status") != "sent" and request_key(h) == key and (
                set(h.get("dates") or []) == dates or (new.get("status") == "sent" and set(h.get("dates") or []) <= dates)):
            continue
        keep.append(h)
    return keep + [new]


def cmd_reqhist(args):
    """Request history (6.7, requests/history in Local Data): before a request goes out, is it an exact repeat of one already
    SENT to the same colleague (same shift and dates), a partial overlap (which dates), or only drafted before?
    Drafts never count as sent; only 'Sent' at Sent or not (Trade Shifts 10) marks one sent (--sent)."""
    if args.history is None and LD_ROOT:
        hist = ld_open().read("requests/history", []) or []   # Local Data (4.14): the script reads it itself
    else:
        try:
            hist = json.loads(args.history or "[]")
        except ValueError:
            hist = None
    if not isinstance(hist, list) or not all(isinstance(h, dict) for h in hist):
        print("ERROR: the request history must be a JSON list of requests (requests/history in Local Data).")
        sys.exit(2)
    dates = sorted(set(args.dates or []))
    for_dates = f" for {', '.join(dates)}" if dates else ""   # a give-away names no dates: same colleague and shift
    want = {"colleague": args.colleague, "shift": args.shift}
    same = [h for h in hist if request_key(h) == request_key(want)]
    sent = [h for h in same if h.get("status") == "sent"]
    asked = sorted({d for h in sent for d in h.get("dates") or []})
    if args.sent:
        print(f"SAVE: request history: {json.dumps(dict(want, dates=dates, status='sent', on=f'{now():%Y-%m-%d}'))} "
              "(added to the history; earlier sent requests are kept, drafts it covers are replaced)")
    elif sent and set(dates) <= set(asked):
        on = sorted({h.get("on") for h in sent if h.get("on")})
        when = "was asked on " + ", ".join(short_date(x) for x in on) if on else "was asked before"
        if args.check:   # C1#15: only a lookup (did my request go out?), so no request to leave them out of
            print(f"REQUEST_REPEAT: {args.colleague} {when} about #{args.shift}{for_dates} (sent). Say when; offer a "
                  "follow-up if they haven't answered.")
        else:
            print(f"REQUEST_REPEAT: {args.colleague} {when} about #{args.shift}{for_dates} (sent). Leave them out of "
                  "this request; offer a follow-up to that request instead.")
    else:
        if sent and set(dates) & set(asked):
            print(f"REQUEST_PARTIAL: {args.colleague} was already asked about #{args.shift} for "
                  f"{', '.join(sorted(set(dates) & set(asked)))}, not for {', '.join(sorted(set(dates) - set(asked)))}. "
                  + ("Say which dates were asked, and which weren't." if args.check else "Say which dates were asked before."))
        elif any(h.get("status") != "sent" and (not dates or not h.get("dates") or set(dates) & set(h.get("dates")))
                 for h in same):   # a draft for other dates doesn't make this one "drafted before"
            print(f"REQUEST_DRAFTED_BEFORE: a request to {args.colleague} about #{args.shift} was drafted before but "
                  "never confirmed as sent; it doesn't count as asked.")
        else:
            print(f"REQUEST_NEW: {args.colleague} hasn't been asked about #{args.shift} for these dates.")
        if not args.check:   # --check: only look (a later chat asking "did my request go out?")
            print(f"SAVE: request history: {json.dumps(dict(want, dates=dates, status='draft', on=f'{now():%Y-%m-%d}'))} "
                  "(a draft, added to the history; earlier sent requests are kept)")
    print_feedback()


# 4.8 (6.7, in memory in 0.01.08; Local Data in 0.01.09): counters restart after a new version. Each release lists the
# counters (offer schedules, reminders, run counts behind an offer) whose workflow or step it changed, with what changed.
COUNTER_CHANGES = {
    "0.01.08": {
        "summary_mode_offer": "summary mode is now a named mode you can switch out of at the start of any Trade Shifts run",
        "blocked_dates_share": "sharing your blocked dates now also covers updates to your vacation days",
    },
}


def counter_restarts(st, installed):
    """-> (marker lines, SAVE lines) for the first launch of a new version: the changed counters restart from zero, and
    anything the user asked not to be asked again about that this version changed is asked once more."""
    lines, saves = [], []
    counters = st.get("counters") or {}
    raw = st.get("never_ask") or []
    if isinstance(raw, str):   # memory may keep it as one line: "a, b (since 0.01.08)"
        raw = re.split(r"[,;]\s*", raw)
    never = {}   # key -> the version they said no in ("" when not recorded)
    for x in raw:
        m = re.match(r"^\s*([\w-]+)\s*(?:\(since ([\d.]+)\))?", str(x))
        if m:
            never[m.group(1)] = m.group(2) or ""
    changed, when = {}, {}
    for v, keys in COUNTER_CHANGES.items():
        if vkey(installed) < vkey(v) <= vkey(VERSION):
            changed.update(keys)
            when.update({k: v for k in keys})
    for k in sorted(changed):
        if str(counters.get(k, 0)) not in ("0", ""):
            saves.append(f"counters: {k} 0 (restarted: {VERSION} changed it)")
        if k in never and not (never[k] and vkey(never[k]) >= vkey(when[k])):   # a no given after this change stands
            lines.append(f"COUNTER_ASK_AGAIN{reads(NEW_VERSION)}: {k}: they asked not to be asked again, but {VERSION} "
                         f"changed it ({changed[k]}). When it next comes up, ask once more: say you know they asked not "
                         "to be asked, what changed and why it might be worth another try. On no: save "
                         f"'never ask: {k} (since {VERSION})' and don't ask again until a later version changes it.")
    return lines, saves


ROLE_CHECK_DAYS = ((3, 25), (6, 24), (9, 24), (12, 25))   # 2.1: a week before each quarter starts


def role_check_anchor(d):
    """2.1 (answer 9/26): the quarterly role check runs on the first startup on or after Mar 25, Jun 24, Sep 24 and
    Dec 25, once per quarter: it's due when the last check was before the latest of those dates on or before d."""
    return max(date(y, m, dd) for y in (d.year - 1, d.year) for m, dd in ROLE_CHECK_DAYS if date(y, m, dd) <= d)


def level_label(x):
    """9.7 B6: the SrAPP level is shown as "SrAPP (LT UC only)"."""
    return "SrAPP (LT UC only)" if x == "SrAPP" else x


# 2.7 setup question count and 9.7 B7 nothing missing after setup
SETUP_QUESTIONS = {   # path -> questions still to come after Help level (Setup 2; administrators: after the name check)
    "clinician": 7, "walk": 10, "administrator": 4, "rerun": 2, "rerun-walk": 7, "clinician-part": 5,
}
SETUP_SECS = (20, 45)   # starting 25th-75th percentile seconds per question until usage data has real ones


def cmd_setupcount(args):
    """2.7: 'Setup has about N more questions. It takes about M minutes...' N per path; M from per-question times
    (usage data) as the 25th-75th percentile range times N. Run right after Help level (Setup 2), so the path is known
    and the count is given once (C1:40); reruns get their count from startup (it knows what this launch asks)."""
    print(setup_count_text(SETUP_QUESTIONS[args.path], args.path, args.question_secs))
    print_feedback()


def setup_count_text(n, path, question_secs=None, when="now, before the next setup question"):
    secs = sorted(x for x in (question_secs or []) if x > 0)
    if len(secs) >= 4:
        lo, hi = secs[len(secs) // 4], secs[(3 * len(secs)) // 4]
    else:
        lo, hi = SETUP_SECS
    m1, m2 = max(1, round(n * lo / 60)), max(1, round(n * hi / 60))
    mins = f"{m1}" if m1 == m2 else f"{m1} to {m2}"
    once = "" if path.startswith("rerun") else ", you only do it once"
    return (f"SETUP_COUNT: say {when}, word for word: \"Setup has about {n} more question"
            f"{'s' if n != 1 else ''}. It takes about {mins} minute{'s' if mins != '1' else ''}{once}, and it makes sure "
            "your results are accurate.\"")


SETUP_FIX = {   # C1:119: what to run for each missing item (Save and check, Setup 9)
    "about you": "About You and Role Check (Setup 3): `aboutyou --name \"<roster name>\" --line \"<the pasted line>\"`",
    "help level": "Help level (Setup 2): `save \"help level: walk me through|standard|advanced\"`",
    "usage data": "Usage data and plan (Setup 4): `save \"usage data: on\"` (or off, if they asked)",
    "plan": "Usage data and plan (Setup 4): `save \"plan: <answer>; plan asked: " + VERSION + "\"`",
    "location ratings": "Location and Shift Time Preferences (Setup 6): `prefs --line \"<the pasted line>\"`",
    "shift-time ratings": "Location and Shift Time Preferences (Setup 6): `prefs --line \"<the pasted line>\"`",
    "back-to-back": "Back-to-back shifts (Setup 7): `save \"back-to-back: no|if I ask|let others ask\"` (default no)",
}


def cmd_setupcheck(args):
    """9.7 B7: at the end of setup (Save and check, Setup 9), list any setting Local Data still doesn't have, each with
    the command that saves it (the same keys setup saves: aboutyou, prefs, save)."""
    st = load_state(args.state)
    prof = st.get("profile") or {}
    has = lambda *ks: next((st.get(k) for k in ks if st.get(k) not in (None, "", [], {})), None)
    need = [("about you", prof.get("roster_name") and all(prof.get(f) not in (None, "") for f in PROFILE_FIELDS
                                                           if f != "role")),
            ("help level", st.get("help_level")), ("usage data", st.get("usage_data") or "on"), ("plan", st.get("plan"))]
    if args.path != "administrator":   # administrators are asked the plan too (Usage data and plan, Setup 4)
        need += [("location ratings", has("site_ratings", "location_ratings", "site_order", "location_preferences")),
                 ("shift-time ratings", has("shift_time_ratings", "time_order", "shift_time_preferences")),
                 ("back-to-back", st.get("back_to_back"))]
    missing = [k for k, v in need if v in (None, "", [], {}, False)]
    if missing:
        print("SETUP_MISSING (Save and check, Setup 9): these aren't saved yet: " + ", ".join(missing) + ". Ask for each "
              "one now (or save the default and say so), then run setupcheck again. To save each:")
        fixes = {}
        for k in missing:
            fixes.setdefault(SETUP_FIX[k], []).append(k)
        for fx, ks in fixes.items():
            print(f"SETUP_FIX: {' and '.join(ks)}: {fx}")
    else:
        print("SETUP_COMPLETE: every setting is saved.")
    print_feedback()


# 9.8 passphrase changes (R1): 5 wrong tries then a 24-hour lockout (like the name check), no near-miss hints, and old
# passphrases recognised by fingerprint only. Tries and the lock are kept in memory in 0.01.08 (Local Data in 0.01.09).
PASS_TRIES = 5
OLD_PASSPHRASES = {}   # fingerprint -> the date it changed ("YYYY-MM-DD"); filled at packaging, never the passphrases


def passphrase_fp(norm):
    """A slow, salted fingerprint of a normalized passphrase (never the passphrase itself)."""
    return hashlib.pbkdf2_hmac("sha256", norm.encode(), b"cincipem-shiftmate-old-passphrase", 200000).hex()[:32]


def passphrase_locked(args):
    until = (getattr(args, "locked_until", None) or "").strip()
    if not until or until.lower() == "none":
        return False
    try:
        u = datetime.fromisoformat(until).replace(tzinfo=ET)
    except ValueError:
        return False
    if u <= now():
        return False
    print(f"PASSPHRASE_LOCKED: unlocking is locked until {until} after {PASS_TRIES} wrong passphrases. Explain kindly and "
          "say when they can try again (in their local time), and that the maintainer (feedback_name / feedback_email in "
          "SKILL_SENSITIVE.md) can help if they've lost the current passphrase. Stop.")
    return True


def passphrase_refused(args, pw, norm):
    """After a wrong passphrase: True when this printed the answer (an old passphrase, or tries left / the lockout)."""
    changed = OLD_PASSPHRASES.get(passphrase_fp(norm))
    if changed and not getattr(args, "old_tried", False):   # only the first old passphrase is free; later ones count
        print(f"OLD_PASSPHRASE: that's the passphrase for an older version; it changed on {changed}. Ask for the current "
              "one (it's in the email that announced this version). This first one doesn't count as a wrong try.")
        if not LD_ROOT:   # Local Data: lockout.json keeps it (cmd_unlock)
            print("SAVE: old passphrase tried: yes")
        return True
    if changed:
        print(f"OLD_PASSPHRASE_AGAIN: that's an older version's passphrase again (it changed on {changed}); this one "
              "counts as a wrong try. Ask for the current one (it's in the email that announced this version).")
    used = int(getattr(args, "tries_used", None) or 0) + 1
    if used >= PASS_TRIES:
        until = (now() + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M")
        print(f"PASSPHRASE_LOCKED: {PASS_TRIES} wrong passphrases, so unlocking is locked for 24 hours, until {until}. "
              "Explain kindly and say when they can try again (in their local time), and that the maintainer (feedback_name / "
              "feedback_email in SKILL_SENSITIVE.md) can help if they've lost the current passphrase.")
        if not LD_ROOT:
            print(f"SAVE: passphrase tries: 0; passphrase locked until: {until}")
        return True
    left = PASS_TRIES - used
    print(f"BAD_PASSPHRASE: that passphrase doesn't unlock this version ({left} tr{'y' if left == 1 else 'ies'} left "
          "before a 24-hour lockout; say so). Ask the user to check it (capitals, spaces and punctuation don't matter); "
          "no hints about how close it was.")
    if not LD_ROOT:
        print(f"SAVE: passphrase tries: {used}")
    return True


# 6.10 several sessions at once (open-session notes kept in memory in 0.01.08; Local Data in 0.01.09)
SESSION_ACTIVE_H, SESSION_KEEP_H = 2, 24   # "active": activity in the last 2 h; notes idle over 24 h move to closed
SESSION_CLOSED_KEEP = 10   # closed-session notes kept in memory (the newest)


def cmd_session(args):
    """Open-session note for this chat (6.10): make or refresh it, and say in one line when another chat is active,
    with a pointer to it (when it started and its first message), and when it's working on the same task."""
    st = load_state(args.state)
    t = now()
    lst = lambda v: [n for n in v if isinstance(n, dict)] if isinstance(v, list) else []   # damaged memory: skip it
    st["sessions"] = lst(st.get("sessions"))
    closed = lst(st.get("closed_sessions"))
    if args.close and demo_active():   # fix 3 #9: a demo keeps no session notes (demo.md: nothing is saved)
        print("SESSION_CLOSED: demo: nothing saved (a demo keeps no session notes). Go on to Close (Wrap-up 8).")
        print_feedback()
        return
    if args.close:   # 2.8/6.10: the chat closed; its note moves from open to closed
        gone = [n for n in st.get("sessions") or [] if n.get("id") == args.close]
        left = [n for n in st.get("sessions") or [] if n.get("id") != args.close]
        closed += [dict(n, closed=f"{t:%Y-%m-%d %H:%M}") for n in gone]
        print(f"SESSION_CLOSED: {args.close} moved to closed sessions." if gone else
              f"SESSION_CLOSED: {args.close} wasn't open (nothing to move).")
        print("SAVE: open sessions: " + json.dumps(left))
        print("SAVE: closed sessions: " + json.dumps(closed[-SESSION_CLOSED_KEEP:]))
        print_feedback()
        return
    if args.id and any(n.get("id") == args.id for n in closed):   # 2.8: the skill was closed in this chat
        plan = str(st.get("plan") or "").strip().lower()
        adv = (st.get("help_level") or "").lower() == "advanced"
        if not args.override_closed:
            print(f"CHAT_CLOSED{reads('workflows/wrap-up/close-after-stop.md')}: the skill was already closed in this "
                  "chat. Don't restart it here: ask them to start a new chat and ask for it there (new chats also use up "
                  "their usage limit less fast). Stop." + (" Advanced help level and not the Free plan: if they "
                  "explicitly ask to keep going here, re-run with --override-closed." if adv and plan and
                  not plan.startswith("free") else ""))
            return
        if not adv or not plan or plan.startswith("free"):
            print("CHAT_CLOSED_NO_OVERRIDE: --override-closed is only for the Advanced help level on a plan other than "
                  "Free. Ask them to start a new chat. Stop.")
            return
        print("CHAT_REOPENED: they asked to keep going in this closed chat (Advanced, not Free); go on here.")
        st["sessions"] += [{k: v for k, v in n.items() if k != "closed"} for n in closed if n.get("id") == args.id]
        closed = [n for n in closed if n.get("id") != args.id]
    sid = args.id or f"{t:%Y%m%d%H%M%S}-{__import__('random').randrange(16 ** 4):04x}"
    if not args.id:
        print(f"SESSION_ID: {sid} (use it for this chat's later `session` runs)")
    notes, others = [], []
    for n in st.get("sessions") or []:
        try:
            last = datetime.fromisoformat(str(n.get("last", ""))).replace(tzinfo=ET)
        except ValueError:
            continue
        age = (t - last).total_seconds() / 3600
        if n.get("id") == sid:
            continue
        if age > SESSION_KEEP_H:   # stale: it moves to closed too (6.10)
            closed.append(dict(n, closed=f"{t:%Y-%m-%d %H:%M} (stale)"))
            continue
        notes.append(n)
        if age <= SESSION_ACTIVE_H:
            others.append(n)
    mine = next((n for n in st.get("sessions") or [] if n.get("id") == sid), {})
    me = dict(mine, id=sid, started=mine.get("started") or f"{t:%Y-%m-%d %H:%M}", last=f"{t:%Y-%m-%d %H:%M}")
    for k in ("first", "workflow", "task", "link"):
        v = getattr(args, k if k != "first" else "first_message", None)
        if v:
            me[k] = v
    told = [x for x in me.get("told") or [] if isinstance(x, str)]
    for n in others:
        key = f"{n.get('id')}|{me.get('task') if n.get('task') == me.get('task') else ''}"
        if key in told:   # C3#11: each other chat is said once per chat (SAME_TASK once per task)
            continue
        told.append(key)
        if any(str(x).split("|")[0] == str(n.get("id")) for x in told[:-1]):   # already said; only SAME_TASK is new
            if me.get("task") and n.get("task") == me.get("task"):
                print(f"SAME_TASK: that chat is working on the same thing ({me['task']}); say so in one line before "
                      "going on, so they can finish in one place.")
            continue
        start = datetime.fromisoformat(n["started"]).strftime("%-I:%M %p").lower() if n.get("started") else "earlier"
        print(f"OTHER_SESSION: say in one line: \"The skill is also open in another chat, started at {start}. Both can be "
              "used; changes are shared. Keeping to one chat at a time is smoothest, but you don't have to.\" Then a "
              f"short pointer: its first message was \"{n.get('first', '?')}\"" + (f" ({n['link']})" if n.get("link") else "")
              + ".")
        if me.get("task") and n.get("task") == me.get("task"):
            print(f"SAME_TASK: that chat is working on the same thing ({me['task']}); say so in one line before going "
                  "on, so they can finish in one place.")
    if told:
        me["told"] = told
    print("SAVE: open sessions: " + json.dumps(notes + [me]))
    if closed != (st.get("closed_sessions") or []):   # something moved to closed, or damaged notes were cleared
        print("SAVE: closed sessions: " + json.dumps(closed[-SESSION_CLOSED_KEEP:]))
    print_feedback()


SITES = [("www.shiftadmin.com", "the schedule"), ("raw.githubusercontent.com", "updates"), ("api.github.com", "feedback")]


def cmd_sites_check(args):
    """Allowed websites (Setup 5): can this chat reach the three sites the skill needs? Any HTTP answer means reachable."""
    urls = args.test_urls or [f"https://{h}/" for h, _ in SITES]
    got, missing = [], []
    for (host, what), url in zip(SITES, urls):
        try:
            urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "cincipem-shiftmate"}), timeout=15)
            ok = "reachable"
        except urllib.error.HTTPError as e:
            ok = "reachable" if e.code < 500 or e.code > 599 else f"reachable (http {e.code})"
        except Exception as e:
            why = net_problem(e)
            ok = "blocked (not in allowed domains)" if why == "blocked" else f"not reached ({why})"
        got.append(f"{host} ({what}): {ok}")
        if not ok.startswith("reachable"):
            missing.append((host, what))
    print("SITES_CHECK (Allowed websites and the beta, Setup 5): " + " | ".join(got))
    if missing:
        print(f"SITES_MISSING{reads('workflows/setup/main.md')}: say which sites are missing and what each is for: "
              + "; ".join(f"{h} ({w})" for h, w in missing) + ". To add, exactly as written: "
              + ", ".join(h for h, _ in missing) + ". Offer [Walk me through it] [Go on without it]; after each fix, run "
              "`sites-check` again. Log each attempt in system health.")
    else:
        print("SITES_OK: say one line: \"✅ I can reach the schedule, updates and feedback sites.\" Nothing to do.")
    print_feedback()


def add_d_parsers(sub):
    fn = sub.add_parser("fbname")
    fn.add_argument("--last", required=True, help="the primary user's last name (even when running it for someone else)")
    fn.add_argument("--first", required=True, help="the primary user's first name")
    fn.add_argument("--item", choices=FB_CATEGORIES, help="make an item ID for this category instead of a file name")
    fn.add_argument("--text", help="with --item: the item, word for word; saved with its ID in this chat's outbox")
    fn.add_argument("--dir", help="the folder the file goes in (a name already there gets _2, _3)")
    fn.add_argument("--taken", nargs="*", help="file names already used this session")
    wt = sub.add_parser("wait")
    wt.add_argument("--kind", required=True, choices=sorted(WAIT_STEPS), help="the slow step about to run")
    wt.add_argument("--past-ms", type=int, nargs="*", help="this step's past run times from memory (USAGE_STEP)")
    wt.add_argument("--last-line", type=int, default=-1, help="from memory: the loading line shown last")
    sc = sub.add_parser("setupcount")
    sc.add_argument("--path", required=True, choices=sorted(SETUP_QUESTIONS))
    sc.add_argument("--question-secs", type=int, nargs="*", help="past seconds per setup question, from usage data")
    sk = sub.add_parser("setupcheck")
    sk.add_argument("--state", help=argparse.SUPPRESS)   # tests only: settings JSON instead of Local Data
    sk.add_argument("--path", choices=["clinician", "administrator"], default="clinician")
    sx = sub.add_parser("sites-check")
    sx.add_argument("--test-urls", nargs=3, help=argparse.SUPPRESS)   # tests: stand-ins for the three sites
    se = sub.add_parser("session")
    se.add_argument("--state", help=argparse.SUPPRESS)   # tests only: settings JSON ('sessions': open notes)
    se.add_argument("--id", help="this chat's session ID from its first `session` run")
    se.add_argument("--first-message", help="this chat's first message (short)")
    se.add_argument("--workflow", help="the workflow this chat is in")
    se.add_argument("--task", help="what it's working on, e.g. 'shift 107941' or 'preferences page'")
    se.add_argument("--link", help="this chat's link, when Claude has it")
    se.add_argument("--close", metavar="ID", help="this chat closed (2.8): move its session note to closed")
    se.add_argument("--override-closed", action="store_true",
                    help="keep using a chat where the skill was closed (Advanced help level, not the Free plan, and only "
                         "when they ask)")
    rh = sub.add_parser("reqhist")
    rh.add_argument("--history", help=argparse.SUPPRESS)   # tests only: the history JSON list instead of requests/history
    rh.add_argument("--colleague", required=True)
    rh.add_argument("--shift", required=True, help="the shift ID being offered")
    rh.add_argument("--dates", nargs="*", help="the trade-into dates asked about (YYYY-MM-DD)")
    rh.add_argument("--sent", action="store_true", help="they said Sent at Sent or not (Trade Shifts 10)")
    rh.add_argument("--check", action="store_true", help="only look: saves nothing (was a request sent?)")
    ad = sub.add_parser("askdue")   # Blocked-date sharing (Wrap-up 2): 2, 3, 4, 5, then every 5 uses after a no
    ad.add_argument("--key", default="blocked_dates_share", help="the counter's name in memory")
    ad.add_argument("--uses", type=int, default=None, help="uses since the last ask (default: Local Data's "
                    "'counters: <key> N')")
    ad.add_argument("--asked", type=int, default=None, help="times asked so far (default: Local Data's '<key> asks')")
    ad.add_argument("--never", action="store_true", help="'never ask' lists <key> (Local Data is read too)")


ASK_GAPS = (2, 3, 4, 5)   # 3.2 (your comment 9/25): after a no, ask again after 2, 3, 4, then 5 uses, then every 5


def ask_gap(asked):
    """Uses to wait before the next ask, after `asked` asks answered no so far (1 = the first no)."""
    return ASK_GAPS[min(asked, len(ASK_GAPS)) - 1] if asked >= 1 else 0


def cmd_askdue(args):
    """Blocked-date sharing (Wrap-up 2): is the ask due at this wrap-up? Counts this use, and says the SAVE lines.
    Fix 3 #15: with Local Data, --uses, --asked and --never default to what the script saved there."""
    if LD_ROOT and (args.uses is None or args.asked is None or not args.never):
        try:
            st = ld_state()
        except SystemExit:
            st = {}
        num = lambda v: int(m.group(1)) if (m := re.search(r"(\d+)", str(v or ""))) else 0
        c = st.get("counters")
        if args.uses is None:
            if isinstance(c, dict):
                args.uses = num(c.get(args.key))
            else:
                m2 = re.search(re.escape(args.key) + r"\s+(\d+)", str(c or ""))
                args.uses = int(m2.group(1)) if m2 else 0
        if args.asked is None:
            args.asked = num(st.get(f"counters_{args.key}_asks") or st.get(f"{args.key}_asks"))
        nv = st.get("never_ask")
        if not args.never and args.key in (json.dumps(nv) if not isinstance(nv, str) else nv or ""):
            args.never = True
    args.uses = args.uses or 0
    args.asked = args.asked or 0
    if args.never:
        print(f"ASK_DUE: no ({args.key}: they asked not to be asked again).")
        print_feedback()
        return
    uses = max(0, args.uses) + 1   # this wrap-up counts
    gap = ask_gap(args.asked)
    if args.asked < 1 or uses >= gap:
        print(f"ASK_DUE: yes ({args.key}: " + ("never asked" if args.asked < 1 else f"{uses} uses since the last ask, "
              f"due after {gap}") + "). Ask it.")
        print(f"SAVE: counters: {args.key} 0; {args.key} asks: {max(args.asked, 0) + 1}")
    else:
        print(f"ASK_DUE: no ({args.key}: {uses} of {gap} uses since the last ask). Don't ask; go on.")
        print(f"SAVE: counters: {args.key} {uses}")
    print_feedback()


MORE_COMMANDS.update({"prefs": lambda a: cmd_prefs(a), "aboutyou": lambda a: cmd_aboutyou(a)})
MORE_COMMANDS.update({"fbname": cmd_fbname, "wait": cmd_wait, "reqhist": cmd_reqhist, "setupcount": cmd_setupcount,
                      "setupcheck": cmd_setupcheck, "session": cmd_session,
                      "sites-check": cmd_sites_check, "askdue": cmd_askdue})

# ---------------------------------------------------------------- Local Data (tracker 4.14, plan 6.7)
# The engine runs on the user's computer, so it reads and writes Local Data itself; Claude memory keeps only the
# passphrase and where Local Data is. --local-data DIR (before the command) or env SHIFTMATE_LOCAL_DATA.
LD_ROOT = os.environ.get("SHIFTMATE_LOCAL_DATA") or None
_LD = None
LD_MISSING = "LOCAL_DATA_MISSING (read workflows/startup/local-data.md)"
LD_STATE_CMDS = {"startup", "session", "setupcheck", "testmode", "migrate-memory", "save", "settings", "aboutyou"}   # need saved state
LD_JSON_KEYS = {"open sessions": ("system/sessions/open/notes", "sessions"),
                "closed sessions": ("system/sessions/closed/notes", "closed_sessions")}
LD_FILES = [("counters", "profile/counters"), ("role", "profile/role"), ("last role", "profile/role"),
            ("request history", "requests/history"),
            ("name", "profile/about-you"), ("preferred name", "profile/about-you"),
            ("credentials", "profile/about-you"), ("contact", "profile/about-you"),
            ("site ratings", "preferences/sites"), ("sites", "preferences/sites"),
            ("site order", "preferences/sites"), ("location ratings", "preferences/sites"),
            ("shift-time ratings", "preferences/shift-times"), ("shift time ratings", "preferences/shift-times"),
            ("shift-times", "preferences/shift-times"), ("time order", "preferences/shift-times"),
            ("back-to-back", "preferences/shift-times"),
            ("trade shifts", "preferences/trade-shifts"), ("trade-shifts", "preferences/trade-shifts"),
            ("swap locations", "preferences/swap-locations"), ("swap-locations", "preferences/swap-locations"),
            ("pickup moonlighting", "preferences/pickup-moonlighting"),
            ("pickup-moonlighting", "preferences/pickup-moonlighting"),
            ("blocked dates share", "blocked-dates/sharing"), ("blocked dates sharing", "blocked-dates/sharing"),
            ("blocked dates shared", "blocked-dates/sharing"),
            ("work on vacation", "blocked-dates/my-blocks"), ("vacations", "blocked-dates/my-blocks"),
            ("shift time preferences", "preferences/shift-times"), ("location preferences", "preferences/sites"),
            ("site ratings tag", "preferences/sites"), ("prefs ask again", "profile/settings"),
            ("sharing", "blocked-dates/sharing"), ("blocked dates", "blocked-dates/my-blocks"),
            ("my blocks", "blocked-dates/my-blocks"), ("blocks", "blocked-dates/my-blocks"),
            ("feedback outbox", "feedback/outbox"), ("unsent feedback", "feedback/outbox"),
            ("usage row", "logs/usage"), ("feedback line", "logs/feedback"), ("usage step", "logs/timing"), ("timing", "logs/timing"),
            ("name tries", "profile/settings"), ("usage data", "profile/settings"),
            ("step timings", "logs/timing"), ("health", "logs/health")]   # everything else: profile/settings
LD_READ_FILES = ("profile/settings", "profile/counters", "profile/role", "profile/about-you", "preferences/sites",
                 "preferences/shift-times", "preferences/trade-shifts", "preferences/swap-locations",
                 "preferences/pickup-moonlighting", "blocked-dates/my-blocks", "blocked-dates/sharing",
                 "system/sessions/open/notes", "system/sessions/closed/notes")
LD_KEEP_IN_MEMORY = ("passphrase", "local data")   # the only memory lines after migrate-memory
TEST_MARK = os.path.join(WORK, ".ld-testing")   # test mode (Test mode 3): every command in this work folder uses testing/
LD_APPEND = {"roster_updates"}   # fields whose saves add to a list instead of replacing it (C1:90)


def ld_mode():
    """'testing' while test mode runs in this work folder (testmode --start / --continue), else 'live'."""
    if os.environ.get("SHIFTMATE_LD_TESTING") or os.path.exists(TEST_MARK):
        return "testing"
    return "live"


def ld_check_folder():
    """C1:8: a refused Local Data folder is one clean ERROR line (before anything says UNLOCKED), never a traceback."""
    if not LD_ROOT:
        return
    sys.path.insert(0, HERE)
    import localdata as L
    try:
        L.LocalData(LD_ROOT, mode=ld_mode())
    except (L.LocalDataError, OSError) as e:
        print(f"ERROR: Local Data folder refused ({e}). " + LD_MISSING)
        sys.exit(2)


def ld_open(need_key=True):
    """The Local Data folder with the chat's key loaded (from unlock), or None when no Local Data is set."""
    global _LD
    if _LD is not None or not LD_ROOT:
        return _LD
    sys.path.insert(0, HERE)
    import localdata as L
    try:
        ld = L.LocalData(LD_ROOT, mode=ld_mode())
    except L.LocalDataError as e:
        print(f"ERROR: Local Data folder refused ({e}). " + LD_MISSING)
        sys.exit(2)
    if not ld.load_key(WORK) and need_key:
        print("LOCAL_DATA_LOCKED: run `unlock` first (it makes the Local Data key for this chat).")
        sys.exit(5)
    try:   # format.json names the version and channel that last used this folder (plain, nothing personal)
        f = ld.read_format()
        if f.get("skill_version") != VERSION or f.get("channel") != CHANNEL:
            ld.write_format(skill_version=VERSION, channel=CHANNEL)
    except (OSError, ValueError):
        pass
    _LD = ld
    return ld


def _ld_key(k):
    return re.sub(r"[\s-]+", "_", k.strip().lower())


LD_FIELD_ALIASES = {   # C1:208, C1:236: one field for each setting, whatever spelling a workflow or 0.01.07 used
    "blocked_date_sharing": "blocked_dates_sharing", "blocked_dates_share": "blocked_dates_sharing",
    "blocked_date_share": "blocked_dates_sharing", "blocked_date_shared": "blocked_dates_shared",
    "plan_version": "plan_asked", "shift_time_preferences": "shift_time_ratings",
    "location_preferences": "site_ratings", "location_ratings": "site_ratings"}


def ld_file_for(key):
    k = re.sub(r"[-_\s]+", " ", key.strip().lower())
    k = re.sub(r"^blocked date\b", "blocked dates", k)   # 'blocked-date sharing' = 'blocked dates sharing'
    for pre, rel in sorted(LD_FILES, key=lambda x: -len(x[0])):   # longest prefix wins ('blocked dates share')
        pre = re.sub(r"[-_\s]+", " ", pre)
        if k == pre or k.startswith(pre + " ") or k.startswith(pre + ":"):
            return rel
    return "profile/settings"


def ld_update(rel, fn, default):
    """Read-modify-write one Local Data file; one retry when another process changed it (6.10)."""
    ld = ld_open()
    for _ in range(2):
        cur = ld.read(rel, default)
        res = ld.write(rel, fn(cur))
        if res.get("ok"):
            return res
    print(f"LOCAL_DATA_CONFLICT: {rel} changed while saving; run the command again.")
    return res


SAVE_KEY = r"([A-Za-z][\w ./'()-]*?)"


def parse_save(text):
    """'k: v; k2: v2' (a SAVE line's text) -> [(key, value)]; JSON values (sessions, request history) kept whole."""
    out, rest = [], text.strip()
    while rest:
        m = re.match(SAVE_KEY + r":\s*", rest)
        if not m:
            break
        key, rest = m.group(1).strip(), rest[m.end():]
        if rest[:1] in "[{":
            try:
                val, n = json.JSONDecoder().raw_decode(rest)
                out.append((key, val))
                rest = rest[n:].lstrip("; ").lstrip()
                if key.lower() == "request history":
                    break   # the rest of the line is a note for Claude
                continue
            except ValueError:
                pass
        # C1:87: split only at a '; ' that starts the next '<key>: ' pair, so a list with '; ' inside stays whole
        nx = re.search(r";\s+(?=" + SAVE_KEY + r":\s)", rest)
        val, rest = (rest[:nx.start()], rest[nx.end():]) if nx else (rest, "")
        out.append((key, val.strip()))
    return out


SAVE_FOR = ""   # save --clinician / prefs --clinician: that clinician's Local Data folder (clinicians/<id>)


def save_state(pairs):
    """Write (key, value) pairs to their Local Data files; returns the keys saved."""
    by = {}
    for k, v in pairs:
        by.setdefault(LD_JSON_KEYS.get(k.lower(), (ld_file_for(k), None))[0], []).append((k, v))
    for rel, kv in by.items():
        def upd(cur, kv=kv, rel=rel):
            if rel == "requests/history":
                out = list(cur or [])
                for _, v in kv:
                    out = merge_request(out, v) if isinstance(v, dict) else out + [v]
                return out
            if rel.startswith(("feedback/", "logs/")):   # outbox and logs: lines appended per chat
                return list(cur or []) + [v for _, v in kv]
            cur = dict(cur or {})
            for k, v in kv:
                f = LD_JSON_KEYS[k.lower()][1] if k.lower() in LD_JSON_KEYS else ld_field(k, rel)
                if f in LD_APPEND:   # C1:90: roster updates add up over setup and the run, never replace
                    have = cur.get(f) or []
                    have = [have] if isinstance(have, str) else list(have)
                    for x in (v if isinstance(v, list) else [v]):
                        if x not in have and x not in ("", None):
                            have.append(x)
                    cur[f] = have
                elif f in LIST_FIELDS:   # fix 3 #1: "blocks: none" is an empty list, never the text "none"
                    cur[f] = as_list(v, keep_str=(f == "blocked_dates_shared"))
                else:
                    cur[f] = v
            return cur
        rel_w = ld_chat_file(rel) if rel.startswith(("feedback/", "logs/")) else rel
        if SAVE_FOR and not rel.startswith(("feedback/", "logs/", "requests/", "system/")):
            rel_w = SAVE_FOR + "/" + rel_w   # an administrator saving a clinician's answers: their own files
        ld_update(rel_w, upd, [] if rel == "requests/history" or rel != rel_w else {})
    return [k for k, _ in pairs]


def ld_field(key, rel):
    """The field name inside its file: a workflow's 'trade shifts usual' is 'usual' in preferences/trade-shifts."""
    k = _ld_key(key)
    k = LD_FIELD_ALIASES.get(k, k)
    if rel in LD_WORKFLOW_FILE.values():
        for pre in (rel.split("/")[1], rel.split("/")[1].replace("-", " ")):
            p = _ld_key(pre) + "_"
            if k.startswith(p) and len(k) > len(p):
                return k[len(p):]
    return k


def ld_chat_file(rel):
    """feedback/outbox, logs/usage, logs/timing, logs/health: one file per chat (named after this chat's work area)."""
    chat = re.sub(r"[^A-Za-z0-9_.-]", "_", os.path.basename(os.path.normpath(WORK)) or "chat")
    return f"{rel}/{now():%Y-%m-%d}-{chat}"


LD_WORKFLOW_FILE = {"shifts": "preferences/trade-shifts", "avail": "preferences/trade-shifts",
                    "swap": "preferences/trade-shifts", "locswitch": "preferences/swap-locations",
                    "mlpickup": "preferences/pickup-moonlighting"}


def ld_primary_name():
    """The primary user's roster name from Local Data (About you), or ''."""
    try:
        st = ld_state()
    except SystemExit:
        return ""
    prof = st.get("profile") if isinstance(st.get("profile"), dict) else {}
    return str(prof.get("roster_name") or prof.get("name") or st.get("roster_name") or "").strip()


def ld_clinician_dir(name):
    """C3#4: a clinician searched for by someone else (an administrator, or 'run it for a colleague') has their own
    Local Data files under clinicians/<id>/ (the id is a hash, so no name is in a file path)."""
    return "clinicians/" + __import__("hashlib").sha256(nkey(name).encode()).hexdigest()[:16]


def ld_for_other(req):
    """The clinician's folder when the search is for someone other than the primary user, else None."""
    who = str(req.get("who") or "").strip()
    clin = str(req.get("clinician") or "").strip()
    prim = ld_primary_name()
    if (who and who.lower() != "you") or (clin and prim and nkey(clin) != nkey(prim)):
        return ld_clinician_dir(clin or who)
    return None


WIDE_FIELDS = ("sites", "times", "types", "categories", "len_up", "len_colleague")   # 4.1: what "everything" widens


def ld_fill_req(req, cmd):
    """Search inputs the request doesn't give, from Local Data (4.14): the workflow's usual and most recent settings,
    location and shift-time ratings, and the user's own blocks. What the request gives always wins.
    C2#1: with "everything", the sites, shift times, categories and lengths are never filled (they're widened); the
    ratings, blocks and back-to-back still are (answer 13). C3#4: searching for someone else reads that clinician's
    own files (clinicians/<id>/), never the primary user's; with none saved, the roster's preferences apply."""
    ld = ld_open()
    other = ld_for_other(req)
    pre = other + "/" if other else ""
    rd = lambda rel: (lambda d: d if isinstance(d, dict) else {})(ld.read(pre + rel, {}) or {})
    filled = []

    def put(k, v):
        if v not in (None, "", [], {}) and req.get(k) in (None, "", [], {}):
            req[k] = v
            filled.append(k)
    wf = rd(LD_WORKFLOW_FILE.get(cmd, "preferences/trade-shifts"))
    for k in ("most_recent", "usual"):   # the most recent run's choices first, then the usual ones
        v = wf.get(k)
        if isinstance(v, str):
            try:
                v = json.loads(v)
            except ValueError:
                v = None
        for kk, vv in (v or {}).items() if isinstance(v, dict) else ():
            if req.get("everything") and kk in WIDE_FIELDS:
                continue
            put(kk, vv)
    sites = rd("preferences/sites")
    put("site_ratings", sites.get("site_ratings") or sites.get("location_ratings") or sites.get("sites"))
    put("site_order", sites.get("site_order"))
    times = rd("preferences/shift-times")
    put("time_order", times.get("time_order") or times.get("shift_time_ratings") or times.get("shift_times"))
    put("back_to_back", times.get("back_to_back"))
    blk = rd("blocked-dates/my-blocks")
    put("blocks", as_list(blk.get("blocks") or blk.get("my_blocks") or blk.get("blocked_dates")))
    if filled:
        print("LOCAL_DATA_INPUTS: from " + ("this clinician's own Local Data" if other else "Local Data") + ": "
              + ", ".join(sorted(set(filled))))
    if other:
        print("LOCAL_DATA_CLINICIAN: searching for " + (str(req.get("who") or req.get("clinician") or "the clinician"))
              + ": only their own saved settings and the roster's preferences are used, never the primary user's.")
    return filled


def ld_state():
    """Saved state from Local Data, in the same shape as --state JSON."""
    ld = ld_open()
    st = {}
    for rel in LD_READ_FILES:
        d = ld.read(rel, {}) or {}
        if isinstance(d, dict):
            st.update(d)
    ay = ld.read("profile/about-you", {}) or {}
    if isinstance(ay, dict) and ay.get("roster_name"):   # C1:69: About you (aboutyou --line) is the profile
        prof = dict(st.get("profile") or {}) if isinstance(st.get("profile"), dict) else {}
        prof.update({f: ay[f] for f in ("roster_name",) + PROFILE_FIELDS if ay.get(f) not in (None, "")})
        st["profile"] = prof
    st["request_history"] = ld.read("requests/history", []) or []
    if st.get("installed"):   # saved as '<version> on <date>' or '<version> (<date>)' (fix 3 #3)
        v, d = split_installed(st["installed"])
        st["installed"] = v
        if d:
            st["installed_date"] = d
    st.setdefault("memory_format", 4)   # Local Data has no memory blocks to upgrade
    return st


# fix 3 #4: `usage data` (Auto-send) is shown; only usage rows and steps are hidden
SETTINGS_HIDDEN = ("usage_row", "usage_step", "request_history", "sessions", "closed_sessions", "counters", "memory_format",
                   "installed_date", "feedback", "logs", "name_tries", "passphrase")


def cmd_save(args):
    """Save answers the user gave (About you, help level, plan, preferences...) to Local Data. The text is one or more
    '<key>: <value>' pairs separated by '; ', the same form the workflows name ("Save `plan: Pro; plan asked: 0.01.08`").
    A '; ' splits pairs only where the next '<key>: ' starts, so a list value keeps its '; '. `--key K --value V` saves
    one value exactly as given (nothing split). --live (test mode only, after the double confirmation): the real settings."""
    if args.key is not None:
        v = args.value if args.value is not None else ""
        if v.strip()[:1] in ("[", "{"):   # a JSON list or object (blocks, blocked dates shared) is kept as JSON
            try:
                v = json.loads(v)
            except ValueError:
                pass
        pairs = [(args.key.strip(), v)]
    else:
        pairs = parse_save(args.text or "")
    bad = [k for k, _ in pairs if k.lower().startswith(LD_KEEP_IN_MEMORY)]
    if not pairs or bad or any(not k for k, _ in pairs):
        print("ERROR: nothing saved. Give '<key>: <value>' pairs separated by '; ', or --key K --value V"
              + (f"; never save {', '.join(bad)} (it stays in memory only)." if bad else "."))
        sys.exit(2)
    if getattr(args, "live", False) and ld_mode() == "testing":
        global _LD
        sys.path.insert(0, HERE)
        import localdata as L
        live = L.LocalData(LD_ROOT, mode="live")
        live.load_key(WORK)
        _LD, keep = live, _LD
        save_state(pairs)
        _LD = keep
        print("SAVED: " + ", ".join(k for k, _ in pairs) + " (real settings, live/: a test-mode override; log and flag it)")
        return
    direct_save(pairs)


def direct_save(pairs, what=None):
    """Save (key, value) pairs now and print one SAVED line; a demo saves nothing (as _DemoOut does for SAVE lines)."""
    if demo_active():
        print("DEMO_NOT_SAVED: a demo saves nothing; go on.")
        return False
    save_state(pairs)
    print("SAVED: " + (what or ", ".join(k for k, _ in pairs)))
    return True


def cmd_settings(args):
    """'Show my saved settings': every saved setting, one per line, for Claude to show in plain words."""
    st = ld_state()
    shown = 0
    for k in sorted(st):
        if k.lower().startswith(SETTINGS_HIDDEN) or st[k] in (None, "", [], {}):
            continue
        v = st[k] if isinstance(st[k], str) else json.dumps(st[k], ensure_ascii=False)
        print(f"SETTING: {k.replace('_', ' ')}: {v}")
        shown += 1
    print(f"SETTINGS: {shown} saved setting(s) in Local Data. Show them in plain words, grouped (About you, "
          "preferences, search settings, blocked dates); never show the passphrase.")


def keep_feedback_line(txt):
    """A FEEDBACK: line in this chat's logs/feedback file (each distinct line once per chat); a demo's is marked demo."""
    if not txt:
        return
    txt = ("(demo) " if demo_active() else "") + txt
    try:
        ld_update(ld_chat_file("logs/feedback"),
                  lambda cur: (list(cur or []) if isinstance(cur, list) else []) + ([] if txt in (cur or []) else [txt]),
                  [])
    except Exception:
        pass   # keeping a feedback line never stops the command


class _LDOut:
    """With Local Data: SAVE lines are written to Local Data by the script and shown as short SAVED lines."""
    def __init__(self, out):
        self.out, self.buf = out, ""

    def write(self, x):
        self.buf += x
        *lines, self.buf = self.buf.split("\n")
        for ln in lines:
            if ln.startswith("FEEDBACK: "):   # fix 3 #5 (SKILL.md: kept for the wrap-up); once per chat, read by --collect
                keep_feedback_line(ln[10:].strip())
            if ln.startswith(("USAGE_ROW: ", "USAGE_STEP: ")):   # 8.3: rows collect in logs/usage between sends
                save_state([("usage row" if ln.startswith("USAGE_ROW") else "usage step",
                             ln.split(": ", 1)[1].split(". Put it", 1)[0])])
            if ln.startswith("SAVE: "):
                pairs = parse_save(ln[6:])
                if pairs and pairs[0][0].lower() == "counters":   # 'counters: X 0; X asks: 1' is all profile/counters
                    pairs = [pairs[0]] + [("counters " + k, v) for k, v in pairs[1:]]
                ln = "SAVED: " + ", ".join(save_state(pairs))
            ln = ln.replace("Save every SAVE line to memory before the first question.",
                            "The script saves settings to Local Data itself (SAVED lines); save nothing to memory.")
            self.out.write(ln + "\n")
        return len(x)

    def flush(self):
        if self.buf:
            self.write("\n")
        self.out.flush()


def ld_unlock(pw):
    """After the passphrase check: make the Local Data key and keep it in the work folder for this chat (6.7)."""
    sys.path.insert(0, HERE)
    import localdata as L
    ld = L.LocalData(LD_ROOT, mode=ld_mode())
    try:
        ld.derive_key(pw)
    except L.BadKey:
        print("LOCAL_DATA_BAD_KEY: this passphrase doesn't open the Local Data folder (it was made with another "
              "passphrase, or a file was edited). Ask them to check the passphrase; don't create a new folder. Stop.")
        return False
    ld.save_key(WORK)
    rec = ld.read_lockout()
    if rec.get("passphrase") and not rec.get("tampered"):   # 9.8: a right passphrase resets the count
        rec["passphrase"] = []
        ld.write_lockout(rec)
    print(f"LOCAL_DATA: {ld.root} " + ("(unlocked on this computer until the next update)" if os.environ.get("SHIFTMATE_EXTENSION") else "(unlocked for this chat)"))
    return True


def ld_locked_out():
    sys.path.insert(0, HERE)
    import localdata as L
    ld = L.LocalData(LD_ROOT, mode=ld_mode())
    locked, rec = ld.is_locked_out()
    if locked:
        until = datetime.fromtimestamp(float(rec["locked_until"]), ET)
        print(f"PASSPHRASE_LOCKED: too many wrong passphrases; locked until {until:%Y-%m-%d %H:%M} (Eastern). Explain "
              "kindly and say when they can try again. Stop.")
        return True
    return False


def ld_wrong_try():
    """Wrong passphrase: counted in Local Data's lockout.json (no memory flags); 3 wrong -> 24 h lockout."""
    sys.path.insert(0, HERE)
    import localdata as L
    ld = L.LocalData(LD_ROOT, mode=ld_mode())
    import time as _t
    rec = ld.read_lockout()
    rec["passphrase"] = list(rec.get("passphrase") or []) + [_t.time()]
    if len(rec["passphrase"]) >= 3:
        rec["locked_until"], rec["passphrase"] = _t.time() + L.LOCKOUT_SECONDS, []
    ld.write_lockout(rec)


def _ld_plain():
    sys.path.insert(0, HERE)
    import localdata as L
    return L, L.LocalData(LD_ROOT, mode=ld_mode())


def ld_name_tries():
    """Setup name-check misses so far, from lockout.json (like the passphrase, 9.8); 3 while the 24 h lock runs."""
    import time as _t
    _, ld = _ld_plain()
    rec = ld.read_lockout()
    if rec.get("tampered") or _t.time() < float(rec.get("name_locked_until") or 0):
        return 3
    return len(rec.get("name") or [])


def ld_name_try(reset=False):
    """A name-check miss (third -> setup locked 24 h), or a match (reset=True), recorded in lockout.json."""
    import time as _t
    L, ld = _ld_plain()
    rec = ld.read_lockout()
    if rec.get("tampered"):
        return
    if reset:
        if not rec.get("name"):
            return
        rec["name"] = []
    else:
        rec["name"] = list(rec.get("name") or []) + [_t.time()]
        if len(rec["name"]) >= 3:
            rec["name_locked_until"], rec["name"] = _t.time() + L.LOCKOUT_SECONDS, []
    ld.write_lockout(rec)


def cmd_migrate_memory(args):
    """One-time move of a 0.01.07 memory block into Local Data (4.14)."""
    txt = args.memory
    if os.path.exists(txt):
        txt = open(txt, encoding="utf-8").read()
    try:
        d = json.loads(txt)
        pairs = [(k.replace("_", " "), v) for k, v in d.items()] if isinstance(d, dict) else []
    except ValueError:
        pairs = []
        for ln in txt.splitlines():
            ln = ln.strip().lstrip("-*").strip()
            if ":" in ln and not ln.startswith("#"):
                pairs += parse_save(ln)
    keep = [(k, v) for k, v in pairs if k.lower().startswith(LD_KEEP_IN_MEMORY)]
    move = [(k, v) for k, v in pairs if not k.lower().startswith(LD_KEEP_IN_MEMORY)]
    if not move:
        print("MIGRATED: nothing to move (no settings found in the memory text).")
        return
    moved = [k for k, _ in move]
    out = []
    for k, v in move:
        kk = _ld_key(k)
        # C2:20: ratings land where searches read them (preferences/sites, preferences/shift-times), best first, with
        # the page's names and a derived site_order / time_order; the old single Holiday rating is split (C2:53)
        if re.match(r"shift_?time_(preferences|ratings)$", kk) and parse_ratings(v):
            new = split_holiday(v)
            if new is not None:
                v = new
                print(f"MIGRATED_HOLIDAY: {k}: the one Holiday rating now applies to Holiday day, evening and overnight "
                      "(moved by 0.01 where needed so nothing ties).")
            out += prefs_pairs(times=parse_ratings(v))[0]
        elif re.match(r"(location_(preferences|ratings)|site_ratings)$", kk) and parse_ratings(v):
            out += prefs_pairs(sites=parse_ratings(v))[0]
        elif kk == "installed":   # fix 3 #3: '0.01.07 (2026-09-10)' / '0.01.07 on 2026-09-10' -> version + date
            ver, d = split_installed(v)
            if not re.match(r"\d+(\.\d+)+$", ver):
                print(f"MIGRATED_INSTALLED_UNKNOWN: installed '{v}' has no version number; saved as unknown (the next "
                      "startup treats it as an older version, no crash).")
            out.append((k, ver))
            if d and not any(_ld_key(x) in ("installed_on", "installed_date") for x, _ in move):
                out.append(("installed on", d))
        else:
            out.append((k, v))
    keys = {_ld_key(k) for k, _ in move}
    if "settings_mode" not in keys and any(re.search(r"usual|most_recent|quick_start", x) for x in keys):
        out.append(("settings mode", "summary"))   # C2:68: they had saved search settings, so they were shown a summary
        print("MIGRATED_SETTINGS_MODE: summary (they had saved search settings in 0.01.07, so they start in summary mode).")
    save_state(out)
    for k, _ in out:
        print(f"MIGRATED: {k} -> {LD_JSON_KEYS.get(k.lower(), (ld_file_for(k),))[0]}")
    inst = next((str(v) for k, v in move if _ld_key(k) == "installed"), "")
    when = next((str(v) for k, v in move if _ld_key(k) in ("installed_on", "installed_date")), "")
    inst, d = split_installed(inst)
    when = when or d
    if inst == VERSION and re.match(r"\d{4}-\d{2}-\d{2}$", when):   # C3:10: the banner shows the migrated date
        try:
            ld_open().write_format(installed_version=VERSION, installed_on=when)
        except (OSError, ValueError):
            pass
    print("MEMORY_CLEANUP: remove these memory lines: " + "; ".join(moved)
          + ". Keep only: " + ("; ".join(k for k, _ in keep) or "the passphrase and the Local Data location") + ".")



# ---------------------------------------------------------------- setup pages, test mode, feedback outbox (fix round 2)
TIME_PAGE_NAMES = {"WD_DAY": "Weekday day", "MT_EVE": "Mon to Thu evening", "FRI_EVE": "Friday evening",
                   "WE_DAY": "Weekend day", "WE_EVE": "Weekend evening", "MT_ON": "Mon to Thu overnight",
                   "FRI_ON": "Friday overnight", "WE_ON": "Weekend overnight", "HOL_DAY": "Holiday day",
                   "HOL_EVE": "Holiday evening", "HOL_ON": "Holiday overnight"}


def _tk(x):
    return re.sub(r"[^a-z]", "", str(x).lower().replace("mon-thu", "montothu").replace("mon thu", "montothu"))


TIME_ALIASES = {}
for _c, _n in TIME_PAGE_NAMES.items():
    TIME_ALIASES[_tk(_n)] = _c
    TIME_ALIASES[_tk(_c)] = _c
    TIME_ALIASES[_tk(CAT_LABEL[_c])] = _c
TIME_ALIASES.update({_tk("Fri evening"): "FRI_EVE", _tk("Fri overnight"): "FRI_ON", _tk("Weekday"): "WD_DAY",
                     _tk("Weekday days"): "WD_DAY", _tk("Weekend days"): "WE_DAY", _tk("Holiday"): "HOL"})


def time_code(name):
    """A shift-time name (the page's, 0.01.07's "Mon-Thu evening", or a code) -> its code; None if unknown."""
    return TIME_ALIASES.get(_tk(name))


def parse_ratings(v):
    """'B ED=8.50; Lib ED=7.00', 'Weekday day 7.00, Holiday 1.00', {"B ED": 8.5} or [["B ED", 8.5]] -> [(name, rating)]
    in the order given (unreadable items skipped)."""
    if isinstance(v, dict):
        items = list(v.items())
    elif isinstance(v, (list, tuple)):
        items = [tuple(x) for x in v if isinstance(x, (list, tuple)) and len(x) == 2]
    else:
        items = []
        for x in re.split(r"[;,]\s*", str(v or "")):
            m = re.match(r"^\s*(.+?)[\s:=]+(\d+(?:\.\d+)?)\s*$", x)
            if m:
                items.append(m.groups())
    out = []
    for k, r in items:
        try:
            out.append((str(k).strip(), round(float(r), 2)))
        except (TypeError, ValueError):
            pass
    return out


def best_first(pairs):
    return sorted(pairs, key=lambda x: -x[1])   # stable: ties keep the order given


def prefs_pairs(sites=None, times=None, tag_sites="", tag_times=""):
    """The Local Data saves for location and/or shift-time ratings, in the forms searches read (C1:87, C1:165):
    preferences/sites {site_ratings {site: r} best first, site_order [sites]} and preferences/shift-times
    {shift_time_ratings {page name: r} best first, time_order [codes]}. Names are mapped to the page's names."""
    pairs, said = [], []
    if sites is not None:
        rs = [(norm_site(k), r) for k, r in sites if norm_site(k)]
        rs = best_first(rs)
        pairs += [("site ratings", {k: r for k, r in rs}), ("site order", [k for k, _ in rs]),
                  ("site ratings tag", tag_sites or "rated")]
        said.append("location ratings best first: " + ", ".join(f"{k} {r:.2f}" for k, r in rs))
    if times is not None:
        ts = []
        for k, r in times:
            c = time_code(k)
            if c == "HOL":   # the old single Holiday rating: all three holiday times (see split_holiday)
                ts += [(h, r) for h in HOL_TIMES]
            elif c:
                ts.append((c, r))
        ts = best_first(ts)
        order = [c for c, _ in ts] + [c for c in DEFAULT_ORDER if c not in [x for x, _ in ts]]
        pairs += [("shift-time ratings", {TIME_PAGE_NAMES[c]: r for c, r in ts}), ("time order", order),
                  ("shift-time ratings tag", tag_times or "rated")]
        said.append("shift-time ratings best first: " + ", ".join(f"{TIME_PAGE_NAMES[c]} {r:.2f}" for c, r in ts))
    return pairs, said


def roster_person(name):
    people, _ = load_roster()
    hits = find_person(people, name or "")
    return hits[0] if len(hits) == 1 else None


def roster_eligible(p):
    """Eligible sites from the roster only (no schedule needed; C2:40), in the fixed site order."""
    _, sites, _, _ = p.status_on(now().date())
    return [x for x in site_order(None, p) if FACILITY_LOC(x) in sites]


def cmd_prefs(args):
    """Location and Shift Time Preferences (Setup 6). --line: save the page's pasted SHIFTMATE_PREFERENCES line whole.
    --page-data: the ELIGIBLE and SAVED lines to put in a copy of assets/preferences.html (roster only; no schedule)."""
    if args.page_data:
        p = roster_person(args.name)
        if p is None:
            print(f"NO_MATCH: '{args.name}' isn't one person on the roster; give the roster name from whoami.")
            sys.exit(2)
        print("PAGE_ELIGIBLE: const ELIGIBLE = " + json.dumps(roster_eligible(p)) + ";")
        st = ld_state() if LD_ROOT and not args.for_other else {}
        saved = {}
        sr = parse_ratings(st.get("site_ratings") or st.get("location_ratings") or st.get("location_preferences") or "")
        if sr:
            saved["sites"] = {norm_site(k): r for k, r in sr if norm_site(k)}
        tr = parse_ratings(st.get("shift_time_ratings") or st.get("shift_time_preferences") or "")
        if tr:
            saved["times"] = dict(prefs_pairs(times=tr)[0][0][1])
        print("PAGE_SAVED: const SAVED = " + (json.dumps(saved) if saved else "null") + ";"
              + ("" if saved else " (no saved ratings: leave it null)")
              + (" (only the saved list; the other starts from the starting ratings)" if len(saved) == 1 else ""))
        print_feedback()
        return
    if not LD_ROOT:
        print(LD_MISSING + ": no Local Data folder is set, so the ratings can't be saved. Stop.")
        sys.exit(3)
    line = args.line.strip()
    body = re.sub(r"^\s*SHIFTMATE_PREFERENCES\s*", "", line)
    sites = times = None
    tags = {"sites": "", "times": ""}
    ask = {}
    for part in body.split("||"):
        m = re.match(r"\s*(SITE_RATINGS|SHIFT_TIME_RATINGS)((?:\s+(?:default|no-preference|ask-next-startup))*)\s+(.*)$",
                     part.strip(), re.S)
        if not m:
            continue
        k = "sites" if m.group(1) == "SITE_RATINGS" else "times"
        tg = m.group(2).split()
        tags[k] = " ".join(tg) or "rated"
        ask[k] = "ask-next-startup" in tg
        vals = parse_ratings(m.group(3))
        if k == "sites":
            sites = vals
        else:
            times = vals
    if sites is None and times is None:
        print("ERROR: nothing saved: the line has no SITE_RATINGS or SHIFT_TIME_RATINGS list. Ask them to press Save "
              "on the page again and paste the whole line.")
        sys.exit(2)
    if sites:   # fix 3 #12: a rating for a site the clinician can't work is dropped (never saved), and said
        who = getattr(args, "clinician", None) or args.name or ld_primary_name()
        p = roster_person(who) if who else None
        if p is not None:
            elig = set(roster_eligible(p))
            drop = [norm_site(k) for k, _ in sites if norm_site(k) and norm_site(k) not in elig]
            if drop:
                sites = [(k, r) for k, r in sites if norm_site(k) not in drop]
                print("PREFS_NOT_ELIGIBLE: dropped the rating for " + ", ".join(drop) + " (not a site "
                      + ("they" if getattr(args, "clinician", None) else "you") + " can work, by the roster); "
                      "tell them in one line; nothing else changes.")
    pairs, said = prefs_pairs(sites, times, tags["sites"], tags["times"])
    if ask:
        pairs.append(("prefs ask again", {k: bool(v) for k, v in ask.items()}))
    pairs.append(("roster updates", "preferences: " + "; ".join(said)))
    if direct_save(pairs, "location and shift-time ratings (preferences/sites, preferences/shift-times), their order "
                   "for searches (site_order, time_order), and a Roster updates line"):
        for x in said:
            print("PREFS: " + x)
        print("PREFS_SAVED: list these back in one short message before the next question" +
              (" (ask-next-startup: PREFS_ASK_AGAIN comes back next startup)" if any(ask.values()) else "") + ".")
    print_feedback()


ABOUT_FIELDS = ("call", "credentials", "cell", "email", "requests", "urgent")


def cmd_aboutyou(args):
    """About You and Role Check (Setup 3): save the page's pasted SHIFTMATE_ABOUT_ROLE line whole (C1:69): About you
    (profile/about-you: roster_name, name, credentials, cell, email, contact_pref, role), changed fields (*) and
    confirmed ones in Roster updates, and the ROLE_CHECK answer. Empty fields are saved as "none"."""
    p = roster_person(args.name)
    body = re.sub(r"^\s*SHIFTMATE_ABOUT_ROLE\s*", "", args.line.strip())
    about, role = {}, None
    for part in body.split("||"):
        part = part.strip()
        if part.startswith("ABOUT_YOU"):
            txt = part[len("ABOUT_YOU"):].strip()
            for f in ABOUT_FIELDS:
                m = re.search(r"(?:^|;\s*)" + f + r"=(.*?)(?=;\s*(?:" + "|".join(ABOUT_FIELDS) + r")=|$)", txt)
                if m:
                    about[f] = m.group(1).strip()
        elif part.startswith("ROLE_CHECK"):
            role = part[len("ROLE_CHECK"):].strip()
    if not about and role is None:
        print("ERROR: nothing saved: the line has no ABOUT_YOU or ROLE_CHECK part. Ask them to press Save on the page "
              "again and paste the whole line.")
        sys.exit(2)
    rp = roster_profile(p) if p else {}
    roster_val = {"call": getattr(p, "preferred_name", "") if p else "", "credentials": rp.get("credentials", ""),
                  "cell": rp.get("cell", ""), "email": rp.get("email", ""), "requests": rp.get("contact_pref", ""),
                  "urgent": ""}
    prof, updates, changed = {}, [], []
    for f in ABOUT_FIELDS:
        if f not in about:
            continue
        v = about[f]
        star = v.endswith("*")
        v = v.rstrip("*").strip() or "none"
        about[f] = v
        if star:
            changed.append(f)
            updates.append(f"{f}: {roster_val.get(f) or 'none'} -> {v}")
    if about:
        prof = {"roster_name": p.name if p else args.name, "name": about.get("call", "none"),
                "credentials": about.get("credentials", "none"), "cell": about.get("cell", "none"),
                "email": about.get("email", "none"),
                "contact_pref": about.get("requests", "none") + (f"; urgent: {about['urgent']}" if about.get("urgent")
                                                                  else ""),
                "role": rp.get("role", "")}
        conf = [f for f in ABOUT_FIELDS if f in about and f not in changed]
        if conf:
            updates.append("confirmed: " + ", ".join(conf))
    pairs, lines = [], []
    if role is not None:
        today = f"{now():%Y-%m-%d}"
        if role.startswith("confirmed"):
            pairs.append(("role confirmed", today))
        elif role.startswith("listed-wrong"):
            items = (re.search(r"items=([^;]*)", role) or [None, ""])[1].strip()
            says = (re.search(r'says="(.*?)"', role) or [None, ""])[1]
            pairs.append(("role override", {"items": items.split("|") if items else [], "says": says, "date": today}))
            updates.append(f"role listed wrong: {items or '-'}; they say: {says} (critical, review by hand)")
            lines.append("ROLE_OVERRIDE: warn them first (setup/main.md, About You and Role Check 4), pass it as "
                         "role_override in their searches, and add a critical Roster updates item "
                         "(`fbname --item roster --text ...`).")
        elif role.startswith("permissions-change-needed"):
            pairs.append(("role confirmed", today))
            updates.append("they think their permissions should change (the listing is kept)")
        elif role.startswith("ask-next-startup"):
            pairs.append(("role confirmed", "none"))
    if updates:
        pairs.append(("roster updates", "about you: " + "; ".join(updates)))
    if demo_active():
        print("DEMO_NOT_SAVED: a demo saves nothing; go on.")
        print_feedback()
        return
    if prof:
        ld_update("profile/about-you", lambda cur: dict(cur or {}, **prof), {})
    # fix 3 #13: pasting the line again in the same chat replaces this chat's earlier About-you roster update
    mark = os.path.join(WORK, ".aboutyou-roster-update" + (("-" + SAVE_FOR.split("/")[-1]) if SAVE_FOR else ""))
    try:
        prev = open(mark, encoding="utf-8").read()
    except OSError:
        prev = ""
    new_upd = next((v for k, v in pairs if k == "roster updates"), "")
    if prev and prev != new_upd:
        rel = ld_file_for("roster updates")
        rel = (SAVE_FOR + "/" + rel) if SAVE_FOR else rel

        def drop(cur):
            cur = dict(cur or {})
            have = cur.get("roster_updates") or []
            have = [have] if isinstance(have, str) else list(have)
            cur["roster_updates"] = [x for x in have if x != prev]
            return cur
        ld_update(rel, drop, {})
    if pairs:
        save_state(pairs)
    try:
        with open(mark, "w", encoding="utf-8") as f:
            f.write(new_upd)
    except OSError:
        pass
    print("SAVED: " + ", ".join((["About you (profile/about-you)"] if prof else []) + [k for k, _ in pairs]))
    if prof:
        print("ABOUT_YOU: " + "; ".join(f"{k}: {prof[k]}" for k in ("name", "credentials", "cell", "email",
                                                                   "contact_pref"))
              + ". List these back in one short message" + (" and say the changed ones (" + ", ".join(changed) +
                                                             ") go to the maintainer in Roster updates so the roster "
                                                             "can be fixed" if changed else "") + ".")
    for x in lines:
        print(x)
    print_feedback()


def _copy_tree_files(ld_from, ld_to, rels):
    """Copy encrypted files as they are (same key: live/ and testing/ share the key-salt)."""
    n = 0
    for rel in rels:
        src = os.path.join(ld_from, *rel.split("/"))
        if os.path.isfile(src):
            dst = os.path.join(ld_to, *rel.split("/"))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            n += 1
    return n


TEST_SETTINGS_DIRS = ("profile", "preferences", "blocked-dates", "clinicians", "requests", "system/sessions")


def _settings_files(base):
    out = []
    for d in TEST_SETTINGS_DIRS:
        top = os.path.join(base, *d.split("/"))
        for r, _, fs in os.walk(top):
            for f in fs:
                if not f.startswith(".tmp-") and not f.endswith(".lock"):
                    out.append(os.path.relpath(os.path.join(r, f), base).replace(os.sep, "/"))
    return sorted(out)


def cmd_testmode_ops(args):
    """Test mode (Test mode 3, 5, 7; C4:58): --start backs up the real settings into testing/backup/ and copies them into
    testing/ for the saved-settings tests, then every command in this work folder uses testing/ (live/ is never
    changed); --clean-set N empties testing/'s settings for a clean set (a true first launch in the next chat);
    --continue --set N (in the new chat, after unlock) switches that chat to testing/; --end restores live/ from the
    backup (unless --no-restore) and switches back to live/."""
    sys.path.insert(0, HERE)
    import localdata as L
    ld_check_folder()
    root = L.check_root(LD_ROOT, walk=False)
    live, test = os.path.join(root, "live"), os.path.join(root, "testing")
    fmt_path = os.path.join(test, "system", "format.json")

    def fmt(**kw):
        try:
            d = json.load(open(fmt_path))
        except (OSError, ValueError):
            d = {}
        if kw:
            d.update(kw)
            L._atomic_write(fmt_path, json.dumps(d, indent=1).encode())
        return d
    stamp = f"{now():%Y%m%d-%H%M%S}"
    if args.start:
        files = _settings_files(live)
        bdir = os.path.join(test, "backup", stamp)
        n = _copy_tree_files(live, bdir, files)
        for rel in _settings_files(test):   # testing/ starts as a copy of the real settings
            os.unlink(os.path.join(test, *rel.split("/")))
        _copy_tree_files(live, test, files)
        os.makedirs(WORK, exist_ok=True)
        open(TEST_MARK, "w").write(json.dumps({"set": 0, "started": stamp}))
        fmt(test_mode={"active": True, "set": 0, "backup": f"testing/backup/{stamp}", "started": stamp})
        print(f"TEST_MODE_ON: {n} settings file(s) backed up to testing/backup/{stamp} and copied into testing/. From "
              "now on every command in this chat uses testing/, so the tests never change the real settings (live/). "
              "Memory: add one line, \"ShiftMate test in progress, backup in testing/backup of the Local Data folder\".")
    elif args.clean_set is not None:
        if not os.path.exists(TEST_MARK):
            print("ERROR: test mode isn't on in this chat (run `testmode --start` first).")
            sys.exit(2)
        for rel in _settings_files(test):
            os.unlink(os.path.join(test, *rel.split("/")))
        tm = dict(fmt().get("test_mode") or {}, active=True, set=args.clean_set)
        fmt(test_mode=tm)
        print(f"TEST_CLEAN_SET: testing/ settings emptied for clean set {args.clean_set} (a true first launch). The "
              f"backup stays in {tm.get('backup', 'testing/backup')}. Now remove the passphrase and Local Data memory "
              "lines (keep the backup line) and ask them to open a new chat and type \"CinciPEM ShiftMate: continue "
              f"test mode, set {args.clean_set}\".")
    elif args.cont:
        tm = fmt().get("test_mode") or {}
        if not tm.get("active"):
            print("TEST_MODE_NOT_RUNNING: no test run is in progress in this Local Data folder. Say so, and go on "
                  "with a normal startup.")
            sys.exit(2)
        os.makedirs(WORK, exist_ok=True)
        open(TEST_MARK, "w").write(json.dumps({"set": args.set, "started": tm.get("started")}))
        fmt(test_mode=dict(tm, set=args.set if args.set is not None else tm.get("set")))
        print(f"TEST_MODE_CONTINUED: set {args.set if args.set is not None else tm.get('set')}; this chat uses testing/ "
              "(a first launch there when it's a clean set). Run `startup` next; the passphrase is the tester's usual "
              "one.")
    elif args.end:
        tm = fmt().get("test_mode") or {}
        n = 0
        if not args.no_restore:
            bdir = os.path.join(root, *(tm.get("backup") or "").split("/")) if tm.get("backup") else None
            if not bdir or not os.path.isdir(bdir):
                bk = os.path.join(test, "backup")
                b = sorted(os.listdir(bk)) if os.path.isdir(bk) else []
                bdir = os.path.join(bk, b[-1]) if b else None
            if bdir:
                n = _copy_tree_files(bdir, live, _settings_files(bdir))
        try:
            os.unlink(TEST_MARK)
        except OSError:
            pass
        fmt(test_mode={"active": False, "ended": stamp})
        print(f"TEST_MODE_OFF: back to the real settings (live/); {n} file(s) restored from the backup"
              + (" (--no-restore: nothing restored)" if args.no_restore else "") + ". Put the passphrase and Local "
              "Data location back in memory, remove the backup line, and check the skill starts normally.")
    else:
        print("TEST_MODE_STATUS: " + ("on (this chat uses testing/)" if ld_mode() == "testing" else "off (live/)"))
    print_feedback()


def outbox_rel():
    return ld_chat_file("feedback/outbox")


def outbox_entries(ld):
    """[(rel, data)] for every unsent feedback file in the outbox (this chat's included)."""
    out = []
    for rel in ld.list("feedback/outbox"):
        try:
            d = ld.read(rel, None)
        except Exception:
            continue
        if d not in (None, "", [], {}):
            out.append((rel, d))
    return out


def entry_chats(rel, d):
    """The chats (runs) whose feedback an outbox entry holds: its own, plus every earlier one folded into a kept file."""
    out = {rel.rsplit("/", 1)[-1]}
    if isinstance(d, dict):
        out |= set(str(x) for x in (d.get("chats") or []))
    return out


def entry_critical(d):
    if isinstance(d, dict) and d.get("critical"):
        return True
    return feedback_has_critical(outbox_text(d))


def outbox_chats(ld):
    """(set of chats with unsent feedback in the outbox, any of it critical?) (fix 3 #2: one unit = one chat)."""
    chats, crit = set(), False
    for rel, d in outbox_entries(ld):
        chats |= entry_chats(rel, d)
        crit = crit or entry_critical(d)
    return chats, crit


def outbox_text(d):
    if isinstance(d, dict):
        return str(d.get("text") or "")
    if isinstance(d, list):
        return "\n".join(str(x) for x in d)
    return str(d)


def outbox_start(rel, d):
    if isinstance(d, dict) and d.get("start"):
        return d["start"]
    m = re.search(r"(\d{4}-\d{2}-\d{2})", rel.split("/")[-1])
    return m.group(1) if m else f"{now():%Y-%m-%d}"


COLLECTED = os.path.join(WORK, ".outbox-collected")   # what `feedback --collect` put in this chat's file


def consume_collected(ld):
    """Delete the log files (logs/feedback, logs/usage) and other chats' item entries that `feedback --collect` put in
    this chat's file, once that file is sent, downloaded or kept (so nothing is collected twice). -> log files removed."""
    try:
        rels = json.load(open(COLLECTED, encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    n = 0
    for rel in rels if isinstance(rels, list) else []:
        try:
            if ld.read(rel, None) is not None:
                ld.delete(rel)
                n += rel.startswith("logs/")
        except Exception:
            continue
    try:
        os.remove(COLLECTED)
    except OSError:
        pass
    return n


def outbox_keep(path, why=""):
    """Put a compiled feedback file in the outbox as this chat's file, with its start date (the earliest unsent), the
    chats it holds (its own plus every earlier one --collect added) and whether any of it is critical. A demo's is
    kept too, marked demo (demo.md)."""
    if not LD_ROOT:
        return
    ld = ld_open()
    mine = outbox_rel()
    text = open(path, encoding="utf-8").read()
    ents = outbox_entries(ld)
    start = min([outbox_start(r, d) for r, d in ents] + [f"{now():%Y-%m-%d}"])
    try:
        collected = set(json.load(open(COLLECTED, encoding="utf-8")))
    except (OSError, ValueError, TypeError):
        collected = set()
    absorbed = [(r, d) for r, d in ents if r != mine and (
        (isinstance(d, dict) and d.get("text") and d["text"].strip() in text) or r in collected)]
    chats = {mine.rsplit("/", 1)[-1]}
    for r, d in absorbed + [(r, d) for r, d in ents if r == mine]:
        chats |= entry_chats(r, d)
    crit = feedback_has_critical(text) or any(entry_critical(d) for _, d in absorbed)
    demo = demo_active()
    res = ld_update(mine, lambda cur: {"file": os.path.basename(path), "start": start, "text": text,
                                       "critical": crit, "chats": sorted(chats), "demo": demo}, None)
    if not res.get("ok"):
        return
    for rel, d in absorbed:   # an older file (or noted items) this one already holds leaves the outbox
        try:
            ld.delete(rel)
        except Exception:
            pass
    consume_collected(ld)
    n = len(outbox_chats(ld)[0])
    print(f"FEEDBACK_KEPT: {os.path.basename(path)} is in the Local Data outbox{why}"
          + (" (marked demo)" if demo else "") + f" ({n} run(s) with unsent feedback; unsent since {start}). It's sent "
          "or offered at a later wrap-up.")


def usage_on():
    try:
        return str(ld_state().get("usage_data") or "on").strip().lower() != "off"
    except SystemExit:
        return True


def cmd_feedback_outbox(args):
    """--keep FILE: a compiled feedback file kept for later (Save it for later; Auto-send off and not due; a failed send)
    goes into the outbox as this chat's file, with its start date. --collect FILE: at Collect (Wrap-up 4), add every older
    unsent file to the end of FILE and print the noted items (OUTBOX_ITEM), the kept FEEDBACK: lines (OUTBOX_FEEDBACK)
    and, with Auto-send on, the kept usage rows (OUTBOX_USAGE), so the one file holds everything unsent (fix 3 #5)."""
    if not LD_ROOT:
        print("ERROR: the feedback outbox is in Local Data; no Local Data folder is set. " + LD_MISSING)
        sys.exit(3)
    ld = ld_open()
    mine = outbox_rel()
    ents = outbox_entries(ld)
    if args.keep:
        outbox_keep(args.keep)
        print_feedback()
        return
    # --collect
    path = args.collect
    older = [(r, d) for r, d in ents if r != mine and isinstance(d, dict) and d.get("text")]
    items = [(r, d) for r, d in ents if not (isinstance(d, dict) and d.get("text"))]
    add = ""
    for r, d in older:
        body = d["text"]
        if body.strip() and body.strip() not in open(path, encoding="utf-8").read():
            add += f"\n\n## Earlier unsent feedback (kept {outbox_start(r, d)}, {d.get('file', '')})\n\n{body.strip()}\n"
    if add:
        open(path, "a", encoding="utf-8").write(add)
    starts = [outbox_start(r, d) for r, d in ents]
    for r, d in items:
        for x in (d if isinstance(d, list) else [outbox_text(d)]):
            print(f"OUTBOX_ITEM: {x}")
    collected = [r for r, _ in items if r != mine]   # other chats' noted items: absorbed when this file is kept
    fb, seen = 0, set()
    for rel in ld.list("logs/feedback"):
        lines = as_list(ld.read(rel, []))
        for x in lines:
            if str(x) not in seen:
                seen.add(str(x))
                print(f"OUTBOX_FEEDBACK: {x}")
                fb += 1
        collected.append(rel)
    on = usage_on()
    rows = 0
    for rel in ld.list("logs/usage"):
        lines = as_list(ld.read(rel, []))
        if on:
            for x in lines:
                print(f"OUTBOX_USAGE: {x}")
            collected.append(rel)
        rows += len(lines)
    try:
        json.dump(collected, open(COLLECTED, "w", encoding="utf-8"))
    except OSError:
        pass
    print(f"OUTBOX_COLLECTED: {len(older)} earlier unsent file(s) added to the end of {os.path.basename(path)}; "
          f"{sum(len(d) if isinstance(d, list) else 1 for _, d in items)} item(s) noted during chats (OUTBOX_ITEM, put "
          f"each in its section with its ITEM_ID); {fb} FEEDBACK: line(s) (OUTBOX_FEEDBACK, in the automatic feedback); "
          + (f"{rows} usage row(s) (OUTBOX_USAGE, in the Usage data section)" if on else
             f"{rows} usage row(s) left out (Auto-send off: they stay in Local Data)")
          + ". OUTBOX_START: " + (min(starts) if starts else f"{now():%Y-%m-%d}") + " (the date for the Download warning).")
    print_feedback()

def main():
    if hasattr(signal, "SIGPIPE"):
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--local-data", help="the Local Data folder (or env SHIFTMATE_LOCAL_DATA)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    mm = sub.add_parser("migrate-memory")
    mm.add_argument("--memory", required=True, help="the 0.01.07 memory block (text or JSON, or a file holding it)")
    b = sub.add_parser("banner")
    b.add_argument("--installed", help="install date (YYYY-MM-DD); default: from Local Data's format.json, else today")
    b.add_argument("--docs", help=argparse.SUPPRESS)       # tests: folder with CHANGELOG/BETA
    for x in ("--name", "--credentials", "--role"):   # ignored since 2.1: the banner shows nothing personal
        b.add_argument(x, help=argparse.SUPPRESS)
    b.add_argument("--channel", help=argparse.SUPPRESS)   # ignored: the channel comes from the version number
    o = sub.add_parser("outlook")
    o.add_argument("--req", required=True)
    w = sub.add_parser("whatsnew")
    w.add_argument("--from", dest="frm", required=True)
    w.add_argument("--to")
    w.add_argument("--channel", default="stable", choices=["stable", "beta", "alpha"])
    w.add_argument("--folder", help="where CHANGELOG.md and BETA.md are (default: the skill folder)")
    up = sub.add_parser("update")
    g = up.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--download", choices=["stable", "beta", "alpha"])
    up.add_argument("--installed", default=VERSION)
    up.add_argument("--beta-program", choices=["in", "alpha", "never joined", "opted out"])
    up.add_argument("--last-beta-asked", help="from memory: the last beta they were asked about")
    up.add_argument("--never-ask-beta", action="store_true", help="from memory: they chose 'Never ask me again'")
    up.add_argument("--channel", help=argparse.SUPPRESS)   # ignored: the channel comes from the version number
    up.add_argument("--manifest", help="versions.json URL or file (default: the public repo)")
    up.add_argument("--out", help="folder for the downloaded .skill file")
    up.add_argument("--join", choices=["yes", "no"], default="yes",
                    help="with --download beta: 'no' installs it without joining the beta program (Yes, update this time)")
    su = sub.add_parser("startup")
    su.add_argument("--state", help=argparse.SUPPRESS)   # tests only: settings JSON instead of Local Data
    su.add_argument("--manifest", help=argparse.SUPPRESS)   # tests: a local versions.json
    su.add_argument("--docs", help=argparse.SUPPRESS)       # tests: folder with CHANGELOG/BETA/thankyou
    u = sub.add_parser("unlock")
    u.add_argument("--passphrase", help="the skill passphrase (or set SHIFTSWAP_PASSPHRASE)")
    u.add_argument("--stdin", action="store_true", help="read the passphrase from standard input")
    u.add_argument("--tries-used", type=int, default=0, help=argparse.SUPPRESS)   # tests without Local Data only
    u.add_argument("--locked-until", help=argparse.SUPPRESS)                      # (Local Data: lockout.json)
    u.add_argument("--old-tried", action="store_true", help=argparse.SUPPRESS)
    nl = sub.add_parser("newlink")
    nl.add_argument("--url", required=True)
    nl.add_argument("--last", required=True, help="last name of the person who made the link")
    nl.add_argument("--first", required=True)
    nl.add_argument("--keep", action="store_true", help="use a schedule with problems for this session anyway")
    fbk = sub.add_parser("feedback")
    fg = fbk.add_mutually_exclusive_group(required=True)
    fg.add_argument("--submit", help="scrub, encrypt and send the filled-in feedback file")
    fg.add_argument("--prepare", help="only scrub the file (before offering a download or saving it)")
    fg.add_argument("--clear", action="store_true", help="after a download: move the outbox to feedback/sent")
    fg.add_argument("--keep", help="keep a compiled feedback file in the Local Data outbox (Save it for later, not due, failed send)")
    fg.add_argument("--collect", help="Collect (Wrap-up 4): add older unsent files to this file; print this chat's noted items")
    fg.add_argument("--due", action="store_true", help="Auto-send off: is a reminder due? (unsent files a multiple of 3, or any critical)")
    fbk.add_argument("--dry-run", action="store_true")
    for c in ("refresh", "whoami", "shifts", "avail", "swap", "locswitch", "mlpickup", "contacts"):
        p = sub.add_parser(c)
        if c == "refresh":
            p.add_argument("--links", help="the user's links from memory: JSON list of {id, url, works}")
        p.add_argument("--ics", help="attached ShiftAdmin calendar file")
        if c in ("shifts", "avail", "swap", "locswitch", "mlpickup"):
            p.add_argument("--req", required=c != "mlpickup")
        if c == "whoami":
            p.add_argument("--name", required=True)
            p.add_argument("--setup", action="store_true", help="first-setup name check (roster + admins, 3 tries)")
            p.add_argument("--tries-used", type=int, default=0, help=argparse.SUPPRESS)   # tests without Local Data
        if c == "mlpickup":
            p.add_argument("--xls", required=True)
            p.add_argument("--file-date", action="store_true", help="only say the Available Shifts file's date (PM 1)")
        if c == "contacts":
            p.add_argument("--names", required=True)
    add_more_parsers(sub)
    a = ap.parse_args()
    global LD_ROOT
    LD_ROOT = a.local_data or LD_ROOT
    if a.cmd in LD_STATE_CMDS and not LD_ROOT and not getattr(a, "state", None):
        print(LD_MISSING + ": no Local Data folder is set, so there are no saved settings to use. Stop.")
        sys.exit(3)
    if a.cmd not in NO_UNLOCK:
        require_unlocked()
    require_startup(a.cmd)
    if a.cmd == "startup" and not a.demo:
        shutil.rmtree(DEMO_DIR, ignore_errors=True)   # a normal launch ends any demo left in this work area
    if LD_ROOT and a.cmd not in NO_UNLOCK and not getattr(a, "state", None):   # banner & co. run before the key exists
        ld_open()
        sys.stdout = _LDOut(sys.stdout)
        import atexit
        atexit.register(sys.stdout.flush)
    if demo_active():
        sys.stdout = _DemoOut(sys.stdout)
        import atexit
        atexit.register(sys.stdout.flush)
    if getattr(a, "step", None):
        import atexit
        import time
        atexit.register(step_usage, a.cmd, a.step, time.perf_counter(), time.process_time())
    if getattr(a, "clinician", None) and a.cmd in ("save", "prefs"):
        global SAVE_FOR
        SAVE_FOR = ld_clinician_dir(a.clinician)
    if a.cmd == "migrate-memory":
        return cmd_migrate_memory(a)
    if a.cmd in ("save", "settings"):
        return {"save": cmd_save, "settings": cmd_settings}[a.cmd](a)
    if a.cmd in MORE_COMMANDS:
        return MORE_COMMANDS[a.cmd](a)
    {"unlock": cmd_unlock, "banner": cmd_banner, "outlook": cmd_outlook, "whatsnew": cmd_whatsnew,
     "update": cmd_update, "startup": cmd_startup, "newlink": cmd_newlink, "feedback": cmd_feedback, "refresh": cmd_refresh, "whoami": cmd_whoami, "shifts": cmd_shifts, "avail": cmd_avail, "swap": cmd_swap,
     "locswitch": cmd_locswitch, "mlpickup": cmd_mlpickup, "contacts": cmd_contacts}[a.cmd](a)


if __name__ == "__main__":
    main()
