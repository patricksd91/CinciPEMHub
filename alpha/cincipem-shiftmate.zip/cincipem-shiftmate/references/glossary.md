# CinciPEM ShiftMate: glossary

**Version:** 0.01.08

Plain-language meanings of the division's terms. Check here before asking a user what a term means. Use these exact definitions when explaining. A term that isn't here and isn't a shift code: ask the user what they mean once, use their meaning, save it to memory under "Terms I've learned", and add it to the feedback's "New terms" section.

## Sites and places
- **B ED:** the Burnet (main campus) emergency department. ShiftAdmin writes it "B". Also called Base or Burnet.
- **Lib ED:** the Liberty campus emergency department. ShiftAdmin writes it "LT" or "Lib".
- **BUC:** the urgent care at Burnet. **LT UC:** the urgent care at Liberty. Together they're the **HBUC** (hospital-based urgent cares).
- **OPE, OPM, OPKY, OPGT:** the outpatient (neighborhood) urgent cares at Eastgate (also called Anderson), Mason, Kentucky (Crestview Hills) and Green Township. Together they're the **NUC**s.
- **UC:** any urgent care (HBUC plus NUC).
- **VUC:** Virtual Urgent Care, for NPs and PAs only.

## Kinds of shifts
- **Jeopardy:** backup call. It trades only for another Jeopardy shift, unless the person giving it up agrees to take a scheduled shift instead.
- **ML (moonlighting):** extra paid shifts beyond someone's regular schedule. ML shifts trade only for ML shifts, or can be given away.
- **M3:** a physician-only ED shift (clinical level and up). In Pickup Moonlighting it may be taken with less than 8 hours' rest if it ends before your next shift.
- **Buddy shift:** a shift that can't be traded without the admins' permission.
- **Split shift:** a shift worked in two parts; each part is treated as its own shift.
- **Holiday / pre-scheduled peri-holiday:** holiday shifts fall on the division's holidays; peri-holiday shifts are the days just around a holiday that are pre-scheduled on the division's holiday calendar. Holiday shifts are left out of searches unless the user includes them.
- **AOC / AOS:** administrator on call; ignored by the skill.

## Shift time and shift type
- **Shift time:** when a shift happens. There are 11: weekday day, Mon–Thu evening, Friday evening, weekend day, weekend evening, Mon–Thu overnight, Friday overnight, weekend overnight, holiday day, holiday evening, holiday overnight. "Holiday" alone means all three holiday times. Day shifts start 5:30 am to 3:59 pm, evening shifts 4:00 to 9:59 pm, and overnights 10:00 pm to 5:29 am. An overnight that starts after midnight counts as part of the night before.
- **Shift type:** the staff level a shift is for (Faculty, Clinical, Senior Clinical, NP/APP and so on). ShiftAdmin calls this "Shift Type." Don't use "shift type" for shift times.
- **Everyday words:** "weekends" = weekend day, weekend evening and weekend overnight; "evenings" = Mon–Thu evening, Friday evening and weekend evening; "nights" or "overnights" = the three overnight shift times; "days" = weekday day and weekend day.
- **Shift levels** (who a shift is for): F (faculty), C* (senior clinical), C (clinical), E (NP, APP and other non-faculty clinical shifts), SrAPP (senior APP shifts at LT UC).
- **Role and permissions:** a person's role on the roster (Faculty, Senior Clinical Staff, Clinical Staff, Senior APP, APP, Fellow by year) and the permissions that decide what they can work: F (faculty), CL\* (senior clinical), CL (clinical), APP\* (senior APP), APP, and fellows by year. Most people have their role's standard permissions ("Standard Clinical Staff permissions"); a few have exceptions, which the role check lists.
- **Jeopardy pools:** Jeop F, Jeop CL and Jeop APP: which Jeopardy shifts someone covers.

## Workflows
- **Trade Shifts (TS):** finding trades for one of your shifts, including giving away or trading an ML shift. **Swap Locations (SL):** moving a shift to a site you prefer, same day. **Pickup Moonlighting (PM):** finding open moonlighting shifts you can pick up.
- **Coming soon:** **Call Off Helper (COH)**, finding someone to take a shift at the last minute; **Schedule Inquiry and Planning (SIP)**, schedule questions and planning for administrators.
- **Step labels:** each step has a name and a number, name first: "Availability (Trade Shifts 3)". The name stays; the number can change.
- **Administrator mode:** running the skill for the clinicians you help. People who are both administrators and clinicians choose their role at each start.

## Trades
- **Trade categories A–F:** how good a trade is. A Win-win (better for both of you), B Even 1:1 (the same kind of shift both ways), C Colleague gains (better for your colleague), D Colleague even (about the same for your colleague), E Colleague loses (worse for your colleague), F Lose-lose (worse for both).
- **1:1:** an even trade: the same kind of shift (same shift time) both ways.
- **Tier 1–9:** a finer rank of how an option lands for you and for your colleague (lower is better). Categories C, D and E each hold two tiers; results are grouped under a heading for each.
- **Back-to-back:** two shifts with an hour or less between them, allowed up to 12 h 15 min in a row, the most the division allows. Setup asks whether you'd like them (Back-to-back shifts, Setup 7): **No** leaves them out; **Yes, but only if I ask for it** includes them in your own searches, but colleagues can't be offered trades that give you one; **Yes, and let others ask me** does both.
- **Rest rule:** at least 8 hours off between shifts. **Days in a row:** no more than 7.
- **Swap Locations:** trading a shift for a same-day shift at a site you prefer.

## Your settings
- **(default):** the skill's standard choice. **(your usual):** the search settings you chose to keep. **Your most recent:** the settings of your last search. Each workflow has its own.
- **Summary mode:** all your saved settings shown at once, instead of one question at a time (**step-by-step**).
- **Location preferences / shift-time preferences:** your ratings of sites or shift times, each from 1 to 9 (1 strongly prefer not, 3 prefer not, 5 neutral, 7 prefer, 9 strongly prefer), no two the same; the order follows the ratings. It's a ratio scale: an 8 counts twice as much as a 4.
- **Beta program:** getting new versions early, before everyone else. They may not work perfectly. **Alpha:** an early preview before a beta, for a few testers (0.01.08 is one); alpha testers are treated like beta testers.
- **Demo mode:** a quick showing of the skill with default settings; nothing is saved. **Test mode:** a version's testing program, for beta and alpha testers on beta and alpha builds (and the maintainers).
- **Help levels:** Walk me through everything, Standard, I'm an advanced user.
- **Usage data:** how you use the skill (which features, search settings and result counts), sent encrypted so only the maintainer can read it.

## ShiftAdmin
- **Schedule link:** the ShiftAdmin link the skill reads the division's schedule from.
- **Available Shifts file:** the Excel download of open shifts (ShiftAdmin → Schedule → Available Shifts → Excel version), used for Pickup Moonlighting.
