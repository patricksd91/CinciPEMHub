# CinciPEM ShiftMate: loading lines

**Version:** 0.01.08

Funny, work-appropriate lines for waits expected to take more than 5 seconds (plan 6.7). The script (`wait`) picks one at random, never the same one twice in a row, and never with an error or failure message. One line per bullet; the build's rotation record lists which build shipped each.

- Triaging your request. You're an ESI 3: important, but please have a seat.
- Paging the schedule. It's on the phone with radiology; please hold.
- Checking whether anyone actually likes Friday overnights. Still checking.
- Counting to 12 hours 15 minutes. Twice, to be safe.
- Consulting the scheduling gods. They'd like a formal consult note.
- Running a full set of vitals on your settings. Pressure looks good.
- Asking the charge nurse. She says "it depends."
- Negotiating with the holiday calendar. It's playing hard to get.
- Rebooting the Pyxis. Just kidding. Mostly.
- Waiting for the schedule to finish its coffee.
- Compiling a differential diagnosis for your shift. Leading candidate: Tuesday.
- Putting on lead. This part of the schedule is radioactive.
- Checking in with the moonlighters. They're somewhere between BUC and OPKY.
- Loading faster than a Thursday night fast track. Probably.
- Consulting UpToDate on shift swaps. There's surprisingly little literature.
- Our computer is doing a quick sepsis screen. Your schedule is afebrile.
- Running this by the attending. The attending is also a computer.
- Double-checking the rest rules, because nobody wants a 7 a.m. after a 3 a.m.
- Hold please. The fax machine is warming up. (We don't use the fax machine.)
- Re-dosing the algorithm with caffeine.
- Reading every shift like it's a 2 a.m. EKG: slowly and twice.
- Counting overnights on our fingers. And toes.
- Finding the one person who wants your holiday shift. It's a big roster.
- Calibrating the pulse ox on your preferences.
- Hang tight. This is going better than the last EHR upgrade.
- Splinting the spreadsheet. It had a minor sprain.
- Giving the schedule a gentle lumbar puncture. Clear so far.
- Rounding on every site. Lib ED says hi.
- Checking the board. Your request is next in line after the kid with the bead in his nose.
- Rolling the schedule into CT. Contrast not needed.
