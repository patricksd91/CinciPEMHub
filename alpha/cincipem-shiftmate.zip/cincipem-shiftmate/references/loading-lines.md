# CinciPEM ShiftMate: loading lines

**Version:** 0.01.82

Funny, work-appropriate lines for waits expected to take more than 5 seconds (plan 6.7). The script (`wait`) picks one at random, never the same one twice in a row, and never with an error or failure message. One line per bullet; the build's rotation record lists which build shipped each.

- Triaging your request. You're an ESI 3: important, but please have a seat.
- Paging the schedule. It's on the phone with radiology; please hold.
- Checking whether anyone actually likes Friday overnights. Still checking.
- Counting to 12 hours 15 minutes. Twice, to be safe.
- Consulting the scheduling gods. They'd like a formal consult note.
- Running a full set of vitals on your settings. Pressure looks good.
- Asking the charge nurse. She says "it depends."
- Negotiating with the holiday calendar. It's playing hard to get.
- Rebooting the Pyxis. Just kidding. Mostly.
- Waiting for the schedule to finish its coffee.
- Compiling a differential diagnosis for your shift. Leading candidate: Tuesday.
- Putting on lead. This part of the schedule is radioactive.
- Checking in with the moonlighters. They're somewhere between BUC and OPKY.
- Loading faster than a Thursday night fast track. Probably.
- Consulting UpToDate on shift swaps. There's surprisingly little literature.
- Doing a quick secondary survey of the schedule. No new findings.
- Weighing your request in kilograms, like we're supposed to.
- Asking the schedule to rate its pain from 1 to 10. It said "Tuesday."
- Getting a second opinion from the calendar. It agrees with the first one.
- Checking capillary refill on your settings. Under two seconds.
- Double-checking the decimal point, the way we do with every dose.
- Offering the schedule a popsicle so it holds still.
- Measuring your request with the length-based tape. It's in the green zone.
- Waiting for the schedule to come back from X-ray. It stopped at the vending machine.
- Reassessing after the intervention. Everything still looks stable.
- Handing off to the next step. SBAR complete.
- Discharging the old schedule with return precautions.
- Checking the whiteboard. Someone drew a very nice dinosaur on it.
- Clearing the calendar's C-spine. No midline tenderness.
- Distracting the schedule with bubbles while we look in its ears.
