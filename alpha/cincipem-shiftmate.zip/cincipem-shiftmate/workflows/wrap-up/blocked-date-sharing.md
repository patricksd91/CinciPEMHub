# Wrap-up: Blocked-date sharing (Wrap-up 2)

**Version:** 0.01.82

Read at Blocked-date sharing (Wrap-up 2), only for the primary user's own dates. Never in administrator mode or when the run was for someone else: blocked dates given for another person stay in that clinician's Local Data files and are never sent to update the roster.

## Is there anything to share?
- Run `myblocks --name "<their roster name>"`. `MYBLOCKS:` lists what the roster has in its three columns (blocked dates, recurring blocks, and dates they can work despite a recurring block or vacation) and their upcoming ShiftAdmin vacation days.
- Compare it with the blocks and vacation exceptions saved in their Local Data. Only differences can be shared. No differences: skip to Your own feedback (Wrap-up 3) and say nothing.

Keys (Local Data, saved with `save`): `blocked dates sharing` (`in`, `no` or `not asked`), `blocked dates shared` (what was sent), `counters: blocked_dates_share` and `never ask: blocked_dates_share` (the ask schedule, from `askdue`).

## Already in the sharing program (`blocked dates sharing: in`)
- Don't ask. Add the differences to the Blocked dates section of the feedback file. Send (Wrap-up 5) lists them in its summary, so they can edit or remove one before it goes.

## Should we ask?
- Run `askdue` with no inputs: the script reads them from Local Data itself (`--uses`: the number in `counters: blocked_dates_share N`, uses since the last ask; `--asked`: `blocked_dates_share asks`, times asked so far; `--never`: `never ask` lists `blocked_dates_share`). Give them only to override what's saved. `ASK_DUE: yes`: ask; `ASK_DUE: no`: go on. The script saves the counters itself (after a no: ask again after 2 more uses, then 3, then 4, then 5, then every 5 uses).
- They can opt in or out any time by asking. If they say not to ask again, `save "never ask: blocked_dates_share"`.

## The ask
- "Would you like to share your blocked dates and any updates to your vacation schedule in the next version, so colleagues can accurately see when you are not available? Only the dates and shift times you block off are shared, never what they're for." **Yes, show me what I'd share** / **No**.
- **No:** `save "blocked dates sharing: no"` and go on.

## Yes, show me what I'd share
- Show what the roster has now, then what would be added, changed or removed, in the three columns.
- Show their upcoming ShiftAdmin vacation days. Say these come from ShiftAdmin and only the schedulers can change them, but they can say they're actually free on a date (it goes in the third column).
- **A block or exception for only one shift time:** already confirmed when it was entered (Setup 8, or blocks.md in a search), so don't ask about it again. Only a new or edited one gets the one-shift-time question from `workflows/trade-shifts/blocks.md`. (A vacation-day exception that names one shift time frees only that shift time; "all" or no time frees the whole day.)
- Let them edit. The lists they see are the one confirmation: ask once, "Share these?" **Share these** / **Don't share**. No other confirmation. **Don't share:** as **No** above.
- On Share these: `save "blocked dates sharing: in"` (they're never asked again). Put the confirmed lists in the Blocked dates section of the feedback file; it's a critical item. Save what was sent with `save --key "blocked dates shared" --value '<the shared blocks, as the JSON list>'`, so later sends include only new changes.
- When their saved blocks and the roster disagree later, the roster may not have caught up yet: startup's `BLOCKS_ROSTER_DIFF` leaves out anything in `blocked dates shared`, so it isn't raised again. If the roster still differs after the next version, flag it in feedback as a pipeline problem instead of asking again.
