# Wrap-up (the Feedback workflow)

**Version:** 0.01.82

Read when a workflow ends, the user is done, or they say "stop" or "bye". These are the Feedback workflow's steps, in the order of the Wrap-up and Feedback diagram. Refer to each step by its name first, then its number.

**Where unsent feedback lives in 0.01.08:** in the Local Data outbox (feedback/outbox), one file per chat (one run of the skill); the script keeps it. With Auto-send usage data and feedback on, it's sent at the end of every run, so the maintainer's feedback review is always up to date. With it off, the user is reminded to send it or download and email it when the number of runs (chats) with unsent feedback, this one included, is a multiple of 3, or when any unsent item is critical (a kept file remembers every earlier run folded into it, so the count doesn't depend on how the files were combined) (`feedback --due`, Send, Wrap-up 5).

## Feedback at any time (6.8)
- Any time in any workflow, phrases like "tell <feedback_name> that…", "let <feedback_name> know…", "tell the developer (or maintainer)…", "note for <feedback_name>…", "feedback: …", or anything clearly meant for the maintainer, are feedback. So is a mistake they call out or a result they correct. <feedback_name> is in SKILL_SENSITIVE.md.
- (The short form of this rule is in SKILL.md, Feedback at any time, so it works mid-flow.)
- **Normally:** run `fbname --last <primary user's last name> --first <first name> --item <category> --text "<the item, word for word, sensitive details left out>"`; the script saves it with its `ITEM_ID` in this chat's Local Data outbox (so it isn't lost if the chat stops early). Say one line: "Got it, I'll pass that on at the end." When startup printed `MAINTAINER` (they are the maintainer): "Got it, I'll add that to your feedback." Walk-me-through users also hear when: "…at the end, when we send your feedback." Then ask again the question you were waiting on. Don't start the Feedback step now.
- **Only if they clearly want it sent now** ("send this now"): go to Collect (Wrap-up 4), then offer to pick up the workflow where it stopped.
- **A bug that blocks them** (they can't get past a step): say so in one line and offer **Send feedback now** / **Keep going**. Send feedback now: Collect (Wrap-up 4) and Send (Wrap-up 5) with the bug marked critical, then offer to pick up the workflow where it stopped.

## Anything else? (Wrap-up 1)
- Save what this run used: `save "features used: <feature keys from the Features table used so far, comma-separated, with this run's added>; last searches: <workflow> <today's date>"` (the intro's highlight reads `features used`; `settings` shows both).
- Ask: "Anything else?" **Another search** / **I'm done**.
- **Another search:** back to Which workflow (the menu in SKILL.md). Administrators: Which workflow (Administrator 3).
- **I'm done:** go on to Blocked-date sharing (Wrap-up 2).
- **"Stop" or "bye" in the middle of a workflow:** read `workflows/wrap-up/close-after-stop.md`.

## Blocked-date sharing (Wrap-up 2)
- Skip it in administrator mode and when the run was for someone else. It's only for the primary user's own dates.
- Otherwise read `workflows/wrap-up/blocked-date-sharing.md`.

## Your own feedback (Wrap-up 3)
- Skip it if they already said they have no feedback this chat.
- **Maintainer:** when startup printed `MAINTAINER`, don't name <feedback_name> or ask whether to pass anything on to them: ask "Any feedback of your own for this run: a bug, something slow, or a wish?" and record it as theirs.
- **Auto-send usage data and feedback on:** ask once: "Anything you'd like me to pass on to <feedback_name>: a bug, something slow, or a wish?"
- **Off, and something was collected:** "This skill has some automatic feedback about <X> that can help improve future versions. Please tell me any feedback of your own to add first (bugs, performance, or a feature wish list)."
- **Off, and nothing was collected:** ask whether they'd like to give any feedback.
- Record their words exactly, each with an item ID from `fbname --item`, except: first remove any password, passphrase, username or other sensitive information (patient information, account numbers), and say in one line that you left it out. Never write those into the file, even "exactly" (the privacy check is a second net, not the first).

## Collect (Wrap-up 4)
- **The file:** run `fbname --last <primary user's last name> --first <first name> --dir <the folder it goes in>` (`--dir` lets the script skip a name already in that folder: `_2`, `_3`). It prints `FEEDBACK_FILE: YYYYMMDDHHMM_<LLL><FFF>_feedback.md`. Use the primary user's name even when the run was for someone else. Fill in `templates/feedback.md` under that name, in the work folder (way A: the folder `shiftmate_info` names; way B: the temp work folder), then run `feedback --collect <file>`: the script adds every older unsent file from the outbox to its end (under "Earlier unsent feedback") and prints the `OUTBOX_ITEM` lines (the items noted with `fbname --item --text`), the `OUTBOX_FEEDBACK` lines (every `FEEDBACK:` line the script kept), the `OUTBOX_USAGE` rows (the usage rows kept in Local Data; only with Auto-send on, since off leaves them out of anything sent or downloaded) and `OUTBOX_START` (the earliest unsent date). Put each `OUTBOX_ITEM` in its section with its ID, the `OUTBOX_FEEDBACK` lines in the automatic feedback, and the `OUTBOX_USAGE` rows in Usage data. Once the file is sent, downloaded (`feedback --clear`) or kept (`feedback --keep`), the script clears what it collected, so nothing is collected twice.
- **What goes in:** everything saved this chat plus everything in the Local Data outbox. That is: their own feedback and "tell <feedback_name>" items; every `FEEDBACK:` line; mistakes they called out or results they corrected; bugs or workflow ideas you noticed; complaints about other systems (ShiftAdmin, Outlook); lessons (what confused them or took extra turns); roster updates; confirmed blocked-date changes; new terms; system health; and the usage lines.
- **Item IDs:** every item starts with its `ITEM_ID` (made by `fbname --item bug|request|roster|schedule|term|lesson|health|usage` when it was first tagged). Items merged from several reports keep the earliest ID.
- **Usage data (8.3):** at the end of each workflow run, finished or stopped (a workflow started but stopped before its results gets a row too), run `usage --workflow "<name>" --turns N --read-chars N --written-chars N --script-ms <sum of its USAGE_STEP times> --model "<model>" --model-source user|self-reported --plan "<plan>"`. Add `--limit-hit "<step>"` if a usage limit was hit or mentioned, and `--decrypt-lib`/`--decrypt-ms` once per chat. Put each `USAGE_ROW:` in the Usage data section. Usage lines are always collected. With Auto-send usage data and feedback off, leave the Usage data section out of anything sent or downloaded, and keep the rows in the Local Data outbox.
- **Critical items:** a crash, an error, a feature that doesn't work, a role override, "don't name me", a schedule update they share (blocked dates or vacation changes), a failed automatic send, and a bug that stops them from going on. Mark each one **Critical** after its ID. Critical items are never merged or dropped.
- **Only what's needed to fix each item.** Never anyone's full schedule or personal conflicts. No colleagues' names in usage data or lessons.
- **Privacy check:** before any send, download or save (including Save it for later), run `feedback --prepare <file>` (`--submit` also does it). `SCRUBBED`: tell them in one line what kind of thing was removed and why, never repeating it. `SCRUB_OK`: say nothing.

## Send (Wrap-up 5)
- **Auto-send on or off** is the user's `usage data` setting (on by default); it counts as on only when `unlock` printed `AUTO_FEEDBACK: available` (see SKILL.md, Unlocking).
- **Auto-send usage data and feedback on:** at the end of every run, run `feedback --submit <file>` without asking (the file holds this run's feedback and everything older still in the outbox, as What goes in says; after it's sent the script empties the outbox: `OUTBOX_CLEARED`). Don't run `feedback --due`, and don't describe the sending, except as in About sending below.
- **Off:** run `feedback --due`. `FEEDBACK_SEND_DUE: no`: don't remind them; run `feedback --keep <file>` so the file waits in the outbox (`FEEDBACK_KEPT`), and say nothing about it (walk-me-through users: one line, "I'll keep your feedback with the others until it's time to send it."). If they ask to send, it's always fine: go on below. Not reminding isn't a beta warning. `FEEDBACK_SEND_DUE: yes` (the runs with unsent feedback are a multiple of 3, or an unsent item is critical; then recommend sending now): remind them and ask how to send it: **Send it automatically** / **Download it** / **Save it for later**. Leave out the first only if `unlock` printed `AUTO_FEEDBACK: not set up`, and say why.
- **Critical items:** recommend sending now, or downloading and emailing it if they'd rather.
- **Size:** a send too big for one inbox item is split by the script into numbered parts of up to 45,000 characters each (`FEEDBACK_SENT: ... in N numbered parts`); nothing to do or say about it beyond "sent". Nothing is dropped to make room.
- **Outbox (6.2):** new items go at the end; never rewrite older ones unless a new report conflicts with one. Merge repeated automatic lines into counts ("attached the schedule file ×4"), but never critical items.
- **About sending:** walk-me-through users every time, and standard users while `about sending shown` is no (then save yes): "Your feedback is encrypted on this computer before it leaves, then sent privately through GitHub, the site that hosts this skill and its feedback tool. Only <feedback_name> can unlock and read it. No one else, including GitHub, can see what's in it, and I remove anything that looks like patient information, usernames or passwords first." Everyone else: "Sent encrypted and privately through GitHub. Only <feedback_name> can read it." If asked how: public-key encryption, and a private repository that holds only the encrypted file.
- **Blocked dates:** if they're in the sharing program, list the blocked-date changes being sent in one short summary before sending, so they can edit or remove one.
- **Beta and alpha testers:** when they decline to send feedback that exists (not sending, or Save it for later), or already have 3 warnings, read `workflows/wrap-up/beta-warnings.md`.

## Result (Wrap-up 6)
- **`FEEDBACK_SENT`:** thank them (in several numbered parts, it's still one send). The script has emptied the outbox (`OUTBOX_CLEARED`, moved to feedback/sent) and reset `feedback warnings` and `failed sends` to 0 itself (`SAVED`); log the send in system health. If About you, a roster field or a preference list changed this run, say it will be in a future roster update.
- **`TOKEN_REFUSED`, `FEEDBACK_FAILED`, `FEEDBACK_PARTIAL` or `FEEDBACK_UNAVAILABLE`:** read `workflows/wrap-up/failed-send.md`.
- **Download:** give `feedback_email` from SKILL_SENSITIVE.md. The start date is `OUTBOX_START` from `feedback --collect`. Offer the file as a download in the chat (the app's file card), from the work folder; never copy it into the Local Data folder by hand. After they've downloaded it, run `feedback --clear` (the script moves the outbox to feedback/sent and resets `feedback warnings` to 0). Say: "If you don't send this file, all feedback since <that date, or your install date> will be lost."
- **Save it for later:** run `feedback --keep <file>` (after `feedback --prepare`): the file goes in the outbox with its start date (`FEEDBACK_KEPT`). It comes up at the next wrap-up (`feedback --collect` adds it to that run's file). Keep "don't name me" with it until it's sent.

## Close (Wrap-up 8)
(There is no Wrap-up 7 any more; the other steps keep their numbers.)
- Say: "This instance of CinciPEM ShiftMate is closed. To use it again, start a new chat and ask for it. Closing (or deleting) old chats and starting new ones means you hit your usage limit less fast."
- Run `session --close <this chat's SESSION_ID>` (plan 2.8). The script moves this chat's session note to closed, so other chats don't count it as open; `SESSION_CLOSED` confirms it.
- **After 1 hour with no reply, once the Feedback step has started:** with Auto-send usage data and feedback on, send what was collected; otherwise `feedback --keep` it in the Local Data outbox. Then close. (Claude only notices the hour when the user next writes; handle it then, before anything else.)
- **Asked something later in this chat:** suggest a new chat, since it's faster and old results can't mix in. If they'd rather stay, run a full startup again (unlock and startup, as a new launch).
