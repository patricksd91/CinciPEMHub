# Wrap-up: "Stop" or "bye" mid-workflow (Anything else?, Wrap-up 1)

**Version:** 0.01.08

Read when the user says "stop", "bye", "never mind" or the like before a workflow is done, and when `session` prints `CHAT_CLOSED` (last section).

- Ask in one line: "Want to finish with the quick wrap-up (about a minute), or close now?" **Wrap up** / **Close now**.
- **Wrap up:** rejoin the wrap-up at Blocked-date sharing (Wrap-up 2) in `workflows/wrap-up/main.md`, and go on from there as usual.
- **Usage row:** a workflow that was started but stopped before its results still gets a usage row (`usage --workflow "<name>"` with what was spent so far, plus `--limit-hit "<step>"` if a usage limit stopped it), whichever they choose below.
- **Auto-send on or off** means the user's Auto-send setting: `usage data` in Local Data (`on` by default; `settings` shows it). It's "on" here only when `usage data` is on **and** `unlock` printed `AUTO_FEEDBACK: available` (this version can send); `AUTO_FEEDBACK: not set up` counts as off.
- **Close now, Auto-send usage data and feedback on:** compile the feedback collected so far (Collect (Wrap-up 4), including the privacy check), then send it with `feedback --submit` (every run, no `feedback --due` check). Then go to Close (Wrap-up 8). If the send fails, the script keeps it in the Local Data outbox itself (`FEEDBACK_KEPT`); say so in one line; don't read the failed-send file.
- **Close now, off:** compile what was collected (Collect (Wrap-up 4): `feedback --collect`, then `feedback --prepare`) and run `feedback --keep <file>` so it waits in the Local Data outbox (items noted with `fbname --item --text`, `FEEDBACK:` lines and usage rows are already kept in Local Data, so closing the window loses nothing). Say in one line that it'll come up next time. Then close (Close, Wrap-up 8).
- **Beta and alpha testers:** closing now doesn't count as declining to send. The feedback comes up at the next wrap-up.

## Restarted in a closed chat (`CHAT_CLOSED`)
- `session` prints `CHAT_CLOSED` when this chat's session ID is among the closed sessions (Close, Wrap-up 8, already ran here). Don't restart the skill in this chat: say in one line that it was closed here and ask them to start a new chat and ask for it there (new chats use up their usage limit less fast). Then stop.
- **Override:** only for the Advanced help level on a plan other than Free, and only when they explicitly ask or tell Claude to keep going here. Re-run `session` with `--id <this chat's SESSION_ID> --override-closed`; `CHAT_REOPENED` means go on here. `CHAT_CLOSED_NO_OVERRIDE`: the override isn't allowed for them; ask for a new chat and stop.
