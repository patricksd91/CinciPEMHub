# Wrap-up: Beta feedback warnings (Send, Wrap-up 5)

**Version:** 0.01.82

Read for beta and alpha testers when they decline to send feedback that exists, or already have 3 warnings when there's feedback. Alpha works exactly like beta; just say "alpha" instead of "beta".

- **Declining counts as a warning:** not sending feedback that exists, or choosing Save it for later, adds 1 to `feedback warnings` (up to 3). This holds whether Auto-send usage data and feedback is on or off. Tell them how many warnings they have: "That's warning <n> of 3. After 3, sending your feedback is needed to stay in the beta."
- **Not a warning:** closing with Close now (the feedback comes up next time), or saving it after an automatic send failed.
- **After the third warning,** the next time there's feedback, say: "If you don't send your feedback this time, you'll be removed from the beta program." **Send it automatically** / **Download it and email it** / **Leave the beta program**. No Something else.
- **Leave the beta program:** save `beta program: opted out`. Say they can rejoin any time just by asking. Offer the latest stable version at the end of the session (`workflows/updates/main.md`).
- **Reset:** sending or downloading feedback resets `feedback warnings` to 0. A download counts even though we can't tell whether it's emailed. Updates don't reset it.
