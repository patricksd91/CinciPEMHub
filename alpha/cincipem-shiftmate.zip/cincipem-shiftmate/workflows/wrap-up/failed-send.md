# Wrap-up: Send failed (Result, Wrap-up 6)

**Version:** 0.01.08

Read when `feedback --submit` prints `TOKEN_REFUSED`, `FEEDBACK_FAILED`, `FEEDBACK_PARTIAL` or `FEEDBACK_UNAVAILABLE`.

## Every failed send (6.9)
- The script keeps the file in the Local Data outbox (`FEEDBACK_KEPT`) and adds 1 to `failed sends` in Local Data (failed sends in a row; `settings` shows it). A later successful send resets it to 0 (the script does it).
- Add a Delivery line to System health in the file: "tried at <time>, failed: <reason in plain words>; failed sends in a row: <n>". Add the item as critical (`fbname --item health`).
- Run `feedback --prepare <file>` again after editing it, then `feedback --keep <file>` so the outbox has the edited file.

## What to say
- **First or second failure in a row:** "I couldn't send your feedback automatically (<reason in plain words>). I've noted that in the file. You can download it and email it to <feedback_name>, or I'll keep it and try again next time." **Download it** / **Save it for later**.
- **Third failure in a row or more:** "Automatic sending has failed again, so something is probably broken on our end. Please download the feedback file and email it to <feedback_name> so it can be fixed." **Download it** / **Save it for later**.
- **Download it:** give `feedback_email` from SKILL_SENSITIVE.md and follow Download in Result (Wrap-up 6).
- **Save it for later:** it's already in the Local Data outbox (`feedback --keep` after the Delivery line was added). It's tried again at the next wrap-up. For beta and alpha testers this isn't a warning, since they tried to send it.

## By marker
- **`TOKEN_REFUSED`:** save `feedback key refused` with today's date. Say installing the latest stable will probably fix it, show what it adds (`whatsnew`) and offer to update (`workflows/updates/main.md`). Then offer the download.
- **`FEEDBACK_FAILED: BLOCKED`:** the reason is that api.github.com isn't in allowed domains. Offer to walk them through adding it, then try again once. Otherwise the download or saving it.
- **`FEEDBACK_PARTIAL`:** a big send goes in numbered parts, and only some got through. It counts as a failed send: the whole file stays in the outbox, and sending it again later sends every part again. Say that some of it was sent and the rest will be tried again (or downloaded).
- **Other `FEEDBACK_FAILED`:** give the reason in plain words (for example "no internet connection" or "GitHub didn't answer").
- **`FEEDBACK_UNAVAILABLE`:** automatic sending isn't set up in this version. Offer the download or saving it. Don't count it as a failed send.
