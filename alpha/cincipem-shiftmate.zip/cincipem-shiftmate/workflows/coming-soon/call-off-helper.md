# Call Off Helper (coming soon)

**Version:** 0.01.08

Read when `comingsoon --workflow call-off-helper` prints `COMING_SOON` or `COMING_SOON_INFO`. Offered to clinicians in the beta or alpha, and to administrators (Which workflow, Administrator 3). The workflow itself isn't built yet; this file says what to do when it's picked.

- **Picked** (they chose it from the menu): run `comingsoon --workflow call-off-helper` (administrator mode: add `--admin`, for the administrator wording). Usage lines are always collected (they're sent only when Auto-send usage data and feedback is on). The script keeps its `USAGE:` line for the wrap-up: each pick counts, so the demand shows.
- **Only asked** what it is ("what's Call Off Helper?"): run `comingsoon --workflow call-off-helper --ask` (plus `--admin` in administrator mode). It prints `COMING_SOON_INFO` and no `USAGE:` line: a question isn't demand. Say its line, then go back to the question you were on (whatever it was: the menu, or a question inside a workflow). The one rule for every coming-soon question, also in administrator mode.
- `COMING_SOON`: say its line word for word ("Call Off Helper is coming soon. It will …"), and in the same message ask the workflow menu question again (the `WORKFLOWS` line; administrators: Which workflow, Administrator 3): one question, the menu is it. Don't ask Which clinician.
- What it will do (the script's line already says it; for more detail): for a clinician, find someone to take their shift at the last minute. For an administrator, find a way to readjust the schedule when someone calls off. It will have a clinician mode and an administrator mode; administrators run only the administrator mode.
