# Schedule Inquiry and Planning (coming soon)

**Version:** 0.01.08

Read when `comingsoon --workflow schedule-inquiry` prints `COMING_SOON` or `COMING_SOON_INFO`. Offered to administrators only (Which workflow, Administrator 3). It's an administrator workflow, so it isn't offered to clinicians, maintainers included: a maintainer running as a clinician is offered every workflow that exists for clinicians (including the beta and coming-soon clinician ones), and sees this one only when running as an administrator. The workflow itself isn't built yet; this file says what to do when it's picked.

- **Picked** (they chose it from the menu): run `comingsoon --workflow schedule-inquiry` (administrator mode: add `--admin`, for the administrator wording). Usage lines are always collected (they're sent only when Auto-send usage data and feedback is on). The script keeps its `USAGE:` line for the wrap-up: each pick counts, so the demand shows.
- **Only asked** what it is ("what's Schedule Inquiry and Planning?"): run `comingsoon --workflow schedule-inquiry --ask` (plus `--admin` in administrator mode). It prints `COMING_SOON_INFO` and no `USAGE:` line: a question isn't demand. Say its line, then go back to the question you were on (whatever it was: the menu, or a question inside a workflow). The one rule for every coming-soon question, also in administrator mode.
- `COMING_SOON`: say its line word for word ("Schedule Inquiry and Planning is coming soon. It will …"), and in the same message ask the workflow menu question again (Which workflow, Administrator 3): one question, the menu is it. Don't ask Which clinician.
- What it will do (the script's line already says it; for more detail): for the people who build the schedule, answer questions about it, list shifts that meet criteria, show what changing something would do, and propose swaps or changes, work out their effects and iterate.
