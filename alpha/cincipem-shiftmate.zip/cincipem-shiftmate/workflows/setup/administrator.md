# Setup: Administrator setup

**Version:** 0.01.82

Read in setup when the name check prints `| ADMIN` (an administrator), or when a clinician-administrator answers **Administrator** at the role question during setup. After setup, administrators use `workflows/administrator/main.md` every run.

- Question count: `setupcount --path administrator`, once, right after the name check.
- The same steps, with their own About you (their role is "Administrator"): Name check (Setup 1), Help level (Setup 2; administrators choose one too), About you in the chat (the page's role card doesn't apply; no role check), Usage data and plan (Setup 4), Allowed websites and the beta (Setup 5).
- Skip Location and Shift Time Preferences (Setup 6), Back-to-back shifts (Setup 7) and Dates you can't work (Setup 8); go to Save and check (Setup 9) with `setupcheck --path administrator`.
- On the intro: what they can do for the clinicians they help, and that setup takes about 2 minutes.
- Clinician-administrators: also save `clinician setup: not done` (see `workflows/startup/role-question.md`).
