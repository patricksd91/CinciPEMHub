# Setup: Confirm your settings (Updates 5)

**Version:** 0.01.82

Read when startup prints `RERUN_SETUP` (the first launch of any new version, plans 2.6 and 2.10). Use it with `workflows/setup/main.md`. Nothing is wiped unless they choose Start fresh and confirm it.

## The question
1. The question count is startup's own `SETUP_COUNT` line (printed before the profile, roster and role checks): say it where startup printed it. Don't run `setupcount` here.
2. Show what's saved, in its own message: help level; About you (leave out any field a `PROFILE_DIFF` line asked about); role; location and shift-time ratings; back-to-back; blocked dates, vacations and exceptions (leave out any date a `BLOCKS_ROSTER_DIFF` line just asked about); message delivery; beta program. Standard and advanced users see the whole summary; walk-me-through users see a short one.
3. Ask, word for word as the marker gives it: "You're running a new version (<version>). Here's what you have saved." **Looks right** / **Change something** / **Start fresh**. Walk-me-through users get one line on what each choice means first.

## Looks right
- Standard and advanced users: keep everything. Walk-me-through users: go through each saved answer step by step, ready to confirm.
- **Always, at every help level:** reopen the ratings page (Location and Shift Time Preferences (Setup 6)) with their saved ratings in `SAVED` (after `HOLIDAY_SPLIT`, with the three holiday times it saved), for them to confirm or change. The page says so. Make the page with `page --name preferences --clinician "<roster name>" --out <file>` (Setup 6 step 1): it fills `ELIGIBLE` and `SAVED` from the roster and Local Data only, so the schedule isn't loaded (no `refresh` here). Publish the file by its path without reading it. Save the pasted line with `prefs --line`.
- `SETUP_NEW_QUESTIONS`: ask each new setting it names (for 0.01.08: Back-to-back shifts (Setup 7)) right after the confirm question, whatever they chose (Looks right included), as in setup.
- Don't ask the plan here: it's asked once, at `PLAN_ASK` later in startup (if printed).
- Skip the name check, the passphrase if unlocked, the beta question if they're in the beta, and the allowed-websites offer if Local Data shows it done. The intro was already said (INTRO, Startup 5): don't repeat it.

## Change something
Ask what they'd like to change (**Something else (type it below)** is fine), then run just those setup steps with each saved answer as **(your usual)**. Then the ratings page, as above.

## Start fresh
1. Warn, in its own message, what will be cleared: settings, preferences, blocked dates and saved clinicians. Kept: the passphrase and any unsent feedback (it carries over into the new version and is never deleted).
2. Ask: "Are you sure? This clears your saved settings." **Yes, start fresh** / **No, go back** (back to the question above).
3. On yes: the script keeps a copy of the old settings in Local Data (`previous-settings/<date>`), so "restore my old settings" can bring them back until the next version. Then run full setup from Help level (Setup 2) (no name check).

## Clinician-administrators and administrators
- Administrator mode: confirm only the administrator part; Start fresh also covers their clinicians' saved settings. Their clinician settings are confirmed the next time they start as a clinician.
- Clinician mode (the marker says so): confirm their clinician settings, then save `clinician settings confirmed: <version>`.

## Afterwards
Counters that this version changed restart from zero (the script does it); `COUNTER_ASK_AGAIN` is in `workflows/startup/new-version.md`. Then go back to the next startup line.
