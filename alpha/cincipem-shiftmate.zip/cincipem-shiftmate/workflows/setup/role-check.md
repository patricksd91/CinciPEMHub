# Setup: Role check (About You and Role Check, Setup 3)

**Version:** 0.01.08

Read when startup prints `ROLE_CHECK_DUE` (Profile, roster and role checks, Startup 11), and in setup when the About You and Role Check page (`assets/about-role.html`, see `workflows/setup/main.md`) can't be used.

## When it's due
In setup, and on the first startup on or after Mar 25, Jun 24, Sep 24 and Dec 25 (a week before each quarter), once per quarter. At `ROLE_CHECK_DUE`, use the page (only its role card matters; the About-you fields are prefilled and can be left as they are), or ask in the chat as below.

## In the chat
From `whoami`, show in its own message:
- their title and the permissions that decide what they can work ("Title: Faculty. Permissions: Standard Clinical Staff (CL)", or the exceptions); say "Clinical Staff" and "Senior Clinical Staff", and "SrAPP (LT UC only)";
- their sites and Jeopardy pools, the shift levels allowed at each site, who they can trade with and moonlighting (the `whoami` Trades and Moonlighting lines);
- what that allows and doesn't allow, plus any special restrictions or extra privileges on their name. Levels: F, CL\*, CL, APP\*, APP (see the glossary).

Then ask: "Is that right?" **Looks right** / **Something's wrong**.
- **Something's wrong:** "Is it just listed wrong here?" **Yes, just listed wrong** / **No, my permissions need to change**.
  - **Just listed wrong:** ask what's wrong and what it should say. Warn: "You're overriding your role from the roster. I'll search using what you've told me, but the schedulers have the final say." Save it as `role override` (keep `role` as `whoami` prints it) and pass it as `role_override`. A title-only correction ("I'm faculty now" when the permissions are right) goes to Roster updates, not `role_override`. Either way it's **critical** feedback (Roster updates), reviewed by hand.
  - **Permissions need to change:** "ShiftMate can't change your scheduling permissions. Please discuss them with your people leader. Until anything changes in ShiftAdmin, I'll keep using what's listed here." Then offer **The listing doesn't match ShiftAdmin** / **OK**: the first opens the same fix as Just listed wrong.
- Save `role confirmed` with today's date (`none` if they chose Save, ask me again later on the page).
