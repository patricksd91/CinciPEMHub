# Setup: Moonlighter and not-on-roster replies (Name check, Setup 1)

**Version:** 0.01.08

Read at the name check when `whoami --setup` prints `SETUP_MATCH_MOONLIGHTER`, `NO_MATCH` or `LOCKOUT`.

- `SETUP_MATCH_MOONLIGHTER`: say, word for word: "CinciPEM ShiftMate is only for staff employed by the Division of Emergency Medicine right now. It may open to more people in the future if there's demand, so please email <feedback_name> if you'd like it." (<feedback_name> is in SKILL_SENSITIVE.md.) Give no email address. It isn't a miss. Then stop.
- `NO_MATCH`: say the name isn't on the CinciPEM roster and how many tries are left (and, before the last, that setup pauses for 24 hours after it). `LOCKOUT` (third miss): explain as it says (including how someone new can ask to be added), ask **Yes** / **No** whether you may let the maintainer know now; on yes, send a short feedback file right away (`feedback --submit`). Then stop.
