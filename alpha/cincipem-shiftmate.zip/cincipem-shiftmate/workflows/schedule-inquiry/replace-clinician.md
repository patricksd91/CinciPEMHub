# Replace Clinician

**Version:** 0.01.82

Read when an administrator picks Replace Clinician in Schedule Inquiry and Planning (Pick a tool, Schedule Inquiry 1), or their message says a clinician is leaving and their shifts need cover. It backfills a departing clinician's shifts by moving colleagues off less-protected shifts on the same day (donor shifts).

Steps: Intake (Replace Clinician 1), Audit (Replace Clinician 2), Pool Selection (Replace Clinician 3), Eligibility Matching (Replace Clinician 4), Resolution Output (Replace Clinician 5). Always call a step by its name first, then its number.

**Words to use** (define them the first time for walk-me-through and standard administrators):
- **Vacated shift:** a shift of the departing clinician, on or after the effective date, that needs someone else.
- **Tier:** how protected a shift is, from 1 (least: enhancements such as flex and bullpen shifts) to 5 (Jeopardy backup, the last resort). `inquiry tiers` lists the rules.
- **Donor shift:** a shift in a chosen tier, on the same day as a vacated shift. Its clinician would move off it to cover the vacated one, and the donor shift would be dropped or repurposed (as the leadership email describes). A donor shift is only used for a vacated shift in a more protected tier, so core coverage is never robbed to fill core coverage; Jeopardy backup (pool 5) can cover core shifts (tiers 3-4), and a vacated Jeopardy shift is refilled only from tiers 1-2.
- **Pool:** the donor shifts of one tier.

Every command below takes the same `--name "<roster name>" --from <effective date>` (and `--to <date>` and `--shifts <ids>` when they narrowed it), so keep them for the whole workflow.

## Intake (Replace Clinician 1)
Ask two things, one per message (skip what their message already says):
1. "Who is leaving?" No buttons; they type the name.
2. "What's the effective date? I'll look at their shifts from that day on." Buttons: **Today** / **The 1st of next month** / **Something else (type it below)**.
Then run `inquiry vacated --name "<name>" --from <date>`. `DID_YOU_MEAN` or `NO_MATCH`: see Running the commands in `workflows/schedule-inquiry/main.md`, then run it again with the confirmed name. An end date ("only through December") goes in `--to`. A name without the first name (a last name alone) is always confirmed first (`DID_YOU_MEAN`, Yes / No), even when only one person matches: a departure is too important to guess.

## Audit (Replace Clinician 2)
Show `SI_VACATED` as one sentence ("Dr. Example has 19 shifts from 11/01 that need a replacement, 2 of them on holidays"), then the numbered list as printed (date, shift, site and level, holiday tag, tier, id).
- `SI_NONE`: say they have no shifts from that date that need cover, and go to What next (Schedule Inquiry 3).
- `SI_OPTIONAL`: some vacated shifts are themselves tier 1 or 2 (enhancement or extra capacity). Say in one line that these could be left unfilled (repurposed) instead of replaced.
- Then one question: "Shall I look for colleagues who could move onto these?" Buttons: **Yes, all of them** (default) / **Only some (type the numbers)**, plus, when they apply, **Leave the tier 1-2 ones out** (with `SI_OPTIONAL`) and **Only through <a date about a month out>** (over 20 shifts). From then on pass `--shifts` with the ids they kept (or `--to` with the date).
- `SI_UNKNOWN_IDS`: some ids weren't this clinician's shifts in the window; say which were left out.

## Pool Selection (Replace Clinician 3)
Run `inquiry pools` (same name, dates and shifts), even when they already named the pools. Show `SI_POOLS` as its numbered list: each tier, least protected first, with how many shifts and clinicians it has on those days and a few example shift names.
Ask (skip it when they already named the pools): "Which pools should I pull replacements from? Least protected first is the usual order." Buttons: **1 and 2 (Enhancement and Extra capacity)** (default) / **1 to 3** / **1 to 4** / **Something else (type it below)** (numbers, for example "2 and 5"). Say once that pool 5 (Jeopardy backup) is a last resort.

## Eligibility Matching (Replace Clinician 4)
Run `inquiry candidates --pools <numbers>`. Say the `SI_CANDIDATES` line in one sentence, then paste the table exactly as printed: the first column is the status (🟢 eligible for at least one vacated shift, ❌ not eligible for any), so the marks line up in one column. "Can cover" says for how many vacated shifts, or the main reason they can't.
- Nobody usable in those pools (`SI_CANDIDATES: nobody works a shift in pools ...`): stop here and ask "Nobody in those pools can move onto these shifts. What next?" **Add a pool** (back to Pool Selection, Replace Clinician 3) / **Offer them as moonlighting** (Moonlighting Offers) / **Something else (type it below)**. Skip Resolution Output.
- Otherwise go straight on to Resolution Output (Replace Clinician 5); don't ask.

## Resolution Output (Replace Clinician 5)
Run `inquiry resolve --pools <numbers>` and show it in two parts, then the suggested plan, each with a bold heading:
1. **Shifts with viable replacements** (`SI_RESOLVED`): each vacated shift, then its options (🟢 name, role, and the donor shift they'd move off, with its tier). The rules used: role and site eligibility, no ShiftAdmin vacation, 8 hours' rest and at most 7 days in a row. Individual blocked dates are ignored on purpose: say once that the clinician still has to agree.
2. **Unresolvable shifts** (`SI_UNRESOLVED`): each vacated shift with the donor shifts that were evaluated and, for each candidate (❌), the reason in plain words. With more than 8 candidates the script groups them by reason (one ❌ line per reason, every candidate named): keep that grouping. Two other lines can appear under a shift:
   - "<n> donor shift(s) in pools ... not used: <rule>": those pool shifts were skipped by the donor rule (a donor must be less protected than the shift; nothing is less protected than an Enhancement shift; a vacated Jeopardy shift is refilled only from tiers 1-2). Say the rule in plain words.
   - "no shifts in pools ... on <date>": the chosen pools had no shifts that day.
3. **Suggested plan** (`SI_PLAN`, only when part 1 has shifts): one clinician per shift, spread so nobody is asked twice where it can be helped and never twice on one day. Show it as a short list under its own bold heading and call it a starting point, not a decision.
`SI_MORE` after a part: that part was cut at 60 shifts; say how many more and offer to narrow (an end date, or some shifts).
Then add one line: nothing has changed in ShiftAdmin; the schedulers confirm each move with the clinicians and make the change there.
Go to What next (Schedule Inquiry 3): with unresolvable shifts left, its first buttons are **Offer the open ones as moonlighting** and **Try more pools**.
