# Coverage Snapshot

**Version:** 0.01.82

Read when an administrator picks Coverage Snapshot in Schedule Inquiry and Planning (Pick a tool, Schedule Inquiry 1), or asks who's working where on certain days. It shows the schedule by day and site: counts for a week or more, names for one to three days. Holidays are flagged.

Steps: Dates and sites (Coverage Snapshot 1), Snapshot (Coverage Snapshot 2), Drill down (Coverage Snapshot 3). Always call a step by its name first, then its number.

## Dates and sites (Coverage Snapshot 1)
Skip what their message already says.
1. "Which dates?" Buttons: **Today** / **This week** / **The holiday block** (the holidays they mean, from the question; ask which if unclear) / **Something else (type it below)**.
2. "Which sites?" Only ask when the dates cover more than one day and they didn't say; default all. Buttons: **All sites** (default) / **The EDs (B ED, Lib ED)** / **The urgent cares** / **Something else (type it below)**. Jeopardy is included with All sites; name it to include it with a pick.

## Snapshot (Coverage Snapshot 2)
Run `inquiry snapshot --from <first date> --to <last date> [--sites "<site>,<site>"]`.
- Say `SI_SNAPSHOT` in one line (how many shifts, which sites, which dates).
- One to three days: the script lists each day (`DAY:` lines, with the holiday named), each site, and each shift with who's on it and its tier. Show it as a list with a bold heading per day and per site.
- Four to 31 days: it prints a table of shift counts (rows: days, holidays marked; columns: sites). Paste it as printed.
- Over 31 days: the same table with one row per week (weeks start Monday; a week with a holiday is marked). Offer a row per day for up to 31 days.
- `SI_MORE`: a name list stopped at 180 shifts; offer fewer days or sites.
- `SI_NOTE`: some shifts have a name the roster doesn't know; say how many, and that they show as "not on roster".
- A site with 0 on a day (for example the outpatient urgent cares on a holiday) may simply be closed; don't call it a gap unless they say it should be open.

## Drill down (Coverage Snapshot 3)
After a counts table, ask: "Want to see who's on for one of these days?" Buttons: **Yes (type the date)** / **No**. Yes: run it again for that day with `--detail`.
Then go to What next (Schedule Inquiry 3).
