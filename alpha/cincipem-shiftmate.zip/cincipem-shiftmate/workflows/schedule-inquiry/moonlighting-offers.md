# Moonlighting Offers

**Version:** 0.01.82

Read when an administrator picks Moonlighting Offers in Schedule Inquiry and Planning (Pick a tool, Schedule Inquiry 1), or chooses **Offer the open ones as moonlighting** after Replace Clinician (What next, Schedule Inquiry 3). It turns a departing clinician's open shifts into a moonlighting (ML) offer list, holidays first, with how many clinicians could take each one.

Steps: Which shifts (Moonlighting Offers 1), Offer list (Moonlighting Offers 2), Posting (Moonlighting Offers 3). Always call a step by its name first, then its number.

## Which shifts (Moonlighting Offers 1)
- **Coming from Replace Clinician:** use the same `--name`, `--from` (and `--to`, `--shifts`) and `--pools`. With `--pools`, only the shifts those pools couldn't fill are offered. Don't ask again.
- **Started here:** ask the Intake questions of Replace Clinician (Replace Clinician 1: who is leaving, then the effective date), one per message, and run without `--pools` (every vacated shift is offered).

## Offer list (Moonlighting Offers 2)
Run `inquiry mloffers --name "<name>" --from <date> [--to <date>] [--shifts <ids>] [--pools <numbers>]` (`--include-optional` only when they ask for the tier 1-2 shifts too).
- Say `SI_ML_OFFERS` in one sentence (how many shifts, how many on or next to a holiday).
- Show each shift as a list item: date, shift, site and level, holiday tag, id, then "<n> eligible and free" and the first names given. Holidays come first.
- Say the `SI_NEXT` rule once in plain words: "eligible and free" means credentialed for the shift, not already working then, not on a ShiftAdmin vacation, with 8 hours' rest and at most 7 days in a row kept. Blocked dates aren't checked, and moonlighters (who pick up ML shifts through ShiftAdmin) aren't listed.
- `SI_SKIPPED_OPTIONAL`: the departing clinician's tier 1-2 shifts (enhancement or extra capacity) aren't offered, because they can simply be left unfilled. Say so in one line; if they want them offered too, run it again with `--include-optional`.
- `SI_NONE`: every shift already has a replacement from those pools (or only tier 1-2 shifts were left); say so.

## Posting (Moonlighting Offers 3)
Say in one line that posting is done in ShiftAdmin (the skill doesn't change the schedule). Ask "Want a draft announcement for the division?" **Draft an announcement** / **I'm done** / **Something else (type it below)** (for example another tool).
- **Draft an announcement:** write a short message the administrator can paste into an email to the division: the shifts (holidays first, date, site, time), how to pick them up in ShiftAdmin, and a thank-you. No names of who's eligible. Signed with the administrator's name. Then What next (Schedule Inquiry 3).
