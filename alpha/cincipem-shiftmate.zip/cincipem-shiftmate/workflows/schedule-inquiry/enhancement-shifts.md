# Enhancement Shifts

**Version:** 0.01.82

Read when an administrator picks Enhancement Shifts in Schedule Inquiry and Planning (Pick a tool, Schedule Inquiry 1), or asks which nice-to-have shifts could be repurposed. It lists the least-protected shifts (tier 1 Enhancement and tier 2 Extra capacity; `inquiry tiers` has the rules) for a date range, with who's on them, so the schedulers can see what could be turned into core clinical coverage.

Steps: Dates and tiers (Enhancement Shifts 1), Inventory (Enhancement Shifts 2), Use them (Enhancement Shifts 3). Always call a step by its name first, then its number.

## Dates and tiers (Enhancement Shifts 1)
Skip what their message already says.
1. "Which dates?" Buttons: **The next 4 weeks** / **Through the end of the block** (ask the date) / **Something else (type it below)**.
2. "Which tiers?" Buttons: **Enhancement only (tier 1)** / **Enhancement and Extra capacity (1 and 2)** (default) / **Something else (type it below)**. Define the two tiers for walk-me-through and standard administrators (flex, bullpen and lecture shifts; Short, Psych, Supertrack and the mid-day add-on APP shifts).

## Inventory (Enhancement Shifts 2)
Run `inquiry enhancements --from <date> --to <date> --tiers <numbers> [--sites "<sites>"]`.
- Say `SI_ENHANCEMENTS` in one sentence, then paste the summary table as printed (tier, site, shift, how many, how many assigned, first date).
- 20 shifts or fewer, or with `--list`: the `SI_LIST` lines follow (date, shift, holiday tag, who's on it, id). Show them as a list.
- Over 20: offer **Show every shift** (re-run with `--list`) / **Narrow it (dates or sites)** / **Something else (type it below)**.
- `SI_NONE`: no shifts in those tiers; offer tier 2 if they picked only tier 1.

## Use them (Enhancement Shifts 3)
Say in one line what these are for: the clinicians on them are the donors Replace Clinician moves first (pools 1 and 2). Then go to What next (Schedule Inquiry 3); add **Replace a clinician** as a button when they mentioned a departure.
