# Schedule Inquiry and Planning

**Version:** 0.01.82

Read when an administrator picks **Schedule Inquiry and Planning (SIP)** at Which workflow (Administrator 3; `workflows/administrator/main.md`), or their message already asks for one of its tools. It's for the people who build the schedule: they run it for the division, not for one clinician, so don't ask Which clinician (Administrator 4). It's an alpha feature, new in 0.01.82.

Steps: Pick a tool (Schedule Inquiry 1), Run the tool (Schedule Inquiry 2), What next (Schedule Inquiry 3). Always call a step by its name first, then its number.

Its five tools (sub-workflows), each in its own file:

| Tool | What it answers | File |
|---|---|---|
| Shift Search | "Which shifts match these filters?" (side-panel page) | `workflows/schedule-inquiry/shift-search.md` (read only when picked) |
| Replace Clinician | "Someone is leaving: which shifts need cover, and who can move onto them?" | `workflows/schedule-inquiry/replace-clinician.md` (read only when picked) |
| Coverage Snapshot | "Who's working where on these days?" | `workflows/schedule-inquiry/coverage-snapshot.md` (read only when picked) |
| Enhancement Shifts | "Which nice-to-have shifts could be turned into core coverage?" | `workflows/schedule-inquiry/enhancement-shifts.md` (read only when picked) |
| Moonlighting Offers | "Which open shifts should be posted as moonlighting, and who could take them?" | `workflows/schedule-inquiry/moonlighting-offers.md` (read only when picked) |

## Running the commands
- Every tool's command is `inquiry <command> ...` on the ShiftMate script (Running the script in SKILL.md: through the extension, `args` = `inquiry <command> ...`; with a shell, `python3 $S inquiry <command> ...`). In a development copy you can also run `python3 scripts/schedule_inquiry.py <command> ...` directly. Shift Search has its own command (see its file).
- The schedule loads the same way as for every other search: run `refresh` right before the first command that needs it (Schedule, Startup 13).
- Dates go to the script as YYYY-MM-DD. Say them back to the administrator as "Wed 11/04".
- Paste tables the script prints (lines starting with `|`) as printed, so the columns line up. Turn the other lines into short sentences; never show the marker words themselves (`SI_...`).
- `SI_NAME_OK`: the name matched the roster; use that full name from then on (no need to say it matched).
- `DID_YOU_MEAN`: the name wasn't an exact roster match (a last name alone is always asked about). Ask as the line says: **Yes** / **No** when it offers one name as "isn't an exact match", otherwise one button per name it gives plus **None of these**; then run the same command again with the exact name. Never go on with a name that wasn't confirmed. `DID_YOU_MEAN_MANY`: over 3 people match; ask for the full name. `NO_MATCH`: say the name isn't on the roster and ask them to check the spelling or give the name ShiftAdmin uses.
- `STARTUP_FIRST` (released copies): run `startup` and finish it first, as for every search command (SKILL.md, Startup), then repeat the command.
- `SI_PAST_DATE`: say in one line that shifts already worked don't need cover, so the tool starts today. (Coverage Snapshot and Enhancement Shifts can look at past dates.)
- `SI_NONE`: say it in plain words and offer the menu again (What next, Schedule Inquiry 3). When the dates are all in the past and they likely meant the same dates next year, ask that instead (**Yes** / **No**) and run it again after a yes.
- `SI_MORE`: the list was cut; say how many more and offer to narrow (dates, sites or shifts).
- `ERROR`: say what went wrong in plain words and ask for the missing piece (usually a date).
- `FEEDBACK`: note it for the wrap-up, as in every workflow.
- Help level still applies: walk-me-through administrators get one small step at a time and the terms defined (tier, donor shift, pool); advanced ones get the results with no explanation.

## Pick a tool (Schedule Inquiry 1)
Skip this when their message already says which tool (or clearly fits one: "Dr. Example is leaving in November" is Replace Clinician; "who's on at Burnet on Christmas" is Coverage Snapshot).
Ask: "What would you like to do?" Show the five tools as a numbered list in the chat (name and the one-line question from the table), with these buttons: **Replace Clinician** / **Shift Search** / **Coverage Snapshot** / **Something else (type it below)**. They can type a number or a name for the other two.
- A question about the tiers ("what counts as an enhancement shift?"), here or in any tool: run `inquiry tiers`, say its `SI_TIERS` list in plain words, then ask the question you were on again.

## Run the tool (Schedule Inquiry 2)
Read the tool's file (table above) and follow it. Each tool ends at its own last step and comes back here.

## What next (Schedule Inquiry 3)
Ask: "Anything else in the schedule?" Buttons, picked from where they are (they can always type another tool's name):
- After **Replace Clinician** with shifts still open: **Offer the open ones as moonlighting** (Moonlighting Offers, with the same name, dates and pools) / **Try more pools** (Pool Selection, Replace Clinician 3) / **I'm done** / **Something else (type it below)**.
- After **Shift Search**: **Replace a clinician on some of these** / **Coverage on one of these days** / **I'm done** / **Something else (type it below)**. (See Shift Search results, below.)
- Otherwise: **Another tool** (back to Pick a tool, Schedule Inquiry 1) / **I'm done** / **Something else (type it below)**.
- **I'm done**: read `workflows/wrap-up/main.md` (administrator mode: Blocked-date sharing, Wrap-up 2, is skipped). **Another search** at the wrap-up comes back to Which workflow (Administrator 3).

## Shift Search results (how the tools connect)
Shift Search's list shows each shift's id as `#<id>` and the clinician on it. From there:
- **Replace a clinician on some of these:** the shifts must all belong to one clinician. Take that clinician's roster name and the ids they picked, and start Replace Clinician at Audit (Replace Clinician 2) with `--name "<name>" --from <earliest date> --shifts <id,id,...>` (Intake, Replace Clinician 1, is already answered; still confirm the name if the search's name wasn't exact). Shifts from several clinicians: ask which clinician first.
- **Coverage on one of these days:** Coverage Snapshot with that date (and the site, if they picked one).
- **Which of these could be repurposed?** Enhancement Shifts with the search's dates and sites.
- **Post some of these as moonlighting:** Moonlighting Offers works on one departing clinician's shifts (`--name`, `--shifts`); for shifts of several people, run it once per clinician.
