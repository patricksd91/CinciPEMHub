# Swap Locations

**Version:** 0.01.08

Read when the user picks Swap Locations, or their message already asks for it. Same-day trades of regular shifts only.

**Who gets it:** a beta feature. Only standard and advanced users in the beta run it, administrators for a clinician, and a maintainer running as a clinician (maintainers are offered every workflow, SKILL.md Features). Everyone else is told it's in the beta (standard and advanced users: offer to join) or coming; follow `startup`'s `WORKFLOWS` line.

**0.01.08 only:** Swap Locations gets a full redesign in 0.01.09. Its open questions are parked on the tracker, and it isn't in this build's clarifications; test mode keeps only its 0.01.07 test (test 22).

Steps: Sites to leave (Swap Locations 1), Sites to move to (Swap Locations 2), Dates (Swap Locations 3), Settings (Swap Locations 4), Search (Swap Locations 5), then The list through Your usual (Trade Shifts 6 to 11): The list, Recipients, Delivery, Draft (Delivery always comes before Draft), Sent or not, Your usual. The request fields in `workflows/trade-shifts/main.md` (`who`, `back_to_back`, `time_order`, `site_order`) and its Delay messages apply here too.

## Sites to leave (Swap Locations 1)
"Which sites would you like to move out of?" Their sites, in their location order (a numbered list if more than 4). Save as `leave_sites`.

## Sites to move to (Swap Locations 2)
Run `locswitch` with `leave_sites` and no `accept_sites`. Leave out `site_ratings`: the script reads the clinician's saved location ratings from Local Data itself (`LOCAL_DATA_INPUTS`); pass `site_ratings` only for ratings they just gave in this chat. Show the sites on its `SITES_TO_MOVE_TO` line, each with its rating ("OPE 9, B ED 8"). With several sites to leave, a site is offered only if it's rated higher than **all** of them (higher than the best-rated site being left); say that in one line when some site was left out for it, and they can add it at **Change them**. Ask: "Are these still right?" **Use these** (its `accept_sites`) / **Change them**.
- **Change them:** ask which sites they'd accept, in their location order.
- `SITES_TO_MOVE_TO: none (...)` (also when no location ratings are saved): say so in one line and ask which sites they'd accept.
- These become `accept_sites`, and they replace the Sites question in Settings.

## Dates (Swap Locations 3)
"Which dates? A list, some ranges, or all future dates." Vacations and blocks as in Availability (Trade Shifts 3); only when they block a time, say they can work a vacation day, or a line prints `ROSTER_BLOCKS`, read `workflows/trade-shifts/blocks.md`.
- Run `locswitch` with `"count_only": true` and say how many shifts that is. `COUNT_ONLY: none`: say so and stop (they can pick other sites or dates); don't ask the rest.
- If any is a holiday or peri-holiday shift, ask the holiday question from `workflows/trade-shifts/special-cases.md`.

## Settings (Swap Locations 4)
Shift times, the two longer-shift limits and trade categories, as in Settings (Trade Shifts 4): summary mode or step-by-step, from this workflow's own usual and most recent (`swap locations usual` and `swap locations most recent`); in summary mode, read `workflows/trade-shifts/your-usual.md` for which set and its buttons. Don't ask the Sites question.

## Search (Swap Locations 5)
Run `locswitch` (the table's columns are the sites they'd accept). Handle its output as in Search (Trade Shifts 5): the table (a shift time narrowed out shows `–`), `OVER_12`, `FEW_RESULTS` and the ladder (one ladder question per shift), `NOTHING_TO_LOOSEN`, `COLLEAGUE_VACATION_EXCEPTION`, and "Why wasn't <colleague> offered?". More than 3 shifts: give one line per shift with its option count, then show the tables and lists they pick.

Then The list (Trade Shifts 6), Recipients (Trade Shifts 7), Delivery (Trade Shifts 8), Draft (Trade Shifts 9), Sent or not (Trade Shifts 10) and Your usual (Trade Shifts 11), in `workflows/trade-shifts/main.md`. Your usual runs `usual --workflow swap-locations` and saves to `swap locations usual` and `swap locations most recent`.
