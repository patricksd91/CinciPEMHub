# Pickup Moonlighting

**Version:** 0.01.08

Read when the user picks Pickup Moonlighting, or their message already asks for it.

**Who gets it:** a beta feature, for standard and advanced users in the beta (follow `startup`'s `WORKFLOWS` line). It's always for the user themself: the Available Shifts file they attach and the schedule are their own, so never ask whose they are. Never run it for someone else or in administrator mode.

Steps: Available Shifts file (Pickup Moonlighting 1), Dates (Pickup Moonlighting 2), Settings (Pickup Moonlighting 3), Results (Pickup Moonlighting 4), Your usual (Pickup Moonlighting 5). Use `back_to_back`, `time_order` and `site_order` as in `workflows/trade-shifts/main.md`. Before `mlpickup`, run `wait --kind mlpickup` (see Delay messages in `workflows/trade-shifts/main.md`).

## Available Shifts file (Pickup Moonlighting 1)
Checked first, so a missing file is found before any questions.
- **No file yet:** "Please download your Available Shifts file from ShiftAdmin and attach it here: hover over Schedule, click Available Shifts, choose the Excel version, then Download Excel file." Wait for it.
- **A file is attached:** use the newest one. Run `mlpickup --xls <file> --file-date`. `AVAILABLE_SHIFTS_UNREADABLE`: say the file can't be read, right away (before any question), and ask for a new download (same steps as No file yet). Otherwise the date is said once:
  - Only `AVAILABLE_SHIFTS_FILE`: say the sentence it gives ("Using your Available Shifts file from 10/02."). The date is the first date in the file's title row; when the title row has none, it's the file's last-saved time, and the line says so ("…from 10/02 (the file's title row has no date, so this is when the file was last saved).").
  - `AVAILABLE_SHIFTS_OLD` too: don't say the FILE line; say only the OLD question: "Open shifts change every day, and this file is from 10/02." (adding that it's the saved date when the line says so) **Use it anyway** / **I'll download a new one**. Use it anyway: add `"old_file_ok": true` to the request. A new one is read the same way.
  - `AVAILABLE_SHIFTS_FUTURE`: the file's date is later than today; say so and ask the same two buttons (Use it anyway: `"old_file_ok": true`).
- Full `mlpickup` runs also print `AVAILABLE_SHIFTS_FILE` first, marked "already said … don't repeat it": don't repeat the date.

## Dates (Pickup Moonlighting 2)
"Which dates should I look in?" Then review their blocked dates and vacations saved in Local Data. Only when they block a time, say they can work a vacation day, or a line prints `ROSTER_BLOCKS`: read `workflows/trade-shifts/blocks.md`.

## Settings (Pickup Moonlighting 3)
Sites (in their order) and shift times, as in Settings (Trade Shifts 4): summary mode or step-by-step, from this workflow's own usual and most recent (`pickup moonlighting usual` and `pickup moonlighting most recent`); in summary mode, read `workflows/trade-shifts/your-usual.md` for which set and its buttons.

## Results (Pickup Moonlighting 4)
Run `mlpickup --xls <file>`. Show the list by date, then sites in their order (no table). It's always the user's own search: say "you" and "your", even though the list's header line names them.
- `OVER_12`: show the `COUNTS` and offer **Display all** (default; re-run with `"show": "list"`) / **Narrow it (by site, shift time or date)** / **Something else (type it below)**. Narrow it: ask how in one question, then re-run with a `filter` (`times` codes as in `workflows/trade-shifts/see-everything.md`).
- `BACK_TO_BACK_LEFT_OUT`: back-to-back shifts are off. Say how many open shifts were left out for being back-to-back with one of theirs, and offer to include them (re-run with `"back_to_back": true`; 12 h 15 min in a row at most).
- Back-to-back shifts (when on) and M3 short-rest shifts are in their own groups, each with its warning.
- `VACATION_DATES`: already in ShiftAdmin. Use them only as a reminder; don't save them.
- `NOT_ELIGIBLE`: say in one line that some open shifts need a level they can't work.
- `OTHER_OPEN` (few results): say how many more they could pick up with wider sites or shift times, and offer to include them.
- Map everyday words like "weekends" with the glossary; ask if unsure.

## Your usual (Pickup Moonlighting 5)
As Your usual (Trade Shifts 11), in `workflows/trade-shifts/your-usual.md` (`usual --workflow pickup-moonlighting`), saved to `pickup moonlighting usual` and `pickup moonlighting most recent`. Then the wrap-up (`workflows/wrap-up/main.md`).
