# Startup: Test mode (Demo or test mode, Startup 9)

**Version:** 0.01.82

This build's testing program (plans 2.9 and 9.12). Read at Demo or test mode (Startup 9) when startup prints `TEST_MODE` or `TEST_MODE_CLOSED` (alpha and beta builds for enrolled users; maintainers on every build), or when they typed "start test mode". Never mention test mode to anyone else. It never bypasses the passphrase.

## Who is offered it
Offer it at every startup only when all of these are true. Exception: a maintainer (the maintainer list in the `SENSITIVE:` file; the script checks it) is always offered it, on every version, stable included.
- their settings (Local Data) say beta program `in` or `alpha`;
- this build is a beta or alpha (the banner's version line says beta or alpha), never a stable;
- the build is less than 7 days old (the `BUILD:` date on the script's `VERSION:` line);
- no newer version is available (`UPDATE_NONE` or `UPDATE_SKIPPED`, not `UPDATE_OFFER` or `BETA_ASK_ONCE`).

The script decides; follow its line. Then ask: "Would you like to run this build's testing program?" **Start test mode** / **Not now**. Not now: go on with startup. If they typed "start test mode" and these aren't all true, say in one line: "Testing for this version has closed." Startup prints `TEST_MODE` (offer it; or start it, when run with `--test-mode`) or `TEST_MODE_CLOSED`. "start test mode" typed after startup: run `testmode`.

## The guide box
- The skill runs normally. The guide's text comes first in each message, as a quote box headed **TEST GUIDE**, and never changes what the skill says or asks.
- Inside the box, formatting is fine; mark what to do next with **🟢 Next:**.
- The guide follows the script and quotes rules only from the skill's own files.
- Anything the tester types after "Note:" or "Feedback:" is always feedback, recorded under the current test, word for word.

## Start (Test mode 1)
If another chat has the skill open (`OTHER_SESSION`), ask them to close it first, then start (Test 3 later opens its own second chat on purpose). Help them find it: when it started, its first message and workflow (from its session note), and a clickable link to that chat when one is known. Only test mode asks this.

## Set up the run (Test mode 2)
1. Thank the tester warmly and specifically (what their testing makes possible for the division). Never the same wording twice in a row.
2. Ask: **Normal mode** (log hidden) / **Debugging mode** (log shown in the guide box).
3. Ask: **Everything** (default) / **Only what's new in this build**.
4. Give the time estimate, in total and per chat, from the Minutes column and the chats listed in Tests below (Everything: about 64 minutes: chat 1 (saved settings) about 40, chat 2 (clean set 1) about 21, chat 3 (clean set 2) about 3; Only what's new: add up the "new" rows the same way). Say they can stop any time and send only what they've done.

## Back up and copy (Test mode 3)
Test mode works in Local Data's `testing/` folder, so tests never touch the tester's `live/` settings. Run `testmode --start`: the script backs up the real settings into `testing/backup/<date-time>/` (never the passphrase), copies them into `testing/` for the saved-settings tests, and switches this work folder to `testing/` (`TEST_MODE_ON`). From then on every command uses `testing/` by itself (`testmode --status` says which); nothing else to pass. Leave one memory line: "ShiftMate test in progress, backup in testing/backup of the Local Data folder". Outside test mode, ignore that line.
- The saved-settings tests use the tester's real settings but never change them: every save goes to `testing/`, never to `live/` or memory, unless the tester overrides (below).

## Saved-settings tests (Test mode 4)
For each test: its steps in the guide box. Record any feedback typed during it under that test. After the test: list what was already noted during it, then ask "Any feedback on this test?" and then **Yes, move on** / **Not yet**. Record the tester's words exactly, plus your own check of whether the skill did what the test checks (pass, fail, or unsure, and why).

## Clean sets (Test mode 5)
There are two clean sets (see Tests): set 1 is tests 12 to 20 (setup), set 2 is test 21 (demo); each runs in its own new chat. For each clean set: send (or download) the results so far first. Ask the tester to make sure they have their passphrase written down (they type it in the new chat and at the restore); never write it in the chat yourself. Run `testmode --clean-set <n>` (`TEST_CLEAN_SET`: `testing/` is emptied, the backup kept). Then remove the skill's two memory lines (passphrase and Local Data location; never their other memories), keep the one backup line, and say: open a new chat and type "<skill name>: continue test mode, set <n>". The set then runs from a true first launch.

**"continue test mode, set <n>"** (a new chat): Startup 1-4 as usual (with the extension the Local Data folder is found by itself; the tester types their usual passphrase at the passphrase step). Right after `UNLOCKED`, run `testmode --continue --set <n>` (`TEST_MODE_CONTINUED`; `TEST_MODE_NOT_RUNNING`: no test run is in progress, so say so and go on normally), then `startup`: it prints `FIRST_LAUNCH` from the emptied `testing/`, and the set's tests follow setup as a new user would see it.

## Results (Test mode 6)
- Each chat's results go in the Test results section of the feedback file (one section per test), and are sent or downloaded before the chat closes, never saved for later.
- **The log** for each test: each script command's run time (`USAGE_STEP`, with `--step`), the script's output lines, each question and its buttons, what was saved and where, and anything that failed (for example on the free plan). Never the passphrase or schedule links.
- **Testing-only changes** to the schedule or roster: log them as testing, list them at the end ("Any of these meant for real?"), and flag each in the feedback for the maintainer's review with the reason. Never prefill them anywhere; nobody can change someone else's data.
- **Overriding into real settings:** only with a double confirmation. Name exactly what would change, ask "Save this to your real settings?", then "Are you sure? This changes your everyday settings, not just the test." Then save it with `save --live "<key>: <value>"` (the only way anything reaches `live/` during test mode). Anything less stays a testing change. Log and flag each override.

## Restore and finish (Test mode 7)
After the last chat's results are sent or downloaded: run `testmode --end` (`TEST_MODE_OFF`: `live/` restored from the backup, this work folder back on `live/`; `--no-restore` only when the tester made double-confirmed overrides they want to keep), put the passphrase and Local Data location back in memory (the tester types the passphrase once), check the skill starts normally (`startup` shows their usual intro), remove the backup line, and tell the tester their settings are back. Thank them warmly: how many tests they finished and that their notes go straight to the maintainer, signed with the maintainer's name (from the feedback contact in the `SENSITIVE:` file).

## Tests (0.01.08)
Each test is tagged **saved settings** or **clean**, with a rough time. "New" marks what's new in this build (the Only what's new choice).

Chat 1 runs every saved-settings test; chat 2 is clean set 1; chat 3 is clean set 2.

| # | Test | Tag | New | Minutes | Checks |
|---|---|---|---|---|---|
| 1 | Startup order | saved settings | new | 3 | Reviews this chat's startup, which already ran: banner, known issues and disclaimer before the passphrase; one item per message; INTRO word for word; the task waits until `NEXT:`. Its commands ran before test mode, so log them as "before test mode" (no `USAGE_STEP`) |
| 2 | Answer buttons | saved settings | new | 2 | One question per message, at most 4 buttons, content shown before the question, numbered list over 4 choices |
| 3 | Other chats | saved settings | new | 3 | The tester opens a second chat during this test; it gets the `OTHER_SESSION` line and never has to close (Test mode 1's close request is only for chats open before test mode) |
| 4 | Role question | saved settings | new | 2 | Clinician-administrators only; last time's role marked (default) |
| 5 | Trade Shifts search | saved settings | | 5 | Settings summary, "show me everything", results table and list |
| 6 | Few results and "why" | saved settings | new | 4 | Loosening ladder with back-to-back last; "why wasn't Dr. X offered?" gives every rule |
| 7 | Messages and Outlook (0.01.07 test 19) | saved settings | | 4 | Delivery asked before drafting; Outlook note; copy-paste when too long |
| 8 | ML giveaway (0.01.07 test 21) | saved settings | | 3 | Give it away skips Availability and Settings |
| 9 | Privacy (0.01.07 test 22) | saved settings | | 2 | A typed password is not repeated or saved |
| 10 | Blocked-date sharing | saved settings | new | 3 | Asked only when their blocks differ from the roster |
| 11 | Wrap-up and close | saved settings | new | 3 | Anything else?, feedback, close message |
| 12 | First launch and Name check (Setup 1) | clean | | 3 | Name check tries; Did you mean |
| 13 | Help level (Setup 2) | clean | | 1 | Order and default |
| 14 | About You and Role Check (Setup 3) | clean | new | 4 | Side-panel page; Save copies one line to paste |
| 15 | Usage data and plan (Setup 4) | clean | new | 1 | One line; plan as a numbered list |
| 16 | Allowed websites and the beta (Setup 5) | clean | new | 3 | The check and the walk-through |
| 17 | Location and Shift Time Preferences (Setup 6) | clean | new | 4 | Slider page; Save copies one line to paste |
| 18 | Back-to-back shifts (Setup 7) | clean | new | 1 | Three choices; "let others ask" line |
| 19 | Dates you can't work (Setup 8) | clean | new | 3 | ShiftAdmin vacations shown; a shift-time-only block or exception is explained and confirmed |
| 20 | Save and check (Setup 9) | clean | new | 1 | `setupcheck` finds nothing missing |
| 21 | Demo | clean | new | 3 | "demo" at startup; nothing saved |
| 22 | Swap Locations (0.01.07 test 18) | saved settings | new | 3 | Sites to move to come from their ratings (Swap Locations 2) |
| 23 | Pickup Moonlighting (0.01.07 test 20) | saved settings | new | 3 | The Available Shifts file's date is said once; an old file asks Use it anyway / I'll download a new one |
