# Startup: Schedule links (Schedule, Startup 13)

**Version:** 0.01.82

Read when `refresh` (or `newlink`) prints `FETCH_FAILED`, `NEW_LINK_INVALID`, `NEW_LINK` or `SCHEDULE_PROBLEM`. Link IDs and `LINK_ATTEMPT` are in SKILL.md (Schedule links).

- **`FETCH_FAILED: BLOCKED`:** offer to walk them through adding `www.shiftadmin.com` to allowed domains, or have them attach the schedule file: give them the most reliable link from SKILL_SENSITIVE.md to open in a browser, save the `.ics` file and attach it; then `refresh --ics <file>`.
- **`FETCH_FAILED: LINK_REJECTED`:** give the make-your-own-link steps: ShiftAdmin → Group Schedule → Schedule: *Cincinnati CDEM* → Go → **Subscribe**; Time Zone UTC, End Times Normal, Include Vacation checked, 24 Hour Events Normal; copy the link in the grey box into the chat. Run `newlink` with it and the primary user's name. If the site is blocked too, they can open the link in a browser and attach the file; once `refresh --ics` shows a valid schedule, ask for the link too so it can be saved and passed on, then run `newlink`.
- **`NEW_LINK_INVALID`:** explain the problems; a fixed link goes through `newlink` again; to continue anyway, run it again with `--keep` (this session only, not saved). **`NEW_LINK: <id>`:** the script saves the ID and link in Local Data as theirs (works) and keeps the FEEDBACK line.
- **`SCHEDULE_PROBLEM`:** explain each problem and its fix, then ask: fix it now, or continue knowing results may be off (repeat that warning with the results). Record it in system health. An attached schedule file is also logged there.
