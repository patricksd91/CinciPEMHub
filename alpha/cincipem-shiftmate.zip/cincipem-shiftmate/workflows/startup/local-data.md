# Startup: Local Data folder (Startup 2)

**Version:** 0.01.82

Read when neither a `shiftmate` tool nor a connected Local Data folder is available, when the script prints `LOCAL_DATA_MISSING`, or when the folder moved. No searches run without Local Data. There's no memory fallback.

## What to say (first launch, or the folder isn't found)
"This skill keeps your settings, feedback and usage logs in a folder on your computer, CinciPEM ShiftMate Local Data, instead of in Claude's memory, so your memory stays uncluttered and fast. It goes in your home folder (the folder with your user name), outside Documents and OneDrive or iCloud. Usage logs are always kept there; turning off Auto-send usage data and feedback only stops them being sent."
Buttons: **Create it there** (default) / **Choose a different place** / **I already have one**. There's no opt-out.

- **Choose a different place:** ask where (a folder outside Documents, OneDrive and iCloud, and never inside the skill's own folder: the script refuses that with `ERROR: Local Data folder refused`). With the extension (Way 1), the place is the extension's setting: walk-me-through users get these clicks: in Claude Desktop open **Settings**, then **Extensions**, click **CinciPEM ShiftMate** (its settings or **Configure** button), set **Local Data folder** to the folder they chose (Browse, or paste the path), save, then start a new chat. Check it with `shiftmate_info`. Without the extension (Way 2): create or pick that folder and connect it as in Way 2, step 2.
- **I already have one** (memory was cleared, a reinstall, or the folder moved): ask where it is, then check it's a real Local Data folder (the script reads `live/system/format.json`; `shiftmate_info` or the first command says if it isn't), then go on to the passphrase. If the check fails, say so and offer the other two buttons again.
- **Folder moved** (memory's location doesn't open): ask where it went; if it's gone, offer to create it again.
- Web or phone chat: the skill needs the Claude desktop app on their computer. Say so, recommend the desktop app, and stop.

## Way 1 (recommended): the ShiftMate desktop extension
Walk-me-through users get one step at a time; wait until each is done.
1. Download `cincipem-shiftmate-<version>.mcpb` from the ShiftMate release page on GitHub (the link from the announcement email).
2. In Claude Desktop open **Settings**, then **Extensions**, and install the file from there (drag it in from Downloads, or use the install button and pick it). Double-clicking the file in Downloads works on some computers but not all, so lead with Settings.
3. Click **Install**. Leave the Local Data folder setting blank (the standard place) unless they chose a different place.
4. Make sure the extension is turned on, then start a new chat (or come back to this one).
5. No Python install is needed: the extension brings its own. The first start downloads it (about a minute, needs internet); after that it starts quickly. If the first start fails with no internet, or the hospital network blocks the download, try again on another network, or use Way 2.
6. The first time Claude uses the tool, Claude Desktop asks to allow it. Choose **Allow always** so it doesn't ask every time. A prompt left unanswered makes the tool time out; if that happens, answer it and Claude runs the step again.

**Check it worked:** call `shiftmate_info`. A `LOCAL_DATA_MOVED` line (an older test build's folder moved to the home folder): tell them in one line. It lists the extension and engine versions and the Local Data folder (exists, writable). The first launch creates the folder. Not writable, or a different folder than they wanted: open the extension's settings in Claude Desktop, fix the folder, and check again.

**Hospital-managed computer that blocks extensions:** Claude Desktop may say extensions are turned off by your organization, or the Install button is missing. Don't try to get around it. Use Way 2 instead, and if that's blocked too, suggest a personal computer or asking the hospital's IT team whether Claude Desktop extensions can be allowed.

## Way 2 (fallback): the Cowork working folder
1. Create the folder in the home folder. **Windows:** in File Explorer, click the address bar, type `%USERPROFILE%` and press Enter, then make a folder **CinciPEM ShiftMate Local Data**. **Mac:** in Finder choose Go, then Home, then File, New Folder, named **CinciPEM ShiftMate Local Data**. A folder already there (from the extension) is the one to use.
2. Connect it (in the folder picker, it's in the home folder: `%USERPROFILE%\CinciPEM ShiftMate Local Data` on Windows, `~/CinciPEM ShiftMate Local Data` on Mac): choose it as the working folder for this Cowork chat, or create a Cowork project named **CinciPEM ShiftMate** with the folder attached and start ShiftMate chats in that project (so they don't have to connect it each time).
3. Claude checks it worked by writing a small test file into the folder and reading it back (then removes it or leaves the README the script makes). If that fails, walk through connecting it again.
4. Then run the script as in SKILL.md, Running the script (B): the app copied once per version into `<Local Data>/app/<version>/`, the work folder always in a temp folder outside the connected folder.

## After it works
- The first launch creates the folder's contents (`README.txt`, `live/`, `testing/`).
- Memory then keeps only two things for this skill: the passphrase and where the Local Data folder is (the way it's reached: the extension, or the path of the connected folder). Save the location to memory once it's confirmed. Never save settings, answers, feedback or logs to memory: the script saves them in Local Data and prints `SAVED:` lines.
- An older 0.01.07 memory block is still there: read `workflows/startup/move-from-memory.md`.
