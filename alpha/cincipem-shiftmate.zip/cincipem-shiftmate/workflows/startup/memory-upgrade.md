# Startup: Settings upgrade

**Version:** 0.01.08

Read when startup prints `MEMORY_UPGRADE`.

- From 0.01.08 the skill's settings live in Local Data, and the script upgrades its own files when a version changes the format; Claude doesn't rewrite anything.
- `MEMORY_UPGRADE` means memory still holds a 0.01.07 settings block: do the one-time move now, before anything else, never later: `workflows/startup/move-from-memory.md`.
- From format 3, the old preference order becomes the shift-time order (ratings "ask again"); `migrate-memory` does this.
- Where the line says to rank and rate location preferences, use the ratings page instead (Location and Shift Time Preferences (Setup 6), in `workflows/setup/main.md`): ratings 1 to 9, no ranking step. If they're busy, the script saves "ask again".
