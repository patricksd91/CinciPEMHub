# Startup: Passphrase problems

**Version:** 0.01.82

Read at Passphrase (Startup 4) when `unlock` prints `BAD_PASSPHRASE`, `PASSPHRASE_LOCKED`, `OLD_PASSPHRASE` or `OLD_PASSPHRASE_AGAIN` or when memory has no passphrase.

- `BAD_PASSPHRASE`: say how many tries are left, as it says (5 tries, then 24 hours locked; never hint how close it was); ask for the current passphrase and save it once it works. `PASSPHRASE_LOCKED`: explain kindly and stop. `OLD_PASSPHRASE`: say it's an older version's passphrase and when it changed (the first one isn't counted as a try; save `old passphrase tried: yes` and pass `--old-tried` to later `unlock` runs). `OLD_PASSPHRASE_AGAIN`: an older passphrase again; this one counts as a wrong try, so also say the tries left.
- No passphrase in memory: "What's the skill passphrase? It's in the email that announced the skill. You only need to enter it once; I'll remember it." Capitals, spaces and punctuation don't matter. Never write the passphrase into any file, message or feedback.
- Memory off: "Memory is off, so you'll need to type the passphrase each time (your settings are still kept in your Local Data folder). You can turn it on with the 'Generate memory from chat history' setting." Then Claude also needs the Local Data location each time.
