# Startup: New version

**Version:** 0.01.08

Read on the first launch of a new version (Version check (Startup 7) and Updates and news (Startup 8)), when startup prints `WHATS_NEW`, `DOWNGRADE`, `NOW_AVAILABLE`, `THANK_YOU_PERSONAL`, `THANK_YOU`, `USAGE_OPT_IN_ASK`, `BETA_ENROLLED`, `ALPHA_ENROLLED`, `COUNTER_ASK_AGAIN`, `HOLIDAY_SPLIT`, `PROFILE_DIFF`, `PROFILE_CAUGHT_UP`, `PROFILE_STUCK` or `BLOCKS_ROSTER_DIFF`. Do them in the order printed, one item per message. They come after the intro (Startup 5), so the intro already lists what a new enrollment allows.

## Enrollment
- `BETA_ENROLLED`: tell them in one line that they're now in the beta program, and that they can say "leave the beta" any time.
- `ALPHA_ENROLLED`: one line: they installed an alpha, so they're alpha-enrolled (the same workflows and testing program as the beta, called alpha); they can say "leave the alpha" any time. When `TEST_MODE` follows later in this startup, open that offer with one connecting line: "Because you're now in the alpha, you can also run this build's testing program." (the same for `BETA_ENROLLED`, with "beta"). It also comes on any launch of an alpha build for a set-up standard or advanced user whose beta program is still `never joined` (not `opted out`; never walk-me-through users); the script saves `beta program: alpha`.
- `ALPHA_STILL_ENROLLED` (read `workflows/updates/main.md`): add its line to What's new, word for word.

## Holiday ratings
- `HOLIDAY_SPLIT`: their one Holiday rating from before now applies to Holiday day, evening and overnight (moved by 0.01 where needed so nothing ties; the script saved them). Say so in one line together with What's new. The ratings page on the rerun shows these saved ratings to confirm.

## What's new (Version check, Startup 7)
- `WHATS_NEW`: show the whole list as "What's new since <version>", in plain words, as its own message. For `DOWNGRADE`, say which beta features they no longer have.
- `NOW_AVAILABLE`: a feature left the beta since their last version. Add one line to What's new: "Now available to everyone: <name>." Make it the intro highlight.
- `THANK_YOU_PERSONAL` / `THANK_YOU`: the personal note first, warmly, then the group messages.
- `USAGE_OPT_IN_ASK`: after the thank-yous, ask once, politely, as it says. **Yes** / **No**.

## Counters (plan 6.7)
Counters (offer schedules, reminders, run counts behind an offer) and the `never ask` list are kept in Local Data (profile/counters); the script reads them itself.
- On the first launch of a version, the counters that version changed restart from zero (the script does it and leaves the rest alone).
- `COUNTER_ASK_AGAIN`: they asked not to be asked about something this version changed. Don't ask now. When it next comes up, ask once more: say you know they asked not to be asked, what changed and why it might be worth another try. On no, save `never ask: <it> (since <version>)` and don't ask again until a later version changes it.

## Confirm your settings (Updates 5)
- `RERUN_SETUP`: read `workflows/setup/rerun.md`.

## Profile, roster and role checks (Startup 11)
- `PROFILE_DIFF`: show the difference in its own message, then ask which to keep: **Keep mine** (default) / **Use the roster's** / **Something else (type it below)**. Save the choice and put it in Roster updates.
- `PROFILE_CAUGHT_UP`: thank them ("Your update made it into the roster") (the script drops the saved override).
- `BLOCKS_ROSTER_DIFF`: blocked-date items (future ones) differ between the roster and their saved blocked dates; printed once per chat, in clinician mode only. Run `myblocks --name "<roster name>"` as it says and show the differences (📅, dates and shift times only). When the line asks, ask once whether the roster's items are still right (searches use them either way). Put any change in Roster updates: their own dates only, never what they're for.
- `PROFILE_STUCK`: tell them: "If I keep asking you this after every update, please mention it in your feedback; it means something isn't working on our end."

## Plan and model (Questions that are due, Startup 12)
- `PLAN_ASK` and `MODEL_SELF_REPORT`: see Usage data and plan (Setup 4) in `workflows/setup/main.md`.
