# Startup: Locked out

**Version:** 0.01.08

Read when startup prints `LOCKED_OUT`.

- `LOCKED_OUT`: explain kindly, say when they can try again in their local time ("tomorrow at 8:00 pm"), how someone new can ask to be added, and stop.
