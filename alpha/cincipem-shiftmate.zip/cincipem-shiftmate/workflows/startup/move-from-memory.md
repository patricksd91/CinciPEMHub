# Startup: Moving settings from memory to Local Data (0.01.07 to 0.01.08)

**Version:** 0.01.82

Read when memory still holds a `CinciPEM Shift Swap – memory format 4` block (primary user or clinician) after Local Data folder (Startup 2) and the passphrase are done. It runs once.

**Where Local Data is:** an upgrader's memory has no Local Data location yet. With the desktop extension (a `shiftmate` tool), use its folder (`shiftmate_info` shows it) without asking, and save that location to memory. Without the extension, read `workflows/startup/local-data.md` first (its first-launch question), then come back here after the passphrase.

1. Tell the user in one line: "Moving your saved settings from Claude's memory into your Local Data folder, so your memory stays uncluttered."
2. Run `migrate-memory --memory "<the block>"` once per block: the primary user's block first, then each clinician's block (an administrator's clinicians), each exactly as it is in memory. Never pass the passphrase line in it; the passphrase goes only through unlock. (Way B: the block may also be put in a file in the work folder and passed as `--memory <file>`.)
3. The script prints one `MIGRATED: <key> -> <Local Data file>` line per moved setting, then `MEMORY_CLEANUP: remove these memory lines: …. Keep only: …`. Old shift-time and location ratings are moved to where searches read them (best first, with the ratings page's names; `MIGRATED_HOLIDAY` when the one old Holiday rating became the three holiday times); `MIGRATED_SETTINGS_MODE: summary` when they had saved search settings (they start in summary mode). The install date moves too, so the banner shows it. `ERROR` or `LOCAL_DATA_MISSING`: explain it in plain words, log it in system health, and remove nothing.
4. Only after the script confirms the move, remove exactly the memory lines `MEMORY_CLEANUP` names. Keep only the passphrase and the Local Data location. If the script failed, remove nothing and try again next launch.
5. Say in one line that it's done ("Your settings are now in your Local Data folder."), then go on with startup.

Never copy the moved settings back into memory later.
