# Startup: Role question (Startup 10)

**Version:** 0.01.08

Read when `startup` prints `ROLE_QUESTION`, or when the name check prints `SETUP_MATCH … | ALSO_ADMIN`. Only for clinician-administrators (admins.csv names their staff.csv row). Everyone else skips this step.

## At startup
- `ROLE_QUESTION`: startup stops here, after the version and update checks. Ask: "Which role are you working in today?" **Clinician** / **Administrator**. Mark last time's role **(default)**, as the line says ("(your usual)" is only for saved search settings). The INTRO before it describes both roles, so don't describe either role again. If they ask what this means: as a clinician they use ShiftMate for their own shifts; as an administrator they run it for the clinicians they help.
- Then run `startup --role clinician|administrator --rest` and do what it prints (the rest of startup). The task from the first message waits until then; search commands refuse until then.
- Skip the question only when the first message makes the role **very** clear ("find trades for Dr. Example's 10/14 shift" as an administrator; "swap my 11/25 overnight" as a clinician). Then run the first `startup` with `--role` and don't ask. When in doubt, ask.
- **Administrator:** read `workflows/administrator/main.md`. They skip their own profile checks, role check, preference questions and blocked dates. Update offers, What's new, known issues and feedback still happen.
- **Clinician:** an ordinary user (help level, beta rules and all).

## At the name check (setup)
- `SETUP_MATCH … | ALSO_ADMIN`: ask the role question now, during setup.
  - **Administrator:** run administrator setup (`workflows/setup/administrator.md`) and save `clinician setup: not done`. Tell them in one line that they also have clinician mode, and that its setup runs the first time they start as a clinician.
  - **Clinician:** the full clinician setup; save `clinician setup: done`.
- `CLINICIAN_SETUP_DUE` (their first start as a clinician): run the clinician part of setup (read `workflows/setup/main.md`): About You and Role Check (Setup 3), then Location and Shift Time Preferences (Setup 6) to Save and check (Setup 9). Then save `clinician setup: done`.

## Saved
`last role` (saved by the script), `clinician setup` (done or not done) and `clinician settings confirmed` (the version whose clinician settings they last confirmed; see `workflows/setup/rerun.md`). These are kept in Local Data.
