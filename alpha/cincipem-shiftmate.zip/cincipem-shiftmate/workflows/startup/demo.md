# Startup: Demo mode (Demo or test mode, Startup 9)

**Version:** 0.01.08

Read when someone asks for "demo": typed at any point during startup, or a roster name followed by "Demo" at the name check ("Alex Example Demo"). Anyone can run it. Nothing is saved.

## Start (Demo 1)
- The demo itself starts at Demo or test mode (Startup 9), but the script must know from the start: when "demo" is in the first message, run the first `startup` with `--demo` (a plain `startup` on a first launch would begin setup). When "demo" is typed later in startup, run `startup --demo` then. The banner, disclaimer (Startup 3) and passphrase (Startup 4) are already done; a set-up user also gets the intro and update lines before `DEMO`. A never-set-up user gets no intro.
- Still required: unlocking Local Data (Passphrase, Startup 4) and a real roster name. On a first launch memory has no passphrase yet: ask for the skill passphrase as `workflows/startup/passphrase.md` says (it's in the email that announced the skill); `unlock` then creates Local Data with it, and memory keeps it from then on, as for any first launch.
- **Never set up** (`DEMO_NAME_CHECK`): ask only the name check (Name check, Setup 1). Run `whoami --setup --name "<name> Demo"`. "Demo" isn't a try; a name not on the roster still is. `DID_YOU_MEAN`: after a yes, run it again with that exact name followed by " Demo". Then stop setup: no other setup question. Then follow the `DEMO` lines `whoami --setup` prints.
- A demo saves nothing to Local Data or memory (the script skips its saves and marks USAGE lines demo itself), except the name and passphrase try counts and its feedback (noted items, `FEEDBACK:` lines, usage rows and a file kept with `feedback --keep`, all marked demo, in the Local Data outbox). `session --close` saves nothing in a demo. Don't change `features used`, `last searches`, request history or your usual.

## Explain (Demo 2)
Say, word for word: "This is a demo. I'll use default settings and skip the setup questions, then take you straight to finding a shift trade. Nothing you do here is saved."

## Defaults (Demo 3)
- Help level Standard. If they ask for advanced, switch; never offer it.
- About you and role as the roster has them (`whoami --name`); no role override.
- `DEMO_DEFAULTS` says these; the search commands apply them themselves while a demo runs: the default shift-time order and no location preference (their saved ratings aren't used; leave out `time_order` and `site_order`); no blocked dates (no `blocks` or `vacations`); back-to-back off.
- No allowed-websites offer, no preference page, no beta question, no plan question.
- Settings (Trade Shifts 4): there's no usual or most recent in a demo. Show the defaults in one short line (no question) and go on.

## Schedule (Demo 4)
- Run `demo --schedule`: the live schedule, else the archived copy. They attached their ShiftAdmin calendar file: add `--ics <file>` (it prints `DEMO_SCHEDULE`, and the demo uses that file). `DEMO_NEEDS_PASSPHRASE`: run it again with `--stdin` and the passphrase on standard input.
- `DEMO_ARCHIVED`: say its line word for word. Don't walk them through allowed websites.
- `DEMO_NO_SAMPLE`: say the demo needs the schedule site this time, and offer to end the demo.
- `LINK_ATTEMPT`: nothing is saved in a demo; only log a rejected or blocked attempt in system health. The schedule copy it downloaded is the normal 2-hour copy in the work folder (not demo data); leave it.

## Then Trade Shifts
Go straight to The shift (Trade Shifts 2) in `workflows/trade-shifts/main.md` (who it's for is Myself). Every usage line and feedback item from the demo is marked **demo**. The wrap-up and feedback work as usual; the wrap-up saves nothing except unsent feedback marked demo (in the Local Data outbox). Someone never set up has no Auto-send usage data and feedback setting: treat it as off (ask before sending, or offer the file).

## End
Run `demo --end` after the wrap-up, or on close. It prints `DEMO_ENDED`.
