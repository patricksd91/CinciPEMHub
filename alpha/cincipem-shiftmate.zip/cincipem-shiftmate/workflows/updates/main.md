# Updates

**Version:** 0.01.82

Read when startup prints `UPDATE_OFFER`, `BETA_ASK_ONCE` or `ALPHA_STILL_ENROLLED`, or when the user asks to update, what's new, or to join or leave the beta or alpha. Update offers happen in either role (clinician or administrator).

## Channels
- Published versions are at github.com/patricksd91/CinciPEMHub; `update` reads them from `raw.githubusercontent.com`.
- A version ending in .00 is stable. 0.01.08 is an **alpha** (banner "0.01.08 alpha"): an early preview, not an official beta. Anything else is a beta.
- `beta program` (in Local Data) is one of: `never joined`, `in` (beta), `alpha`, or `opted out`.
- **Alpha works exactly like beta** (the same workflows and the same testing program), but call it alpha.
- Installing a beta puts the user in the beta program (except walk-me-through users). Installing an alpha makes them alpha-enrolled.

## Is there a newer version? (Updates 1)
- Startup checks by itself. Who is offered what:
  - Alpha-enrolled: the newest version of any kind (alpha, beta or stable).
  - In the beta: the newest beta or stable. Never an alpha, unless they ask to check for one: then run `update --check ... --alpha`.
  - Everyone else: newer stables only. Never a beta, except through `BETA_ASK_ONCE`, and never to walk-me-through users.
  - The maintainer is always offered the newest of any kind (`update --check --name "<roster name>"`; startup does this itself).
- **"Update" or "check for updates" any time:** `update --check --installed <version> --beta-program "<theirs>"`. The script reads the last beta asked and never-ask from Local Data. It prints the notes.

## Offer (Updates 2)
- **`UPDATE_OFFER: <version>`:** show the release notes printed below it as "What's new in <version>". Ask: "Would you like to update now?" **Update now** / **Not now**.
- `NOTES_UNAVAILABLE`: say the notes couldn't be loaded and give the download page link.
- **Not now:** save `update snooze until` = 24 hours from now. Go on with the rest of startup (Updates and news, Startup 8).
- **`BETA_ASK_ONCE: <version>`** (people who left the beta): ask once, showing the notes printed above it: **Yes, update this time** (`update --download beta --join no`) / **Yes, and opt back into the beta program** / **Never ask me again**. Save the answer.

## Install (Updates 3)
- Run `update --download <channel> --out <the folder for files you share with the user>`. Share the `.skill` file it names so they can click **Save skill**. The new version works in a new chat.
- `BETA_JOINED`: save `beta program: in`. `BETA_NOT_JOINED`: leave it. `ALPHA_ENROLLED`: tell them in one line and save `beta program: alpha`.
- An alpha user who installs a beta gets `BETA_ENROLLED` and is never offered an alpha again unless they ask.
- **No Save skill button, `CHECK_FAILED` or `DOWNLOAD_FAILED`:** give the manual steps: open github.com/patricksd91/CinciPEMHub, click the stable (or beta, or alpha) download link, then in Claude go to Customize → Skills → + → Create skill → Upload a skill. If the site was blocked, suggest adding `raw.githubusercontent.com` to allowed domains.
- `UPDATE_NOT_PUBLISHED`: nothing to update to yet.
- Log every check and download in system health.

## First launch of the new version (Updates 4)
- Startup finds it at Version check (Startup 7) and prints What's new (`workflows/startup/new-version.md`).
- `ALPHA_BUILD` (first launch of an alpha) and `ALPHA_ENROLLED` work like `BETA_BUILD` and `BETA_ENROLLED`: tell them in one line (the script saves `beta program: alpha`). `ALPHA_ENROLLED` also comes on any launch of an alpha build for a set-up standard or advanced user who never joined (not one who opted out, and never walk-me-through users).
- **`ALPHA_STILL_ENROLLED`:** an alpha-enrolled user installed a stable and stays alpha-enrolled. Add its one line to What's new, word for word.

## Confirm your settings (Updates 5)
- Startup prints `RERUN_SETUP` at every new version: read `workflows/setup/rerun.md`. It asks "You're running a new version (<version>). Here's what you have saved." **Looks right** / **Change something** / **Start fresh**.
- Unsent feedback always carries over to the new version. It's never deleted by an update or a fresh start.

## Any time
- **"What's new?"**: `whatsnew --from <the version before this one> --channel <theirs>`.
- **"Install the latest stable"**: offer it even if it's older than their beta or alpha. Show what they'd lose with `whatsnew`.
- **"Join the beta"** (or "join the alpha"): save `beta program: in` on a stable or beta build; on an alpha build (like 0.01.08) save `alpha`, whichever word they used, and say they're alpha-enrolled (the same as the beta, called alpha). Walk-me-through users: see Help level in SKILL.md.
- **"Leave the beta"** or **"leave the alpha"**: save `beta program: opted out`. Tell them they'll get stable versions only and can rejoin any time just by asking.
- After joining or leaving mid-chat, run `startup --workflows-only` and use its fresh `WORKFLOWS` line from then on (the one from startup is out of date).
- **Beta and alpha testers and feedback:** handled in the wrap-up, which reads `workflows/wrap-up/beta-warnings.md` only when they decline to send feedback; don't read it here.
