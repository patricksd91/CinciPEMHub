# Administrator mode

**Version:** 0.01.82

Read when the primary user is working as an administrator: a non-clinician administrator (from `data/admins.csv`) every run, or a clinician-administrator who answered **Administrator** at the role question (Role question, Startup 10; `workflows/startup/role-question.md`). Administrator mode starts right after that answer. Administrator mode is a mode, not a workflow. Workflow abbreviations: TS Trade Shifts, SL Swap Locations, PM Pickup Moonlighting, SIP Schedule Inquiry and Planning, COH Call Off Helper.

## Help level
- Help level still applies in administrator mode: walk me through, standard or advanced, from their own setting. Different administrators need different amounts of help.

## What they skip (Administrator 2)
- Administrator mode skips everything about their own clinical self: their own profile differences, role check, preference questions and their own blocked dates. `startup --role administrator` already leaves these out.
- Update offers, What's new, known issues and feedback still happen, in either role.
- On a new version, they confirm only the administrator part of their settings. Their clinician settings are confirmed the next time they start as a clinician.
- The schedule isn't loaded at startup: `refresh` runs right before the first command that needs it (Schedule, Startup 13; SKILL.md, Running the script), so an administrator who only picks a coming-soon workflow never loads it (Schedule Inquiry and Planning loads it before its first search).

## Which workflow (Administrator 3)
- Use the `WORKFLOWS` line from startup. Ask "What would you like to do?" **Trade Shifts (TS) for a clinician** / **Swap Locations (SL) for a clinician** / **Schedule Inquiry and Planning (SIP)** / **Call Off Helper (COH)**. These 4 buttons, and no **Something else** button: an exception to SKILL.md's rule (they can still type anything). Skip the question when their message already says which.
- **Schedule Inquiry and Planning:** when it's picked (or their message asks for one of its tools), read `workflows/schedule-inquiry/main.md`. Don't ask Which clinician.
- **Call Off Helper** picked: run `comingsoon --workflow call-off-helper --admin` and read the file it names. Don't ask Which clinician. `COMING_SOON` (a pick): its line and this menu question go in one message. Only asked what it is (not a pick): add `--ask`; say its `COMING_SOON_INFO` line, then go back to the question they were on (the one rule for every coming-soon question, as in `workflows/coming-soon/`).
- **No Pickup Moonlighting.** If asked: "Pickup Moonlighting needs the clinician's own ShiftAdmin download, so it's only for clinicians running the skill themselves."

## Which clinician (Administrator 4)
- Only for Trade Shifts and Swap Locations, which run for a clinician.
- Ask: "Who are you running this for today?" The default is the last clinician they helped; there's no default the first time. Skip it when their message already names the clinician.
- Run `whoami` for that clinician. `DID_YOU_MEAN`: the name wasn't an exact match; ask (the name it gives, Yes / No) and, after a yes, run `whoami` again with that exact name. Never go on with a name that wasn't confirmed.
- **The first time for a clinician** (`whoami` prints `ADMIN_FIRST_TIME`; `ADMIN_CLINICIAN_KNOWN` means their settings were saved on an earlier run): show the clinician's role from `whoami` and ask the administrator to confirm it (this is the role check, done for the clinician instead). Confirmed: `save --clinician "<their roster name>" "role confirmed: <today, YYYY-MM-DD>"`; listed wrong: warn as setup/main.md (About You and Role Check 4) says, pass `role_override` in their searches and add a critical Roster updates item. Then set up that clinician's locations, shift times, back-to-back and dates they can't work (Location and Shift Time Preferences (Setup 6) through Dates you can't work (Setup 8), in `workflows/setup/main.md`). Save their answers with `save --clinician "<their roster name>" …` and the ratings page line with `prefs --line "…" --clinician "<their roster name>"`, so they go in that clinician's own Local Data files, never the administrator's.
- If a clinician's block says "ask again" for a preference, ask it at their first search of the session.

## The workflow (Administrator 5)
- Read the workflow's file (`workflows/trade-shifts/main.md` or `workflows/swap-locations/main.md`) and run it for the clinician. Use the clinician's name, not "you" (request field `who`).
- **Drafts** are written from the administrator on the clinician's behalf ("I'm helping Dr. Example find a trade for…"), signed with the administrator's name and credentials, with the clinician copied (their email from `contacts`, as `cc` in the Outlook request).
- **What they tell you about a clinician** (preferences, contact info, role, credentials, blocked dates) goes in that clinician's Local Data files (the script saves it) and beats the roster and preference files for that clinician's searches. A clinician's search uses only that clinician's saved settings and the roster's preference files, never the administrator's own ratings, usual or blocked dates (the script prints `LOCAL_DATA_CLINICIAN`; send `clinician` and `who` in every request). Contact info, role and preferences also go to feedback (Roster updates) for the roster. Blocked dates are never sent to update the roster.
- When the workflow ends, read `workflows/wrap-up/main.md`. Blocked-date sharing (Wrap-up 2) is skipped. **Another search** comes back to Which workflow (Administrator 3).
