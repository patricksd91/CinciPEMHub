# Trade Shifts: Few results and the loosening ladder (Search, Trade Shifts 5)

**Version:** 0.01.82

Read when a search prints `FEW_RESULTS` (Trade Shifts or Swap Locations).

- `FEW_RESULTS` (under 10): explain why in plain words from `WHY_COLLEAGUES` and `WHY_TRADES`.
- Then the `LADDER`, in the script's order: steps that cost only the user first, then changes that cost colleagues, and "allow back-to-back shifts" always last. Each step is kept only if it adds options, and each total includes the steps above it. A "together" step names changes that only help combined.
- `LADDER_END`: offer to apply any step, or to loosen anything else they'd like. Up to 4 choices go on buttons. When it ends with `CHOICES:`, show the steps as a numbered list in the chat (with each running total) and let them type the number; add **Something else (type it below)** as a button.
- **Several shifts** (Swap Locations prints one `FEW_RESULTS` and `LADDER` per shift): one ladder question per shift, in date order, each naming its shift.
- A step they pick applies to this run only (see `workflows/trade-shifts/your-usual.md`). Re-run with it and go on to The list (Trade Shifts 6).
- "Allow back-to-back shifts": re-run with `"back_to_back": true` (12 h 15 min in a row at most).
- `DATES_LIMITING`: suggest wider dates; re-run only if they want.
- `NARROWED`: the options were narrowed by their own choice; don't offer to loosen what they just narrowed.
- Record the failure and what fixed it as a lesson item (`fbname --item lesson`).
