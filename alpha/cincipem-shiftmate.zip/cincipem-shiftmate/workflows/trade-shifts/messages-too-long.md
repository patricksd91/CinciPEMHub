# Trade Shifts: Too long for a link (Draft, Trade Shifts 9)

**Version:** 0.01.08

Read when `outlook` prints `TOO_LONG`.

- `TOO_LONG`: tell them a direct link won't work for that email and give only the `COPY_TEXT` block (it includes the note); don't repeat the draft.
- Tell them to copy it and paste it into a new email in Outlook (or their texting app). For several recipients, the To line in the block is ready to paste as is.
