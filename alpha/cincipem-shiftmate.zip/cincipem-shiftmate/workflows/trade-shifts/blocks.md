# Trade Shifts: Blocked dates (Availability, Trade Shifts 3)

**Version:** 0.01.08

Read at **Block anything else?** in Availability (Trade Shifts 3), when a script line prints `ROSTER_BLOCKS`, or whenever the user blocks a time or says they can work a vacation day. Swap Locations and Pickup Moonlighting use it too.

## Block anything else?
Ask step-by-step users one question: "Is there anything else you'd like to block off, like a date, part of a day, or something that repeats?" **No** (default) / **Yes (type it below)**.
- Kinds of block (`blocks` field; an optional `label` is for the user's own reference only: the script never prints it, and it's stored in Local Data, so keep reasons out of it): a date; a date and shift time (`"cat": "evening"`); a range; a repeating block (`"weekday": "Wed"`, with `"nth"` for "3rd Thursday"); exact hours (`{"date": "2026-12-10", "hours": "14:00-18:00"}` leaves out only shifts that overlap those hours); one site only (`"site"`).
- **Exact hours (9.9):** if the hours cover a whole shift time, block that shift time. If not, ask: **Just those hours** / **Every shift time that overlaps** (the exact hours are saved and shared when they choose hours).
- The script saves each new block in the clinician's Local Data (blocked-dates: one-time blocks, recurring blocks, vacations not in ShiftAdmin yet), then re-run `avail`.

## Only a shift time (rule of 9/27)
When someone blocks only a shift time or exact hours, or says they can work only part of a vacation day, tell them how it works and confirm what they meant, in **one** question per block (this is the only confirmation for that block: it repeats the date back, so don't also ask them to confirm the date). The same wording and buttons are used in setup (Setup 8).
- **Date format (the one rule, setup included):** month/day, as in 11/25; add the year only when the date isn't in the current year (1/5/27).
- A block: "That blocks only the evening shift on 11/25. Day and overnight shifts that day can still be offered. Is that what you meant?" **Yes, only evenings** / **Block the whole day**.
- A vacation day: "That frees only the day shift on 12/9. The rest of that vacation day stays blocked. Is that what you meant?" **Yes, only days** / **Free the whole day**.
- A block they already confirmed (in setup or earlier in this chat) isn't asked about again.

How to run it: a whole vacation day goes in `work_on_vacation` as the date. One shift time goes in as `"<date> evening"` (or day, overnight, or `HH:MM-HH:MM`). The script frees only that shift time and prints `WORK_ON_VACATION`.

## ROSTER_BLOCKS
The clinician's own blocked dates on the roster were used, together with the ones saved in Local Data. When Local Data and the roster disagree (a date in one but not the other, or a different shift time), show both and ask which is right, or let them edit it. Ask about each difference once (the script saves the answer). If the user says one no longer applies, re-run with `"roster_blocks": false` plus the blocks that still apply. Put the change in feedback only when the dates are the primary user's own. When running it for someone else, it's saved in that clinician's Local Data files and never sent to update the roster.

