# Trade Shifts: Nothing to loosen (Search, Trade Shifts 5)

**Version:** 0.01.82

Read when a search prints `NOTHING_TO_LOOSEN` (Trade Shifts or Swap Locations).

No setting would add more options. Don't call it a short list. The reason lines after it are for "why" questions.
- **Some results:** say exactly "No search setting I can loosen would add more options." You may add one short suggestion on how to go on (for example, other dates, or asking a colleague directly). Then The list (Trade Shifts 6).
- **Zero results (No one fits):** say exactly "No one fits these dates and settings." A one-line reason is fine. Show no empty list. Ask what next: **Change something** (back to Settings, Trade Shifts 4) / **Try other dates** (back to Availability, Trade Shifts 3) / **I'm done** (to the wrap-up).
- Record the failure and what fixed it as a lesson item (`fbname --item lesson`).
