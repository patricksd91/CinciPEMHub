# Trade Shifts: Special cases (The shift, Trade Shifts 2)

**Version:** 0.01.82

Read right after the shift, only when it is a Jeopardy, holiday or peri-holiday shift. Swap Locations also uses the holiday question.

- **Jeopardy:** only Jeopardy, or would they take a scheduled shift (`jeop_mode`)? Length limits don't apply to Jeopardy trades; say so if they'd take a scheduled shift.
- **Holiday or peri-holiday:** what would they take in return? Five choices, so show them as a numbered list in the chat (they type the number) with **Something else (type it below)** as the only button: 1. Regular (non-holiday) shifts only (default; leave out `holiday_mode`), 2. Only holiday shifts (`hol`), 3. Only peri-holiday shifts (`peri`), 4. Holiday or peri-holiday shifts (`both`), 5. All shifts (`all`: regular, holiday and peri-holiday). Peri-holiday: the pre-scheduled days around the holidays that follow the division's holiday calendar (glossary, "Holiday / pre-scheduled peri-holiday"); define it for walk-me-through users. Whatever they include stays checked in shift times for this search (with `all`, all 11 shift times), on top of the Shift times default. Trading a holiday for a regular shift is usually category E (worse for the colleague): say so and offer to include E for this search; if they add it, also put it in `"holiday_added": ["E"]`, so it isn't saved as part of their usual.
