# Trade Shifts: Running it for someone else (Who it's for, Trade Shifts 1)

**Version:** 0.01.82

Read when the user runs a search for someone else, not as an administrator (administrators use `workflows/administrator/main.md`).

- **Request fields:** `who` is the clinician's preferred first and last name ("Alex Example"), so the script's lines name them instead of saying "you". Also pass `primary` (the primary user's roster name).
- **Local Data:** the script keeps their own files (clinicians/<name>) for their preferences, usual and most recent settings, and dates, so they're reused. Their blocked dates are kept there and never sent to update the roster.
- **Their own info** (contact details, role, credentials) goes to feedback only and never changes what the roster says.
- **Messages:** drafts are from the primary user on the clinician's behalf.
- **Back-to-back:** follow the clinician's Back-to-back shifts (Setup 7) setting if their block has one; otherwise leave it off unless the user asks.
- Pickup Moonlighting is never run for someone else.
