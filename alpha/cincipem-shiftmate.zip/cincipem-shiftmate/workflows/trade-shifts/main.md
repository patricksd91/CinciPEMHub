# Trade Shifts

**Version:** 0.01.82

Read when the user picks Trade Shifts, or their message already asks for it. Open to every user, including the ML-shift branch. Swap Locations uses The list through Your usual (Trade Shifts 6 to 11).

Steps: Who it's for (Trade Shifts 1), The shift (Trade Shifts 2), Availability (Trade Shifts 3), Settings (Trade Shifts 4), Search (Trade Shifts 5), The list (Trade Shifts 6), Recipients (Trade Shifts 7), Delivery (Trade Shifts 8), Draft (Trade Shifts 9), Sent or not (Trade Shifts 10), Your usual (Trade Shifts 11). Always call a step by its name first, then its number.

**In every request:**
- `who`: leave it out (or `"you"`) for the user's own search. For someone else, their preferred first and last name. The script's lines then say "you" or the name; use them as printed. For someone else, always talk about the clinician in the third person (their name, "they", "their"), never "you" or "your", in results and instructions alike.
- `back_to_back`: leave it out; the script uses their saved Back-to-back shifts (Setup 7) answer. **Yes, but only if I ask for it** means back-to-back options are included in their own searches, but colleagues can't be offered a trade that gives them one; **Yes, and let others ask me** means both; **No** means neither. Pass `true` only when someone whose answer is No asks for back-to-back shifts in this search (or takes the loosening ladder's last step). With it on, 12 h 15 min in a row is still the limit.
- `clinician`: leave it out for the primary user's own search (the script uses the roster name saved in About you); give it (the name `whoami` matched) for someone else and in a demo.
- `time_order` and `site_order`: leave them out; the script fills them from Local Data (the saved ratings, `LOCAL_DATA_INPUTS`). Send them only when the user gives an order in this chat. Usage lines are always collected (see the wrap-up).

**Delay messages:** before `avail`, `swap` or `locswitch`, run `wait --kind search` (`wide-search` for Show me everything) with `--past-ms` (this step's past times) (the script reads the last loading line from Local Data). `WAIT_NONE`: say nothing. `WAIT`: say its line first. `LOADING_LINE`: then that line on its own line, never next to an error.

## Who it's for (Trade Shifts 1)
See SKILL.md, under Every run. For someone else, read `workflows/trade-shifts/someone-else.md`.

## The shift (Trade Shifts 2)
Which day or days to trade out of. Run `shifts`. More than one shift that day (for example a regular shift and an ML or Jeopardy shift): ask which, one button each. Not working that day: say so and show the nearest shifts.
- **Special cases** (only when they apply): Jeopardy, holiday or peri-holiday: read `workflows/trade-shifts/special-cases.md`. **ML shift:** read `workflows/trade-shifts/ml-shift.md`.

## Availability (Trade Shifts 3)
Ask: "Tell me the dates you'd be willing to trade into: a few dates, a few ranges, or one range. I'll check your schedule and any blocked dates, and show you the days you're available and there are shifts you could trade into." **All available dates** (default) is always a button. Then run `avail` with `give_ids`, `into`, `blocks`, `vacations` and their usual `sites` (without sites, `PATTERN` can't show).
- `ASK_SHIFT`: no shift was named. Ask for the shift and dates; show no availability until then.
- Show `AVAILABLE_TO_TRADE_INTO` as "days you're available and there are shifts you could trade into". A date tagged "the day of the shift you're giving away": use those words.
- `PATTERN`: say it once in plain words ("your sites only have weekday evening and weekend day shifts").
- `NOT_AVAILABLE`: over 10 dates come as counts by reason; give the counts. A saved block shows only as "blocked" (a block's label is never printed or said). Re-run with `"not_available": "list"` only to answer about one date.
- `REST_LIMITS`: the 8 h rest rule leaves only part of that day. Give the limit with the date ("10/20, day shifts from 12:00 only"). Never call that date open all day.
- `VACATION_IN_RANGE`: "You have the following dates blocked off for vacation: <dates>. Are you available to work any of them?" Add the ones they can work to `work_on_vacation`, keep it for the `swap` request, and re-run.
- `WORK_ON_VACATION`: tell them a shift time frees only that shift time, and confirm that's what they meant. For "can't read it" or "not a ShiftAdmin vacation day", say so.
- **Block anything else?** Step-by-step users are asked this next (one question). Summary-mode users aren't asked; their blocks are in the summary, and **Change something** covers them. When you ask it, or when they block a time or say they can work a vacation day, read `workflows/trade-shifts/blocks.md` (how blocks work, `ROSTER_BLOCKS` and the shift-time rule).

## Settings (Trade Shifts 4)
Summary mode or step-by-step is saved as `settings mode` in the primary user's Local Data. Step-by-step users (to see whether a summary-mode offer is due), or when someone asks to switch modes: read `workflows/trade-shifts/summary-mode-offers.md`. Summary-mode users don't need it.
- **Summary mode:** show one summary of the settings (which set, and its buttons, are in `workflows/trade-shifts/your-usual.md`): the availability line; sites in their order; shift times; the two length limits; trade categories; list or table; back-to-back; blocked dates and recurring blocks; how they send requests. Add **what those settings leave out** ("This leaves out: overnights, VUC, shifts over 9 hours"). Mark anything from this conversation "(from what you just said)". **Change something** asks only about that. Everyone can edit in one message ("drop VUC, add evenings, max 9 h"): show the new summary and start. If they already said to use their saved settings, show the summary and start without asking.
- **Show me everything:** standard and advanced users with a usual saved get one line under the summary: "or say 'show me everything'". Read `workflows/trade-shifts/see-everything.md` when they say it.
- **Step-by-step, one question at a time** (default = their usual, else as noted):
  - **Sites:** "What sites are you willing to work at?" Their eligible sites from `whoami`, in their location order. Default: all eligible.
  - **Shift times:** "Which shift times are you willing to work in general?" Default: all except the holiday times. When the shift they're giving away is a holiday or peri-holiday shift, the times from the holiday question (`workflows/trade-shifts/special-cases.md`) are checked too, for this search only.
  - "Would you take a longer shift?" **No, same length only** (default) / **Up to 2.5 h longer** / **Up to 4.5 h longer**. Then "Is it OK to ask a colleague to take a longer shift?" Same choices and default.
  - "Which kinds of trades would you consider?" A to F (several allowed; default A to D). Define them for their help level from the glossary.
  - "Would you like the table first, or always the full list?" **Table first** (default) / **Always the full list** (`"show": "list"`). This is the last settings question: don't ask about their shift-time order here (it comes from their saved ratings).
- Walk-me-through users hear what "your usual" means once per run (see `workflows/trade-shifts/your-usual.md`).

## Search (Trade Shifts 5)
Run `swap`. It searches every site they're eligible for and shows only their chosen sites.
- Paste the `TABLE` as printed, with its legend line (rows: shift times in their order; columns: sites in their order; each box: total (A+B, C+D, E+F); – for a shift time they didn't choose or narrowed out, never 0).
- 12 options or fewer: the list follows. `OVER_12`: show the table, then offer **Display all** (default; re-run with `"show": "list"`) / **Narrow it (by site, shift time or category)** / **Something else (type it below)**. **Narrow it:** ask how in one question, then re-run with a `filter` (fields in `workflows/trade-shifts/see-everything.md`). After a Show me everything search that isn't narrowed yet, `OVER_12` asks only how to narrow: follow `workflows/trade-shifts/see-everything.md`.
- `SAME_DAY`: say how many options are on the day of the shift they're giving away (a switch of site or time, not a day off).
- `OTHER_SITES` (under 20 options): say how many more are at the sites they left out, per site.
- `EMPTY_ROWS`: for shift times they chose that came up empty, say in one line what one change would add. Don't guess reasons the script doesn't give.
- `FEW_RESULTS` (under 10): read `workflows/trade-shifts/few-results.md`. `NOTHING_TO_LOOSEN`: read `workflows/trade-shifts/nothing-to-loosen.md`.
- `ROLE_OVERRIDE`: remind them once that the schedulers have the final say.
- `ROSTER_BLOCKS`: see `workflows/trade-shifts/blocks.md`.
- `COLLEAGUE_VACATION_EXCEPTION`: these colleagues are in the results even though ShiftAdmin has them on vacation. Next to each one, say that ShiftAdmin has them on vacation, but they've said they might be available. (A colleague's roster exception frees only the shift time it names; "all" frees the day. Colleagues are never offered a trade onto a time they've blocked on the roster.)
- **"Why wasn't <colleague> offered?"** (any time from here on): read `workflows/trade-shifts/why-not-offered.md`.

## The list (Trade Shifts 6)
Under each category-and-tier heading, one line per option, as `10/21 Wed B 9aE 0900-1700 (Example, A.)` (no `#id`s). Keep the script's notes (holiday, ML, same day, back-to-back, split shift). Buddy shifts go under their own heading. Walk-me-through users get long lists a few at a time, even after Display all. Ask: "Should I remove any?"

## Recipients, Delivery, Draft, Sent or not (Trade Shifts 7 to 10)
Only when they want to send requests: read `workflows/trade-shifts/messages.md`. Otherwise go on to Your usual (Trade Shifts 11).

## Your usual (Trade Shifts 11)
Read `workflows/trade-shifts/your-usual.md`. Then go to the wrap-up (`workflows/wrap-up/main.md`).
