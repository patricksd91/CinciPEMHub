# Trade Shifts: Messages (Trade Shifts 7 to 10)

**Version:** 0.01.82

Read after The list (Trade Shifts 6), when the user wants to send requests. Shared by Trade Shifts and Swap Locations.

## Recipients (Trade Shifts 7)
Ask who to send to: names, all, a category, or all except some (no default). Run `contacts`.

**Request history** (kept in Local Data, requests/history): before drafting to each colleague, run `reqhist --colleague "<name>" --shift <id> --dates <trade-into dates>`. Any form of the colleague's name works ("Example, A." from the list, "Alex Example" from `contacts`, or "Dr. Alex Example"); pass whichever is at hand.
- `REQUEST_REPEAT`: they were already sent this exact request. Leave them out, name them, and offer a follow-up to that request instead.
- `REQUEST_PARTIAL`: say which dates were asked before.
- `REQUEST_DRAFTED_BEFORE` or `REQUEST_NEW`: go ahead.
- The script saves it in the history as a draft and merges it for you: sent requests are always kept, and a new draft replaces only an earlier draft for the same colleague, shift and dates. A draft never counts as asked.
- **"Did my trade go through?"** (only when they ask, in this chat or a later one): the skill can't see replies; they go to the user. Run `shifts` for that date: if the shift is no longer theirs in ShiftAdmin, the trade was entered. If it's still theirs, say so, and check when the request was sent with `reqhist --check --colleague "<name>" --shift <id>` (saves nothing): a `REQUEST_REPEAT` line gives the date ("was asked on 9/22": "you emailed Dr. Example about it on 9/22"); offer a follow-up message. `REQUEST_NEW` or `REQUEST_DRAFTED_BEFORE`: no request to them was confirmed as sent. Never bring up past requests unprompted.


## Delivery (Trade Shifts 8)
Before drafting: skip the question if they already said how. First say how the recipients like to be reached, from `contacts`:
- `PREFERS_EACH` (5 recipients or fewer): each recipient's preferred way, one short line each (one line for a single recipient), including anyone with no cell or no email on file.
- `PREFERS` (more than 5): its one-line summary ("12 prefer texts, 9 email; 1 has no cell") instead of listing everyone.

Then ask how to send (default: `message delivery`, else **Bulk email**): **Bulk email** / **Text individually** / **Email individually** / **Each person's preferred way**. These four buttons are fixed: they're an exception to the **Something else (type it below)** rule in SKILL.md (anything else they type is still fine). If they said only "email them", ask which: **Bulk email** / **Email individually** (one question); "one email" or "a group email" means Bulk email, and "separately" or "each of them" means Email individually.
- **Bulk email:** one group email: the addresses separated by semicolons for Outlook's To line (as in the script's copy-paste `To:` line; the Outlook link sets its own To line), the group email, then an **Open in Outlook (opens your browser)** link.
- **Text individually:** for each person, name and cell, then a short text with only their shifts, each in its own code block. Flag anyone with no cell and offer email instead.
- **Email individually:** for each person, address, subject ("Shift trade? My 10/15 UC OPKY 1") and a short email with only their shifts, then an **Open in Outlook** link.
- **Each person's preferred way:** text or email per person, as `contacts` shows.

Warn only about people the chosen method goes against. Save their choice as `message delivery` (a delivery choice is always saved; it isn't a search setting). For more than about 10 people, suggest a bulk email rather than individual texts.

## Draft (Trade Shifts 9)
Draft only in the format they chose at Delivery (one group email, or one message per colleague). For a bulk email: one friendly, collegial group email ("Hi all, I'm trying to switch out of my 10/15 UC OPKY 1 shift. It looks like you might be able to work it. Would you be willing to trade for any of these?"), then each colleague by full name with the shifts they could give ("Alex Example: 10/21 B 9aE, 10/22 UC OPE 1"), signed with the name people call the primary user.

Tell them they can copy and paste any draft, or open it in their CCHMC email (Outlook on the web) with the link; if clicking doesn't open their browser, right-click the link, choose **Copy link**, and paste it into the address bar. For every Outlook link, write the messages to JSON (`{"messages": [{"label", "to": [...], "cc": [...], "subject", "body"}], "ad": true}`), run `outlook`, and show each `LINK` as `[Open in Outlook (opens your browser)](<link>)`.
- The script adds a one-line note about the skill after the signature in every Outlook draft (one of 23 versions, picked per email; 5.1). The copy-paste text you show doesn't carry it. Never offer to remove it; if the user asks, send `"ad": false` from then on, save `ad: off`, and note it in feedback. `NOTE_DROPPED_FOR_LENGTH`: say nothing.
- `TOO_LONG` (also for too many recipients): an email too long for one link gets no link at all, and links are never split. Read `workflows/trade-shifts/messages-too-long.md`.

## Sent or not (Trade Shifts 10)
Ask only here, once the drafts are shown: "Did you send these?" **Sent** / **Not yet**.
- **Sent:** for each colleague sent to, run `reqhist --colleague "<name>" --shift <id> --dates <dates> --sent` (the script saves it as sent and replaces the drafts it covers; earlier sent requests are kept). Only confirmed sends count as asked.
- **Not yet:** the requests stay drafts.
Then Your usual (Trade Shifts 11), or for an ML giveaway, the wrap-up.
