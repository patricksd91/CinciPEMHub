# Trade Shifts: ML shift (The shift, Trade Shifts 2)

**Version:** 0.01.08

Read right after the shift, only when they're trading out of an ML shift.

Ask: "Would you like to give this ML shift away, or trade it for another ML shift?" **Give it away** / **Trade for another ML shift** (`ml_mode` `"giveaway"` or `"trade"`).
- **Trade for another ML shift:** carry on with Availability (Trade Shifts 3) as usual.
- **Give it away:** skip Availability (Trade Shifts 3) and Settings (Trade Shifts 4). Go straight to Search (Trade Shifts 5): run `swap` for who can take the shift. Give the count and the levels, then ask who to send it to: **Everyone** / one or more levels / people they pick. Then Recipients, Delivery, Draft and Sent or not (Trade Shifts 7 to 10, in `workflows/trade-shifts/messages.md`). Skip Your usual (Trade Shifts 11). `(you)` marks the primary user only in their own search; when searching for someone else there's no `(you)` marker.
