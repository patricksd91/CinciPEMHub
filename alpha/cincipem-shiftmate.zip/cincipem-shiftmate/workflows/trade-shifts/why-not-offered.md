# Trade Shifts: "Why wasn't Dr. X offered?" (Search, Trade Shifts 5)

**Version:** 0.01.82

Read when the user asks why a colleague wasn't offered.

Works for Trade Shifts and Swap Locations, any time after Search.

1. Re-run the same request (same command) with `"why": ["<name>"]`. Several names can go in one run.
2. `WHY_PERSON`: every rule blocking each of their shifts. Name them all, in plain words.
   - `ALREADY_LISTED`: they are on the list already. Say that first ("Dr. X is already on your list: 10/21 B 9aE"), then any of their other shifts that were left out and why.
   - "No other shift of theirs in your dates is left out": say so; everything of theirs that could fit is listed.
   - "No setting leaves out any other shift of theirs in your dates; the rest can never be traded": say that no setting change would add more, then name those rules (e.g. shift kind, eligibility).
   - Plain words: "colleagues' blocked dates (roster)" means they blocked that date or time on the roster; "already working then" means that person already has a shift at those hours; "your narrowing (the filter chosen after the wide search) leaves it out" means the narrowing they chose after Show me everything removed it (say it that way, as their own choice).
3. `WHY_FIX`: each single setting change, re-run by the script. Suggest only a change listed there ("without your narrowing" is one of them after a narrowed wide search). If it says no single setting change brings them in (or, for someone already listed, adds more of their shifts), say that no one setting change would. Name back-to-back shifts only when a line names them as the reason or the fix.
4. Answer from these lines only. Don't compare counts with an earlier search as if their edits caused the difference; the schedule changes between runs.
