# Trade Shifts: Summary mode offers (Settings, Trade Shifts 4)

**Version:** 0.01.08

Read at Settings (Trade Shifts 4) to decide whether to offer summary mode, and when someone switches modes.

## The two modes
- **Summary mode:** all saved settings at once (see `workflows/trade-shifts/your-usual.md` for which set and the buttons).
- **Step-by-step:** one question at a time.
- Saved as `settings mode: summary` or `settings mode: step-by-step` in the primary user's Local Data. No `settings mode` saved (new users, and everyone coming from 0.01.07, which kept no such setting): step-by-step, and the offer schedule below decides when summary mode is offered. They can also say "summary mode" any time.
- Switching back is never scheduled. Every summary-mode run offers **Let's go through these one-by-one instead** on the confirm question. If they pick it: save `settings mode: step-by-step`, set the counter to 0, and ask the questions.

## When to offer summary mode (step-by-step users only)
The script keeps `summary_mode_offer <n>` in Local Data (profile/counters): the Trade Shifts runs finished in step-by-step mode since the counter last started. It adds 1 at the end of each such run. Offer at Settings (Trade Shifts 4) when the count reaches one of these:
- **Walk-me-through** (after 3 runs, then gaps of 3, 4, 5 … 10, then every 10): 3, 6, 10, 15, 21, 28, 36, 45, 55, then every 10.
- **Standard** (after the 2nd run, then each gap twice: 3, 3, 4, 4 … 10, 10, then every 10): 2, 5, 8, 12, 16, 21, 26, 32, 38, 45, 52, 60, 68, 77, 86, 96, 106, then every 10.
- **Advanced** (after the 1st run, then each gap three times: 3, 3, 3, 4, 4, 4 … 10, 10, 10, then every 10): 1, 4, 7, 10, 14, 18, 22, 27, 32, 37, 43, 49, 55, 62, 69, 76, 84, 92, 100, 109, 118, 127, then every 10.

The counter restarts at 0 after a new version that changed summary mode (the script does it).

## The offer
- **Walk-me-through** (a question, before the first settings question): "You've done this a few times now. Would you like me to show all your saved settings at once, instead of asking each one?" **Yes, show them all at once** / **No, keep asking one at a time**.
- **Standard and advanced** (one line above the first settings question, not a question): "💡 Tip: say 'summary mode' to see all your saved settings at once next time."
- Yes (or they say "summary mode" any time): `settings mode: summary` (the script saves it). No, or no reply: carry on step-by-step.

