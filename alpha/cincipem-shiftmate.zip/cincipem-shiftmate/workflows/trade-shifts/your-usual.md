# Trade Shifts: Your usual and your most recent

**Version:** 0.01.08

Read at Settings (Trade Shifts 4) in summary mode, and at Your usual (Trade Shifts 11). Swap Locations and Pickup Moonlighting use the same rules with their own sets.

## The two sets
- **Your usual:** the settings the user chose to keep. **Your most recent:** the settings from their last search. Nothing becomes their usual without them saying so.
- Each workflow has its own pair, in the clinician's Local Data (preferences): `trade shifts usual` and `trade shifts most recent`; `swap locations usual` and `… most recent`; `pickup moonlighting usual` and `… most recent`. An old `defaults` line moved from memory counts as the Trade Shifts usual.
- What counts: sites, shift times, trade categories, the two longer-shift limits, and list or table. Not dates, blocked dates, Back-to-back shifts (Setup 7), the Jeopardy and holiday answers (The shift, Trade Shifts 2), or anything added only because the shift is a holiday: the holiday shift times the holiday question turned on, and a category added for the holiday (put it in the request's `"holiday_added"`, e.g. `["E"]`). The `usual` command leaves these out and names them on `USUAL_LEFT_OUT`; don't mention that line unless they ask.
- For someone else, or in administrator mode, both sets are saved in that clinician's own Local Data files (the script does it when the request has their `clinician` and `who`), never in the primary user's.
- **Walk-me-through users, once per run:** the first time "(your usual)" shows in a run, add: "Your usual is the set of search settings you chose to keep." Not again that run.


## Settings (Trade Shifts 4), summary mode
A blocked date that `BLOCKS_ROSTER_DIFF` already showed in this chat isn't spelled out again here: list it as "(as above)".
Show one of these, with its buttons (at most 4):
- **Most recent differs from the usual:** both, side by side. **Use my usual** / **Use my most recent search** / **Change something** / **Let's go through these one-by-one instead**.
- **They match, or no most recent yet:** only the usual. **Use my usual** / **Change something** / **Let's go through these one-by-one instead**.
- **No usual yet** (they said No to making one): the most recent. **Use my most recent search** / **Change something** / **Let's go through these one-by-one instead**.

## Your usual (Trade Shifts 11)
Asked once, at the end of the run. First run `usual --workflow trade-shifts --req <the search's final request>` (`swap-locations` or `pickup-moonlighting` for those workflows). It always saves this search's settings as the most recent, and says how they compare with the usual:
- `USUAL_NONE` (first search, no usual yet): "Make these settings your usual?" **Yes** / **No**. Yes: run it again with `--make-usual`. No: saved as most recent only; ask again after their next search, until they have a usual.
- `USUAL_DIFFERS`: "This search used different settings from your usual. Here are both." Show them side by side from its rows (a small table: setting, your usual, this search). "Update your usual to this search?" **Update my usual** (run with `--make-usual`) / **Keep my old usual** / **Keep some of them**. Keep some: a numbered list of each change (old → new); they type the numbers to keep; save the kept ones as the usual (run with `--make-usual` on a request that has only those changes).
- `USUAL_SAME`: ask nothing.
- **Came from Show me everything:** run `usual` (the final narrowed settings are saved quietly as the most recent); don't offer to update the usual.
- **ML giveaway:** skip this step.

Saving a changed setting any other time: answers, edits and loosening count for this run only. If they say "make it my usual", "make this my usual" or "save that" (also after a narrowed Show me everything search: what the narrowing kept becomes the usual), run `usual --make-usual` with the current request right away and say so in one line.
