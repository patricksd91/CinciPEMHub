# CinciPEM ShiftMate – feedback

**Version:** 0.01.08 (template)

<!-- The privacy check removes the template's Version line; the Form version line below keeps it (6.11).
     File name: from `fbname` (FEEDBACK_FILE: YYYYMMDDHHMM_<LLL><FFF>_feedback.md).
     Every item starts with its ITEM_ID from `fbname --item <category>` (YYYYMMDDHHMMSS_mmm_<LLL><FFF>_<category>;
     categories: bug, request, roster, schedule, term, lesson, health, usage). Items merged from several reports keep
     the earliest ID. Critical items say **Critical** right after the ID and are never merged or dropped.
     Critical: a crash, an error, a feature that doesn't work, a role override, "don't name me", a schedule update the
     user shares (blocked dates or vacation changes), a failed automatic send, a bug that stops the user going on.
     Only what's needed to fix each item. No patient information, usernames, passwords, full schedules or personal
     conflicts. Leave out a section that has nothing in it, except the header. -->

- **Form version:** <the version on this template's Version line>
- **From (primary user):** <roster name>
- **Initials:** <LLL><FFF, as in the file name>
- **Date:** <YYYY-MM-DD>
- **File:** <the FEEDBACK_FILE name>
- **Skill version / build / roster date:** <VERSION, BUILD and ROSTER line from the script>
- **Channel:** <alpha, beta or stable>
- **Demo:** <yes if any of this came from demo mode, otherwise no>
- **Workflow(s) run:** <Trade Shifts, Swap Locations, Pickup Moonlighting, Updates, Feedback; coming-soon picks>
- **Ran for:** <Myself, or the clinician's name; for an administrator, "administrator for <clinician>">
- **Help level / Auto-send usage data and feedback / beta program:** <walk me through, standard or advanced> / <on or off> / <alpha, in, never joined or opted out>
- **Critical items:** <the IDs of the critical items below, or none>

## The primary user's own feedback
<!-- Their words exactly, each with its ID, including "tell <feedback_name> that…" items said during a workflow (6.8).
     Exactly, except: remove any password, passphrase, username or other sensitive information first. -->
### Bugs
- 
### Performance
- 
### Wish list
- 

## Automatic feedback
<!-- What Claude noticed: corrections, mistakes the user called out, rule breaks, bugs, workflow ideas, complaints about
     other systems (ShiftAdmin, Outlook), and lessons (category "lesson"): failure modes
     (searches with no or few results: settings, the script's reasons, what fixed it), schedule patterns the skill
     doesn't know yet, troubleshooting tips, the topics of "why" and help questions. For lessons: no colleagues' names
     or dates tied to a person, only the pattern. One bullet per item: ID, what happened, what should change. -->
- 

## Roster updates
<!-- Critical when it holds a role override. For each item: ID, whose info (the user's own, or someone else's), the
     file and field, and "confirmed" or "changed from <roster> to <new>". Own info is used from Local Data until the
     roster catches up; someone else's info never overrides the roster.
     staff.csv: name people call them, credentials, cell, email, contact preference, role and role overrides, fellow
     promotions, new staff, "don't name me", ad opt-out.
     Role check "That's wrong": say whether it was only listed wrong; always flag it (and anything about a permission
     exception) "for manual review".
     site_prefs.csv / time_prefs.csv: location and shift-time preference lists (rank and rating, 1.00-9.00, no ties).
     backtoback_prefs.csv: "back-to-back: let others ask me: yes/no" (columns name, allow_others_ask, updated), from
     Back-to-back shifts (Setup 7): "Yes, and let others ask me" is yes; "Yes, but only if I ask for it" and No are no.
     Colleagues can be offered trades that give this person a back-to-back only once their row says yes.
     holidays_FYxx.csv: holiday lists the user gave. -->
- 

## Blocked dates
<!-- Critical. Only the primary user's own, confirmed at Blocked-date sharing (Wrap-up 2) or sent automatically
     because they're in the sharing program. Dates and shift times only, never reasons. Never for someone else.
     For each column: what the roster has now, then what to add, change or remove. -->
- **Blocked dates:** 
- **Recurring blocks:** 
- **Can work despite a recurring block or vacation:** 

## New terms
<!-- Terms the user used that weren't in the glossary: ID, the term, what they said it means, where it came up. -->
- 

## Usage data
<!-- Only when Auto-send usage data and feedback is on (always collected, sent only then). -->
- **Plan:** <Free, Pro, Max, Team, Enterprise or Not sure>
- **Model:** <model> (<user or self-reported>)
- **Runs:** <one USAGE_ROW line per workflow run, as the script printed it>
- **Usage lines:** <the USAGE lines, merged into counts where they repeat; coming-soon picks; demo lines marked demo>
- **Features used:** <feature: times>
- **Usage limits:** <the step where a limit was hit or mentioned, or none>
- **Setting changes:** <any change to Auto-send usage data and feedback, or none>

## System health
<!-- Counts since the last feedback, plus each problem with its time. Link IDs only, never the shipped links. -->
- **Installed:** <version>, <alpha, beta or stable>; Local Data format <n>; Local Data location (desktop extension or Cowork working folder)
- **Encryption library:** <cryptography or the bundled fallback>, decrypting took <ms>
- **Schedule links:** successful attempts per link ID; each rejected or blocked attempt (ID, time, rejected or blocked)
- **New links made:** ID, link, when made (only links that produced a valid schedule)
- **Attached schedule file as a workaround:** <n> times
- **Incomplete schedules:** problems found, source (link ID or attached file), and whether the user fixed it or continued
- **Updates:** each check (worked, not published yet, or failed and why); each download; Save skill button offered, or manual steps needed
- **Delivery:** each automatic send (worked, failed, token refused), with its time and reason; failed sends in a row: <n>; each fallback to download
- **Lockouts:** passphrase tries and lockouts; setup name-check names that weren't on the roster, and any lockout
- **Saved-data problems:** anything that couldn't be saved to or read back from Local Data

## Test results
<!-- Only in test-mode files. One ### per test: the test name, the tester's words exactly, the guide's check of whether
     the skill did what the test checks, and the log (script run times, output lines, questions and buttons, what was
     saved and where, failures). Never the passphrase or schedule links. -->

_Sent automatically? Nothing more to do. Downloaded instead? Please email this file to <feedback_name> at <feedback_email> (both in SKILL_SENSITIVE.md)._
